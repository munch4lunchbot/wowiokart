local _, AK = ...

AK.RaceUI = {}
local RaceUI = AK.RaceUI
local UI = AK.UI

-- Pseudo-3D projection. Segments are sampled at even steps of 1/z rather than
-- of z: perspective maps 1/z linearly to screen height, so every quad ends up
-- the same few pixels tall instead of piling slivers onto the horizon.
-- Camera and road figures live in AK.db.tuning so `/kart tune` can correct them
-- live; only values that never need tweaking are constants here.
-- More, thinner strips. The road edge is built from axis-aligned quads, so the
-- visible staircase along the verge is exactly one strip tall: halving the
-- strip height halves the step. 110 puts them at roughly 6px.
local SEGMENTS = 150
--- How many of those 150 strips a given detail setting actually draws. Named
--- for what you get, not for a number: the difference between them is how
--- finely the road is sliced, which nobody thinks about in strips.
local SEGMENT_DETAIL = { Low = 84, Balanced = 116, High = SEGMENTS }
local FORK_SEGMENTS = 40
--- Where the road stops being sliced by screen height and starts being sliced
--- by metres. See the long note in RenderRoad.
local DETAIL_Z = 120
--- How many strips the far tail gets, at most. They are thin and cheap to look
--- at; what they buy is a far road that bends.
local TAIL_SEGMENTS = 22
--- How far off a shortcut announces itself, in metres. The ribbon is drawn as
--- far as the road is; the SIGN and its name are a warning, and a warning has a
--- range of its own.
local FORK_NOTICE = 200
-- HOW FAR THE ALTERNATE ROAD IS DRAWN. Not FAR_Z.
--
-- The ribbon used to run to the draw distance -- five hundred and sixty metres
-- by default -- which puts a second road, twenty metres to the side, one or two
-- pixels tall, with a rail floored at two and a half pixels so it stays
-- visible. What that produces is not a road: it is a bright green stripe laid
-- across the entire horizon, over the treeline, over the rock walls of a
-- tunnel, straight through the middle of the road you are on. It is in every
-- frame of the footage and it reads as the renderer being broken.
--
-- Two hundred metres is where the SIGN starts, and for the same reason: this
-- exists so you can decide, and you cannot decide at half a kilometre. The last
-- fifty of it fades, so it arrives rather than switching on.
local FORK_DRAW = 210
local FORK_DRAW_FADE = 55
--- How far before the end of a branch the main line starts being drawn coming
--- back in, and how much of it to draw. Shorter than FORK_NOTICE: a rejoin is
--- not a decision, it is a thing about to happen to you, so it only has to stop
--- being a surprise -- and a branch is a couple of hundred metres long, so a
--- longer notice would simply be on screen for the whole shortcut.
local REJOIN_NOTICE = 130
local REJOIN_DRAW = 150
-- How far the camera climbs at the top of a launch, in metres. The sprite's own
-- hop is small; this is what makes the world drop away.
-- HOW HIGH A JUMP ACTUALLY GOES, in metres of world height.
--
-- The arc used to be a screen offset -- so many kart-widths up the picture --
-- which is why it kept having to be traded against the frame: at 2.1 widths it
-- left the top of the screen, and cutting it to 0.8 took the jump with it.
-- "We don't get as much hangtime as we did, which is depressing, that was
-- really cool." It was, and I took it out.
--
-- Height in METRES fixes the trade instead of splitting it. The rise is
-- projected like everything else in the world, so it is correct at any depth
-- (a rival launching a hundred metres ahead rises a hundred metres' worth, not
-- a full screen's worth), it scales with how long the kart is actually in the
-- air, and the camera can take a measured share of it rather than all or none.
--
-- The camera climbs a little over half. What is left is the kart genuinely
-- rising in frame; what the camera takes is the ground falling away underneath
-- it, which is the other half of what a jump looks like. Both cues, and the
-- kart stays where you can see what it is doing.
-- How much of the arc the camera climbs. Small on purpose: this is a chase
-- camera easing after the kart, not a boom lifting with it. At half the arc the
-- two cancel and the jump disappears; at a fifth the kart clearly rises in
-- frame and the ground still visibly drops away under it.
local JUMP_CAMERA_SHARE = 0.18

--- Where this kart is on its jump: metres off the road, and how far along the
--- arc. Nil when it is on the ground. The apex is set by the physics at launch,
--- from the speed that earned it -- see vehicle.airApex in Race/Physics.lua.
local function jumpArc(vehicle)
  local air = vehicle and vehicle.air or 0
  if air <= 0 then return nil end
  local t = 1 - air / math.max(0.01, vehicle.airMax or 1)
  local apex = vehicle.airApex or 4.0
  return apex * math.sin(t * math.pi), t, apex
end
local TUNNEL_HEIGHT = 7.5        -- metres from road to tunnel ceiling
local TUNNEL_TILE = 5.0          -- metres per repeat of the rock texture
local PROPS = 54                 -- roadside scenery frames in flight at once
local PROP_SPACING = 9           -- metres between props on each side
-- How far ahead the road is drawn. At racing pace this is the difference
-- between three seconds of warning and five: you cannot read a corner you
-- cannot see yet, and every track felt like a straight partly because the bend
-- only appeared once you were already in it.
local FAR_Z = 330
--- How far the AIR reaches, in metres. Distinct from FAR_Z on purpose.
---
--- Fog and aerial haze used to be measured as a fraction of the draw distance,
--- which quietly made the weather a function of a SLIDER: wind the draw
--- distance out and the same hillside 200m away got clearer, wind it in and it
--- got murkier. Worse, it meant the road could never fade INTO anything -- the
--- last strip sat at the same haze whatever the setting, so the road ENDED, in
--- a hard edge with open ground beyond it, instead of dissolving at the
--- horizon. The atmosphere is a property of the world; only how much of the
--- world you are shown is a setting.
local HAZE_Z = 330
--- How far out a piece of roadside FURNITURE is drawn, in metres.
---
--- Also not a fraction of FAR_Z, and for a reason the props already learned
--- the hard way: past about 120m the road has usually swung off the side of
--- the display, so anything drawn out there enters at the screen edge and
--- travels inward rather than appearing on the road and simply growing. That
--- limit belongs to the PROJECTION, so it is a distance in metres -- pulled in
--- only when the road itself is drawn shorter than that, which is the one case
--- where a post could otherwise stand beyond the end of the tarmac.
local function reach(metres)
  return math.min(FAR_Z * 0.9, metres)
end
--- Nearer than this, a trackside object is never faded for being off-axis: it
--- is genuinely sweeping past you, not stranded off the road by a corner.
---
--- Solved rather than guessed. An object reaches the screen edge when
--- `(camDepth / dz) * worldX >= 1`, so with camDepth 0.85 a pickup on the
--- centreline half of the road (4.5m out of roadHalf 9) only leaves the frame
--- inside 3.8m, and one right on the verge (9m) inside 7.7m. Anything further
--- away than that which is off-axis was put there by the corner, not by you
--- driving past it. The first attempt used 45m, which left everything from 8m
--- to 45m unfaded -- the entire band where the road has already begun to swing
--- away -- so things carried on sliding in from the edge.
local EDGE_FADE_MIN_Z = 12
local STRIPE_LENGTH = 4.5
-- Metres covered by one repeat of the ground textures. The road art is 4 slabs
-- square, so 4.8m gives roughly 1.2m paving stones.
local ROAD_TILE = 4.2
local GRASS_TILE = 3.0
--- Mean luminance the ground textures are baked to.
---
--- Not a guess and not a measurement of the rendered frame: road.tga and
--- grass.tga are levelled to exactly these by OUTPUT_LEVEL in
--- Art/generate-art-ground.js. A strip that has dropped its texture for flat
--- colour multiplies by its own file's mean, which is what makes the changeover
--- invisible instead of a bright step across the field. If those targets move,
--- these move with them.
local ROAD_MEAN = 0.82
local GRASS_MEAN = 0.80
--- Fewest screen pixels one repeat of a texture is allowed to occupy.
---
--- There is no mipmapping here, so a texture minified past about this reads as
--- an interference pattern rather than as a surface. See the note in the strip
--- loop -- this is what caps the tiling on a distant strip.
local MIN_TEXEL = 18

-- HOW MUCH OF A REPEATING PATTERN SURVIVES AT THIS DISTANCE.
--
-- Every periodic thing on the road plane is sampled ONCE PER STRIP: the
-- light/dark paving bands, the red-and-white kerb, the dashed centre line, a
-- ramp's hazard stripes. Near the camera a stripe spans several strips and the
-- pattern comes out faithfully. Far away one strip spans several whole stripes,
-- so which phase it lands on is decided by where that single sample happened to
-- fall -- and that moves every frame you drive. Measured off a recording of the
-- Deadmines run, the far road's mean brightness swung forty values in one frame
-- and thirty back in the next. That is the "strobey" in the report: not a
-- flicker in the lighting, an ALIAS of the paint.
--
-- Which makes it the mip-map argument, and mip-mapping's answer applies: a
-- pattern finer than the sampling rate has to fade to its own average, because
-- the average is the only honest thing left to draw. A red-and-white kerb two
-- hundred metres away IS a pink line.
--
-- The measure is the strip's own extent IN METRES OF TRACK, not its height on
-- screen. Those are wildly different things here: the road is sampled uniformly
-- in 1/z, which is a singularity at the horizon, so the last strip of the near
-- band spans FIFTY-FOUR METRES of road in five pixels -- twelve whole paving
-- stripes in one sample -- and the tail strips beyond it are nine and a half
-- metres each against a 4.5m stripe. Screen height says those strips are fine.
-- Track extent says they cannot possibly resolve the pattern, which is the
-- question actually being asked.
--
-- Returns 1 while a period is comfortably longer than the strip that samples
-- it, and eases to 0 as the two converge.
local STRIPE_RESOLVE = 2.6
local function stripeFade(period, dzSpan)
  return AK.Math.Clamp((period / math.max(0.01, dzSpan) - 1) / STRIPE_RESOLVE, 0, 1)
end

-- A LINE THINNER THAN A PIXEL MUST NOT BE DRAWN AT FULL STRENGTH.
--
-- Differencing two consecutive frames of a real run, the brightest thing on
-- screen by a wide margin was the kerb -- then the marker posts, then the lane
-- dashes. All three are thin, bright and clamped to a one-pixel minimum, so out
-- where their true width falls under a pixel they are drawn at full strength
-- wherever the rounding happens to put them, and jump a whole pixel between
-- frames. That is the other half of "strobey", and it is the oldest trick in
-- rasterisation to fix: keep the minimum width, and give back in ALPHA exactly
-- what was taken in width, so the line's total ink stays what the geometry
-- asked for and it fades out instead of flickering.
--- How much of a strip lies on a launch ramp, and how much of that is the lip.
---
--- A POINT TEST IS A COIN FLIP OUT THERE. This asked RampAt for the strip's far
--- end alone, which is exact in the near field and meaningless in the far one:
--- 1/z sampling makes the last strips tens of metres long, and a ramp is about
--- forty-five, so whether the whole jump was painted at all came down to where
--- one sample happened to land. It landed somewhere different every frame, so
--- the ramp flashed in and out and jumped about -- "jumps still look slightly
--- glitchy in the distance", which is the same singularity behind everything
--- else in the far field.
---
--- Measured as OVERLAP instead. A strip that is half on the ramp gets half the
--- paint, which is stable frame to frame because it is a property of the road
--- rather than of the sampling.
local function rampCover(track, fromZ, toZ)
  local ramps = track.ramps
  if not ramps then return 0, 0 end
  local a = AK.TrackBuilder:At(track, fromZ)
  local b = AK.TrackBuilder:At(track, toZ)
  -- The strip straddles the lap seam, which is one strip a lap. Fall back to
  -- the point test rather than reporting a negative span.
  if b <= a then
    local ramp = AK.TrackBuilder:RampAt(track, toZ)
    if not ramp then return 0, 0 end
    return 1, (ramp.to - b < 2.2) and 1 or 0
  end
  local span = b - a
  local on, lip = 0, 0
  for _, ramp in ipairs(ramps) do
    local lo, hi = math.max(a, ramp.from), math.min(b, ramp.to)
    if hi > lo then
      on = on + (hi - lo)
      local lipFrom = math.max(lo, ramp.to - 2.2)
      if hi > lipFrom then lip = lip + (hi - lipFrom) end
    end
  end
  return on / span, lip / span
end

-- HOW MUCH A BLINKING THING IS ALLOWED TO BLINK, by how far away it is.
--
-- The same argument as stripeFade, in time rather than in space. A pattern
-- finer than the sampling has to ease toward its own mean or it aliases; a
-- thing that BLINKS while it is two pixels wide and two hundred metres away
-- cannot be localised either, so it stops reading as a signal and starts
-- reading as the picture being broken. Three things in the scene blink -- the
-- hazard rails along a launch ramp at 1.9Hz, its side barriers, and Oribos's
-- travelling kerb pulse -- and every one of them is at its most distracting
-- exactly where it is least useful: out at the horizon, where the eye cannot
-- tell a flashing rail from a rendering fault. That is what is left of "jumps
-- still look slightly glitchy in the distance".
--
-- The amplitude eases out; the MEAN stays. A distant ramp is still hazard gold
-- and still reads as a ramp -- it simply holds still until you are close enough
-- for the flashing to mean something.
local FLICKER_NEAR, FLICKER_FAR = 70, 170
local function flicker(dz)
  return AK.Math.Clamp((FLICKER_FAR - dz) / (FLICKER_FAR - FLICKER_NEAR), 0, 1)
end

local THIN_PIXELS = 1.6
local function thinLine(width)
  if width >= THIN_PIXELS then return width, 1 end
  return THIN_PIXELS, math.max(0, width) / THIN_PIXELS
end

--- Ease a colour toward the average it shares with its opposite number, by
--- `keep`. At keep = 1 the colour is itself; at 0 both halves of the pattern
--- land on the same value and there is nothing left to alias.
local function towardMean(r, g, b, r2, g2, b2, keep)
  local mr, mg, mb = (r + r2) * 0.5, (g + g2) * 0.5, (b + b2) * 0.5
  return mr + (r - mr) * keep, mg + (g - mg) * keep, mb + (b - mb) * keep
end
local BOOST_FOV = 0.075
-- THE CROWD COMES IN GROUPS, AND A GROUP HAS A PLACE.
--
-- SPOTS are places along the road where people gather; CROWD_PER_SPOT frames
-- are reserved at each, and how many of them are actually used varies, so some
-- spots hold three people, some two and some one person on their own. Anything
-- evenly spaced reads as fence posts however varied the figures are.
--
-- SPECTATOR_SLOTS must stay CROWD_PER_SPOT times the number of spots in view,
-- and it is what makes the crowd HOLD STILL. See the note in RenderSpectators:
-- a person's identity is their seat, and their seat is their position, so the
-- arithmetic below has to be a bijection or people change face as you drive.
local SPECTATOR_SPACING = 34
local CROWD_PER_SPOT = 3
local CROWD_SPOTS = 3
local SPECTATOR_SLOTS = CROWD_PER_SPOT * CROWD_SPOTS
-- Metres of clear ground between the edge of the tarmac and a spectator. A
-- model is drawn about its own centre and is roughly a metre and a half across,
-- so anything under about two puts an elbow over the kerb.
local CROWD_CLEAR = 2.6
--- What the crowd is doing. Resolved lazily -- Constants and Data\Models load
--- before this file, but reading them at the top of it is still an ordering
--- dependency nobody should have to remember when moving a file in the .toc.
local CROWD_POSES
local PARTICLES = 110
local TREES = 44

local ORDINALS = { "1ST", "2ND", "3RD", "4TH", "5TH", "6TH", "7TH", "8TH" }

-- Drift charge stages, Mario-Kart style: the spark colour tells you how big the
-- boost will be before you release it.
--- The drift ladder. These thresholds MUST match Physics:ReleaseDrift exactly
--- (0.35 mini / 0.9 super / 1.8 mega) or the colour lies about the boost you
--- are about to get: the meter used to turn at 0.75 and 1.70, so it promised a
--- tier you had not banked yet and you released early. Blue, orange, purple --
--- three unmistakably different hues, because the whole point is reading it in
--- peripheral vision with your eyes on the corner.
local DRIFT_STAGES = {
  { threshold = 1.80, color = { 0.72, 0.42, 1.00 }, tier = 3 },   -- mega
  { threshold = 0.90, color = { 1.00, 0.58, 0.10 }, tier = 2 },   -- super
  { threshold = 0.35, color = { 0.30, 0.70, 1.00 }, tier = 1 },   -- mini
  { threshold = 0.00, color = { 0.92, 0.94, 1.00 }, tier = 0 },   -- nothing banked
}

-- --------------------------------------------------------------------------
-- HUD layout
-- --------------------------------------------------------------------------
--
-- Every HUD offset used to be an absolute pixel figure authored against a
-- 1280-wide window: a 620x73 header, a 128px map, a control row spanning 816px
-- of a screen that may only be 800 wide. On a 1440p client the whole interface
-- shrivelled into the corners at half its intended size; on a small one it ran
-- off both edges. The SKYLINE was fixed for exactly this reason -- there is a
-- comment about it forty lines up -- and the HUD, which the player actually
-- reads, never was.
--
-- So: the HUD is authored once at a design resolution and the whole thing is
-- scaled as one frame to fit whatever the player has (RaceUI:LayoutHud). One
-- SetScale on one container handles every child, so the offsets below stay
-- readable numbers rather than becoming screen fractions.
--
-- The arrangement is Mario Kart's grammar, not a settings panel's. The three
-- things you need without looking are WHICH LAP, WHAT ITEM and WHAT PLACE, so
-- those get the corners, the centre and the size. The clock and the map are
-- reference material you consult between corners, so they get the far corners.
-- Everything used to live in one 620x73 strip of eight readouts across the top.
-- THE PAUSE PANEL, in one place.
--
-- The panel used to be a fixed 320x302 with every control at a hand-measured
-- offset, and two of those controls come and go: RESTART is meaningless in a
-- race other people are in, and the developer row is off unless the player has
-- asked for it. Hiding a button left a 46px hole in the middle of the stack and
-- a 78px void under it -- a menu with gaps in it reads as broken, not as
-- configurable. The stack is measured at show time now and the panel is exactly
-- as tall as what is on it.
--- Where the big number in the lap panel starts. On a circuit the word beside
--- it is "LAP" and it starts at 52; in an arena the word is "BALLOONS", which
--- is four times as wide, so the number moves out of its way.
local LAP_NUMBER_X, BALLOON_NUMBER_X = 52, 100
-- HOW FAR A TUNNEL WALL SITS FROM THE ROAD IT STANDS BESIDE.
--
-- "The walls are hard to see" was reported three times and answered three times
-- by making them exist, be lit, and not be occluded -- all of which they now
-- are. What was never done was MEASURING them, and the moment
-- Art/verify-contrast.js was taught to sample a covered strip the answer was
-- flat: the walls scored 0.07 to 0.16 against the road, on the same scale where
-- the verges of those very circuits score 0.25 to 0.47. A wall was about a
-- third as legible as a grass bank.
--
-- It was a FRACTION of the road's light -- half of it -- and a fraction is the
-- wrong instrument. `rockTint` is derived from the road's own colour and
-- normalised to carry hue only, so a wall is already the same colour as the
-- floor; all it has is luminance, and a fraction gives less and less of that
-- the darker the road is. Measured: taking the fraction from a half down to
-- three tenths improved the bright circuits and made the dark ones WORSE --
-- Icecrown fell from 0.112 to 0.044 -- because below a certain level everything
-- converges on black together.
--
-- So the wall is held a fixed DISTANCE from the road instead, and goes brighter
-- than the floor rather than darker when the floor is already too dark to get
-- under. Which is also what a shaft actually looks like: cut rock beside a dark
-- road catches more light than the road does, not less.
-- Measured, not guessed: the road's luminance deep inside a shaft runs from
-- 0.095 on Durotar to 0.375 on Oribos. On the dark half of that range there is
-- no room UNDER the road at all -- which is why a darker fraction made those
-- circuits worse, not better. So the wall is aimed at a luminance a fixed
-- distance from the road's, and goes over it when there is no room under.
local WALL_GAP = 0.23     -- how far a wall's pixel sits from the road's, in luminance
local WALL_MIN = 0.07     -- below this a wall goes lighter than the road instead
local WALL_MOUTH = 0.35   -- how much of the gap is given back out at the mouth
--- The baked mean of rock.tga, so a tint aimed at a luminance lands on it.
--- ROAD_MEAN above is the same idea for the tarmac.
local ROCK_MEAN = 0.74

local function luminance(c) return 0.299 * c[1] + 0.587 * c[2] + 0.114 * c[3] end

--- The multiplier a tunnel wall's texture is drawn with, aimed so the PIXEL
--- lands a readable distance from the road's pixel beside it.
--- @param roadColour the track's own road colour
--- @param roadLight the light the road is being drawn at right here
--- @param tint the rock tint, which carries hue only
--- @param coverage 0 at the mouth, 1 deep inside
local function wallLight(roadColour, roadLight, tint, coverage)
  local roadLum = luminance(roadColour) * roadLight * ROAD_MEAN
  local gap = WALL_GAP * (1 - WALL_MOUTH * (1 - coverage))
  local want = roadLum - gap
  if want < WALL_MIN then want = roadLum + gap end
  return want / math.max(0.05, luminance(tint) * ROCK_MEAN)
end
local PAUSE_W = 320
local PAUSE_WHERE_Y = 54       -- top of the circuit's name
local PAUSE_COUNT_Y = 71       -- top of the lap (and heat) count under it
local PAUSE_FIRST_Y = 96       -- top of the first big button
local PAUSE_BTN_W, PAUSE_BTN_H = 240, 40
local PAUSE_BTN_GAP = 6
local PAUSE_TOOL_W, PAUSE_TOOL_H = 76, 28
local PAUSE_TOOL_GAP = 16      -- extra air above the developer row
local PAUSE_BOTTOM = 22

local HUD_DESIGN_W, HUD_DESIGN_H = 1600, 900
local HUD = {
  lap      = { point = "TOPLEFT",     x =   26, y =  -22, w = 196, h =  74 },
  item     = { point = "TOP",         x =    0, y =  -22, w = 124, h = 124 },
  clock    = { point = "TOPRIGHT",    x =  -26, y =  -22, w = 236, h =  84 },
  place    = { point = "BOTTOMLEFT",  x =   30, y =  116, w = 210, h = 132 },
  map      = { point = "BOTTOMRIGHT", x =  -26, y =  110, w = 168, h = 168 },
  drift    = { point = "BOTTOM",      x =    0, y =  112, w = 320, h =  18 },
  controls = { point = "BOTTOM",      x =    0, y =   26, w = 872, h =  44 },
  quit     = { point = "TOPRIGHT",    x =  -26, y = -116, w =   76, h = 26 },
  -- THE BANNER AND THE START GANTRY BELONG IN HERE TOO.
  --
  -- They were the only two pieces of the interface placed by hand instead of
  -- from this table, which meant verify-hud -- which checks every rectangle
  -- for collisions and for running off the display, at eight resolutions --
  -- was checking neither of them. And the gantry had a real bug because of
  -- it: its lamp size and its offset were computed from the FRAME's height in
  -- real pixels and then applied inside a coordinate space that is scaled to
  -- the design size, so they were only ever right at 1600x900. At 1440p that
  -- is a 127px lamp sitting 460 pixels down the screen. Both are design-unit
  -- boxes now, like everything else, and both are checked.
  --
  -- The vertical stack down the middle: item (22-146), the shortcut line
  -- (~156-171), the banner, then the lights.
  notice   = { point = "TOP",         x =    0, y = -178, w =  700, h = 52 },
  lights   = { point = "TOP",         x =    0, y = -244, w =  272, h = 84 },
}
local HUD_PANEL = { .025, .05, .10, .88 }
--- The cooldown-lap finishing ladder. Sized off the racer cap so it fits the
--- field exactly rather than leaving a gap under a short one.
local LADDER = { w = 250, row = 22, top = 32 }
LADDER.h = LADDER.top + LADDER.row * AK.MAX_RACERS + 10
local ITEM_ICON = 74
-- Drift tick positions as a FRACTION of the meter, derived from the ladder
-- above rather than from three hand-placed pixel offsets that had drifted out
-- of step with it: the ticks used to sit at even thirds while the tiers turned
-- at 0.35, 0.90 and 1.80 of a 2.5 scale, so the bar's rungs marked nothing.
local DRIFT_MAX = 2.5
-- Named rungs. The colour tells you which tier you are on in peripheral vision;
-- the name confirms it when you have a moment to look.
local DRIFT_TIER_NAMES = { [1] = "MINI", [2] = "SUPER", [3] = "MEGA" }
local DRIFT_TRACK = HUD.drift.w - 8
local DRIFT_TICKS = {}
for i = #DRIFT_STAGES - 1, 1, -1 do
  DRIFT_TICKS[#DRIFT_TICKS + 1] = DRIFT_STAGES[i].threshold / DRIFT_MAX
end

--- Put a region on one of the HUD table's boxes.
---
--- `mode` is "box" for something that fills the box (a plate, a frame) and
--- "centre" for something that sits in the middle of it (a line of text, whose
--- own size is its content's). Everything on the HUD goes through the table so
--- that verify-hud, which walks the same table at eight resolutions, is
--- actually looking at the whole interface.
local function placeHud(region, box, mode)
  region:ClearAllPoints()
  if mode == "centre" then
    region:SetPoint("CENTER", region:GetParent(), box.point, box.x, box.y - box.h * 0.5)
  else
    region:SetPoint(box.point, box.x, box.y)
  end
end

-- A widget texture is always an axis-aligned rectangle: SetRotation turns the
-- UVs, not the quad, so flat colour can never be round or soft-edged. The fix
-- is real art with an alpha channel, so the addon ships its own generated TGAs
-- rather than guessing at Blizzard asset names that may not exist.
--
-- ONE of these per file. This file had TWO -- `ART` further down and an
-- `ART_PREFIX` up here holding the identical string, because the second was
-- added where the first was not yet in scope. Hoisted, so there is one.
local ART = AK.ART

local OBJECT_STYLE = {
  -- Item cubes float and bob; dash panels lie flat on the tarmac.
  box = { icon = ART .. "itembox.tga", color = { 1.00, 0.82, 0.25 }, label = "", size = 2.2, float = true, spin = true },
  boost = { icon = ART .. "dashpad.tga", color = { 1.00, 0.72, 0.18 }, label = "", size = 3.8, flat = true },
  shortcut = { icon = "Interface\\Icons\\Spell_Arcane_PortalStormWind", color = { 0.35, 0.85, 1.00 }, label = "SHORTCUT", size = 3.4 },
  hazard = { icon = ART .. "banana.tga", color = { 1.00, 0.85, 0.22 }, label = "", size = 2.2 },
}

-- One body texture per kart id, so the six karts are six silhouettes instead of
-- one slab tinted six ways. Keyed off AK.Karts because that is exactly the set
-- Art/generate-art-kart.js emits art for; anything unknown (the ghost before a
-- selection exists, a future kart without art) falls back to the generic body
-- rather than showing WoW's missing-texture green.
local kartArt = {}
for _, entry in ipairs(AK.Karts or {}) do
  kartArt[entry.id] = ART .. "kart-" .. entry.id .. ".tga"
end
local function kartTexture(id)
  return kartArt[id] or (ART .. "kart.tga")
end
local SOLID = "Interface\\Buttons\\WHITE8x8"

--- `tile` asks for REPEAT wrapping, without which a SetTexCoord above 1 clamps
--- instead of repeating and the art just stretches.
local function makeTexture(parent, layer, color, sublayer, file, tile)
  local texture = parent:CreateTexture(nil, layer, nil, sublayer)
  if file and tile then
    texture:SetTexture(ART .. file, "REPEAT", "REPEAT")
  else
    texture:SetTexture(file and (ART .. file) or SOLID)
  end
  texture:SetVertexColor(unpack(color))
  return texture
end

-- A ROAD EDGE IS A DIAGONAL. IT MUST NOT BE DRAWN AS A STAIRCASE.
--
-- Everything else on the road plane is an axis-aligned rectangle, because a
-- pseudo-3D road is a stack of them. That is fine for a wide fill: the road
-- quad's boundary steps, but the tarmac either side of the step is the same
-- colour, so nothing shows. It is not fine for the kerb. The kerb is the
-- highest-contrast thing in the frame -- saturated red and white against dark
-- tarmac and green verge -- laid exactly along the boundary that steps, and at
-- distance it turned into a flight of hard little stairs. That, more than any
-- texture, is what "blocky in the distance" was.
--
-- WoW has an actual line primitive -- CreateLine, a quad rotated to join two
-- points at a given thickness -- so the kerb can just BE the diagonal. Each
-- piece runs from its strip's near edge to its far edge, which is the next
-- strip's near edge, so the chain is continuous by construction and every
-- segment lies along the true edge instead of beside a staircase of it.
--
-- The fallback is the axis-aligned span this replaces, kept because a widget
-- that fails to construct has to degrade to a road with chunky kerbs and not to
-- a road with no kerbs at all.
local function makeEdge(parent, layer, colour, sublayer)
  local line = parent.CreateLine and parent:CreateLine(nil, layer, nil, sublayer)
  if line and line.SetStartPoint and line.SetThickness then
    line:SetTexture(SOLID)
    line:SetVertexColor(unpack(colour))
    line.akLine = true
    return line
  end
  return makeTexture(parent, layer, colour, sublayer)
end

--- Lay an edge piece so that it covers `width` pixels HORIZONTALLY along its
--- whole run, from (x0, y0) to (x1, y1). Coordinates are offsets from the race
--- frame's CENTER, as everything else on the road plane is.
---
--- Horizontal, not perpendicular, because horizontal is the only width the
--- renderer's model has: a pseudo-3D road is a stack of horizontal spans, and
--- the kerb's width is a fraction of the span's. Asking a line for a
--- perpendicular thickness instead is what turned the last strips before the
--- horizon -- where the road sweeps forty pixels sideways in one -- into red
--- streaks ruled clean across the frame.
local function setEdge(edge, frame, x0, y0, x1, y1, width)
  local dx, dy = x1 - x0, y1 - y0
  -- However oblique the run, the piece stays as thick as the strip is tall --
  -- the width asked for grows with the turn, and thickness is width * dy / run
  -- -- so there is no angle at which this degenerates into a sliver. The only
  -- case with no diagonal in it is a strip less than a pixel high, which is
  -- every strip in the last metre before the horizon: one scanline, and a
  -- rectangle is what one scanline of a diagonal is.
  if edge.akLine and math.abs(dy) >= 1 then
    local run = math.sqrt(dx * dx + dy * dy)
    edge:SetThickness(math.max(0.6, width * math.abs(dy) / run))
    edge:SetStartPoint("CENTER", frame, x0, y0)
    edge:SetEndPoint("CENTER", frame, x1, y1)
  else
    -- Rectangle covering the union of both ends' bands. Wider than the diagonal
    -- it stands in for, which is the right way to be wrong: it still hides the
    -- road quad's own step, and at this angle nothing thinner would.
    local lo = math.min(x0, x1) - width * 0.5
    local hi = math.max(x0, x1) + width * 0.5
    if edge.akLine then
      -- A Line cannot be an axis-aligned box, so lay it flat down the middle
      -- and let its thickness carry the height.
      local mid = (y0 + y1) * 0.5
      edge:SetThickness(math.max(1, math.abs(dy)))
      edge:SetStartPoint("CENTER", frame, lo, mid)
      edge:SetEndPoint("CENTER", frame, hi, mid)
    else
      edge:SetPoint("BOTTOM", frame, "CENTER", (lo + hi) * 0.5, math.min(y0, y1))
      edge:SetSize(math.max(1, hi - lo), math.max(1, math.abs(dy)))
    end
  end
end

-- Additive blending plus a soft radial falloff is what makes something read as
-- emitted light rather than a painted rectangle.
local function makeGlow(parent, layer, color, sublayer, file)
  local texture = parent:CreateTexture(nil, layer, nil, sublayer)
  texture:SetTexture(ART .. (file or "glow.tga"))
  texture:SetVertexColor(unpack(color))
  texture:SetBlendMode("ADD")
  return texture
end

-- Additive, but filling its whole rect: for washes and bar fills, where a
-- radial falloff would leave dark corners.
local function makeWash(parent, layer, color, sublayer)
  local texture = parent:CreateTexture(nil, layer, nil, sublayer)
  texture:SetTexture(SOLID)
  texture:SetVertexColor(unpack(color))
  texture:SetBlendMode("ADD")
  return texture
end

--- Tint an item's icon with the item's own colour.
---
--- The shells are drawn white-cored ON PURPOSE -- Art/generate-art-items.js
--- says so in its first three lines -- precisely so one texture makes the green,
--- the red and the spiny by vertex tint. The projectile in flight does apply it.
--- The item box never did, so five different items (green shell, red shell,
--- spiny shell, and the triple versions of two of them) were the same white ball
--- in your hand. Which shell you are holding is the entire decision in Mario
--- Kart: one homes, one does not, one is aimed at whoever is winning.
local function applyItemTint(texture, item)
  local tint = item and item.tint
  if tint then
    texture:SetVertexColor(tint[1], tint[2], tint[3], 1)
  else
    texture:SetVertexColor(1, 1, 1, 1)
  end
end

--- Apply `fn` to every argument that is not nil -- INCLUDING past the nils.
---
--- `ipairs` stops dead at the first nil, so `ipairs({ a, b, c })` where `a`
--- happens to be nil silently skips b and c too. Both callers below guard each
--- element with `if region then`, which is proof the author expected the list to
--- hold nils, and proof that guard could never be reached: the loop had already
--- stopped. One renamed widget would have quietly stopped hiding every widget
--- after it in the list -- the HUD left on screen over the title menu, with no
--- error to say why. `select("#", ...)` counts the arguments as written.
local function forEachPresent(fn, ...)
  for i = 1, select("#", ...) do
    local value = select(i, ...)
    if value then fn(value) end
  end
end

local function shade(color, factor, alpha)
  return { color[1] * factor, color[2] * factor, color[3] * factor, alpha or 1 }
end

-- SetGradient's signature moved to colour objects in 10.0; skip the flourish
-- rather than error on clients that disagree.
local function applyGradient(texture, orientation, r1, g1, b1, a1, r2, g2, b2, a2)
  if not texture.SetGradient or not CreateColor then return end
  pcall(texture.SetGradient, texture, orientation, CreateColor(r1, g1, b1, a1), CreateColor(r2, g2, b2, a2))
end

--- Show or hide, but only when the state actually CHANGES.
---
--- Every frame the scene renderer walks its pools and hides whatever it did not
--- use. Hiding something that has been hidden since the last corner is a call
--- into the client that does nothing at all, and there are hundreds of them:
--- measured on an Elwynn frame, RenderFork spent 12% of the entire frame's
--- widget traffic hiding forty branch strips on a circuit with no fork in
--- sight. The road does the same thing at the far end of its own strip list.
---
--- The cached flag lives on the region, so anything that shows or hides one of
--- these pooled regions has to come through here or the cache goes stale.
--- Parent visibility is not affected: hiding the race frame leaves every
--- child's own flag exactly as it was, which is what makes this safe.
local function setShown(region, visible)
  if visible then
    if region.akVisible ~= true then
      region.akVisible = true
      region:Show()
    end
  elseif region.akVisible ~= false then
    region.akVisible = false
    region:Hide()
  end
end

local function vehicleIsDrifting(vehicle)
  return vehicle and vehicle.drifting
end

local function driftColor(charge)
  for _, stage in ipairs(DRIFT_STAGES) do
    if charge >= stage.threshold then return stage.color end
  end
  return DRIFT_STAGES[#DRIFT_STAGES].color
end

--- Which boost tier this charge would currently bank: 0 (none) to 3 (mega).
local function driftTier(charge)
  for _, stage in ipairs(DRIFT_STAGES) do
    if (charge or 0) >= stage.threshold then return stage.tier end
  end
  return 0
end

--- Project a point ahead of the camera onto the screen.
-- @param dz metres ahead of the camera (must be > 0)
-- @param worldX lateral world offset in metres
-- @return screen x, screen y (frame-centre relative), pixels-per-metre scale
-- @param worldY road surface height at that point, in metres. The camera rides
-- at camHeight above the road beneath it, so a crest ahead pushes toward the
-- horizon and a dip falls away below.
-- Camera yaw. Rotating the camera by a small angle shifts every projected point
-- by the SAME screen distance (the Z terms cancel against 1/z), so a yaw is a
-- uniform horizontal slide of the world -- which is exactly the swinging
-- vanishing point that makes a corner feel like turning rather than like the
-- road sliding sideways underneath you. This is the single biggest difference
-- between an OutRun-style renderer and a kart racer.
function RaceUI:Project(dz, worldX, camX, worldY)
  local tuning = self.T
  local scale = (self.camDepth or tuning.camDepth) / dz
  local x = scale * (worldX - camX) * self.halfWidth
    + (self.yawShift or 0) + (self.shakeX or 0)
  local rise = (self.camWorldY or tuning.camHeight) - (worldY or 0)
  local y = tuning.horizon - scale * rise * self.halfHeight + (self.shakeY or 0)
  return x, y, scale * self.halfWidth
end

-- Where the road sits on screen, accumulated FORWARD from the kart.
--
-- This replaces projecting the road's absolute world position. That older model
-- required the centreline to stay within a few units of the camera axis for the
-- small-angle projection to hold, which is why Compile renormalises the entire
-- lap down to `sweep` -- and why every corner rendered nearly flat. Worse, the
-- normalisation divides by the lap's GLOBAL peak, so the more corners a track
-- had, the harder each one was squashed: making a circuit more technical made
-- it look more like a straight line. Measured, the tightest hairpin in the game
-- moved the road 90px out of a 640px half-screen, and Elwynn's sweep moved it
-- exactly 0px.
--
-- Classic pseudo-3D never tracks world position. The kart is the origin and
-- curvature integrates forward from it: each step ahead adds to a running
-- lateral velocity, which adds to a running offset. A hairpin then bends the
-- road by the same amount regardless of what else is on the lap, and the road
-- may bend arbitrarily far ahead without leaving the projection's valid range.
--
-- It also reads the same curveTable the physics already steers by, so what you
-- see and what the kart feels finally come from one source.
local BEND_STEP = 2

--- The tuned gain, as a plain number. The panel stores a 1-30 dial so it has
--- usable resolution on screen; the renderer wants the small real value.
local function bendGain()
  local dial = AK.db and AK.db.tuning and AK.db.tuning.bendGain
  return (dial or 10.0) / 1000
end

function RaceUI:BuildBend(track, camZ)
  local samples = math.ceil(FAR_Z / BEND_STEP) + 4
  local bend = self.bendTable
  if not bend then bend = {} self.bendTable = bend end
  local gain = bendGain()
  local offset, lateral = 0, 0
  for i = 1, samples do
    bend[i] = offset
    lateral = lateral + AK.Math.RoadCurve(track, camZ + (i - 1) * BEND_STEP) * gain * BEND_STEP
    offset = offset + lateral * BEND_STEP
  end
  self.bendTable, self.bendCount, self.bendFrom = bend, samples, camZ
end

--- Lateral screen offset of the centreline at an absolute distance. Clamped at
--- both ends so anything sampled outside the drawn window still resolves.
function RaceUI:Bend(distance)
  local bend = self.bendTable
  if not bend or not self.bendCount then return 0 end
  local t = (distance - (self.bendFrom or 0)) / BEND_STEP
  local maxT = self.bendCount - 2
  if t < 0 then t = 0 elseif t > maxT then t = maxT end
  local index = math.floor(t)
  local fraction = t - index
  local a, b = bend[index + 1] or 0, bend[index + 2] or 0
  return a + (b - a) * fraction
end

--- World-space helpers so every projected thing agrees on where the road is.
function RaceUI:RoadAt(track, distance)
  return self:Bend(distance), AK.Math.RoadHeight(track, distance)
end

--- Fade for anything the corner has swung off-axis.
---
--- One implementation for objects, hazards and props, because three copies of
--- the same thresholds drifted apart -- props ended up with no fade at all and
--- were drawn to 2.2 half-widths off screen, which is what was still sliding in
--- after the distance-space fix.
---
--- The band starts at 0.62 rather than 0.86 of a half-screen. At 0.86 a thing
--- was fully opaque until it was practically at the edge, so the eye caught it
--- travelling before it began to dim; starting the fade well inside the frame
--- means anything drifting outward is already going before it can be tracked.
--- Inside EDGE_FADE_MIN_Z nothing fades: that is a pickup genuinely sweeping
--- past you, and hiding it is worse than the slide ever was.
function RaceUI:EdgeFade(x, dz)
  if (dz or 0) <= EDGE_FADE_MIN_Z then return 1 end
  local off = math.abs(x)
  local from, gone = self.halfWidth * 0.62, self.halfWidth * 1.02
  if off <= from then return 1 end
  return AK.Math.Clamp((gone - off) / (gone - from), 0, 1)
end

--- Fade in over the last stretch of a class's own draw range.
---
--- Pulling a draw range back to where the road actually still is on screen is
--- only half a fix: a hard cutoff swaps things sliding in from the side for
--- things popping into existence, which is not obviously better. Everything
--- discrete therefore arrives over the last 30% of its range.
---
--- RenderObjects had this inline and nothing else had it at all, which is why
--- posts, arches, the finish gantry and the crowd were all left drawn out to
--- 200-300m -- depths where, measured (verify-render.js), the road is off the
--- side of the screen more than half the lap.
function RaceUI:DepthFade(dz, far)
  local from = far * 0.70
  if dz <= from then return 1 end
  return AK.Math.Clamp((far - dz) / (far - from), 0, 1)
end

--- On-screen size of something `metres` across, at this depth.
---
--- The floor and ceiling are fractions of the screen, never pixel constants.
--- Trackside objects were clamped to (22, 260) absolute pixels, which is the
--- same mistake that shrank the skyline to specks on a 1440p client: a 260px
--- ceiling is a third of a 720p preview and a tenth of the player's screen, so
--- everything quietly flattened out at high resolution.
--- The FLOOR was set too low when it was made screen-relative. The absolute
--- value it replaced was 22px, which on the 1280-wide reference is 0.034 of a
--- half-screen; 0.012 is barely a third of that, so every distant pickup came
--- out roughly three times smaller than before the change. Rendered against
--- OLDOBJ, that is plainly visible. 0.020 lands near the old 22px on a 2560
--- client while staying resolution-independent, which was the point.
function RaceUI:ObjectSize(pixelsPerMetre, metres)
  return AK.Math.Clamp(pixelsPerMetre * metres, self.halfWidth * 0.020, self.halfWidth * 0.46)
end

--- How much the distance haze has eaten this far out. Shared so an object's
--- shadow fades on exactly the same curve as the road it is sitting on.
function RaceUI:FogAt(dz)
  return AK.Math.Clamp(1 - (dz / HAZE_Z) * self.T.fogStrength, 0.22, 1)
end

--- A lit colour blended toward the colour of the air, `dz` metres out.
---
--- THE ROAD DID THIS. NOTHING STANDING ON IT DID.
---
--- Every trackside thing was tinted `colour * fog`, and fog is a MULTIPLIER --
--- it does not move a colour toward the air, it moves it toward BLACK. So the
--- ground receded correctly into a pale wash while the rocks, trees, posts,
--- pickups and rival karts sitting on that ground got darker and darker, down
--- to the 0.20 floor. Photographed at 300m on Elwynn that is a field of hard
--- black blobs on pale grass, which is exactly backwards: distance drains
--- contrast, it does not add it. It was most of why the far half of the screen
--- read as noise rather than as somewhere further away.
---
--- Same haze colour and same curve the road strips use, published by
--- RenderRoad, so ground and everything on it recede together.
function RaceUI:Aerial(r, g, b, lit, dz)
  r, g, b = r * lit, g * lit, b * lit
  local haze = self.haze
  if not haze then return r, g, b, 1 end
  local mix = (self.hazeCap or 0) * (AK.Math.Clamp(dz / HAZE_Z, 0, 1) ^ 0.85)
  return r + (haze[1] - r) * mix, g + (haze[2] - g) * mix, b + (haze[3] - b) * mix, 1
end

--- Depth-sorted frame level for a trackside thing.
---
--- Everything shares one banding so a nearer object really does draw over a
--- farther kart. Depth is bucketed to 2m and strided by 3 because a kart owns
--- THREE consecutive levels (body / rider / front chassis); `base` separates
--- the categories at equal depth. The whole band must stay under 400, which is
--- where the tag and HUD layers begin -- pushing race content above that once
--- drew karts over the main menu.
local DEPTH_BASE = { shot = 150, object = 152, hazard = 156, kart = 160 }
local DEPTH_BUCKETS = 74

--- Which of the 74 depth buckets this distance falls in, 0 furthest.
---
--- Spread in 1/z, exactly like the road's own strips, and NOT scaled by the
--- draw distance. Two earlier forms each failed by tying this to something
--- else: clamping `FAR_Z - dz` at 148 saturated the whole near field into a
--- single bucket, and dividing by FAR_Z means winding the draw distance out
--- spends three quarters of the buckets on scenery past 150m while the near
--- field -- the only place things actually overlap -- loses its sorting and
--- falls back to creation order. In 1/z half the buckets land inside the first
--- thirty metres, which is where they are needed, and the answer for a given
--- distance in metres is now the same at every setting.
local function depthBucket(dz)
  local near = 1 / (1 + math.max(0, dz) * 0.03)
  return math.floor(AK.Math.Clamp(near, 0, 1) * (DEPTH_BUCKETS - 1))
end

function RaceUI:DepthLevel(kind, dz)
  return self.frame:GetFrameLevel() + (DEPTH_BASE[kind] or 152) + depthBucket(dz) * 3
end

--- Kick the camera. Impacts, boosts and rough ground all route through here.
--- Draw value for a simulated quantity, between its last two simulated states.
---
--- Physics runs in fixed 1/120 slices; the display does not tick at 120Hz, so
--- drawing the raw value draws whichever slice happened to land last. Racing
--- games solve this by drawing BETWEEN the last two states using however much
--- of the current slice has not been simulated yet (`race.alpha`), which is
--- what makes 60fps look like 60fps instead of like 120Hz sampled unevenly.
---
--- `limit` is the largest change one slice can legitimately produce. Anything
--- bigger is a DISCONTINUITY, not motion -- a lap rollover, or a fork setting
--- distance back to zero -- and interpolating across it would fling the kart
--- backwards through the whole track for one frame.
function RaceUI:Lerped(previous, current, alpha, limit)
  if previous == nil or alpha == nil then return current end
  local delta = current - previous
  if delta > limit or delta < -limit then return current end
  return previous + delta * alpha
end

function RaceUI:Shake(amount)
  if AK.db.settings.reducedEffects then return end
  self.shake = math.max(self.shake or 0, amount)
end

-- ---------------------------------------------------------------------------
-- FEEL CHANNELS
--
-- Every camera reaction is an OFFSET added to the tuned baseline at read time
-- and eased back to zero. Nothing here is ever written back into AK.db.tuning,
-- and each channel is snapped hard to zero once it falls under an epsilon.
--
-- Both of those rules exist for one reason: a camera that keeps a fraction of
-- every boost, landing and hit is a camera that has silently moved somewhere
-- else by lap three, and the player cannot tell you why the game stopped
-- feeling right. Easing toward zero asymptotically never actually arrives, so
-- without the snap the residue is real -- small, permanent, and cumulative.
local FEEL_EPSILON = 0.0005

--- Ease a channel toward zero and snap it when it is close enough to gone.
local function decay(value, rate, dt)
  if not value or value == 0 then return 0 end
  value = value * math.max(0, 1 - rate * dt)
  if math.abs(value) < FEEL_EPSILON then return 0 end
  return value
end

--- Add an impulse to a feel channel. Impulses take the LARGER of what is there
--- and what is arriving rather than summing, so a burst of events in the same
--- frame cannot stack into something violent.
function RaceUI:Feel(channel, amount)
  if AK.db.settings.reducedEffects then return end
  self.feel = self.feel or {}
  local current = self.feel[channel] or 0
  if math.abs(amount) > math.abs(current) then self.feel[channel] = amount end
end

--- Being hit: the camera is shoved AWAY from whatever hit you, and the world
--- dips. `side` is -1 or 1, or 0 for a hit with no direction to it.
function RaceUI:FeelHit(side, severity)
  severity = severity or 1
  self:Feel("kickX", -(side or 0) * 26 * severity)
  self:Feel("dip", 0.55 * severity)
  self:Shake(14 * severity)
end

--- You landed one on somebody. Light, bright, and over quickly -- the opposite
--- shape to FeelHit, which is heavy, red and shoves you sideways.
function RaceUI:HitConfirmed()
  local x, y, width = self.playerX or 0, self.playerY or 0, self.playerWidth or 60
  self:PlayEffect("pop", x, y + width * 0.55, width * 1.1, AK.COLORS.lime)
  self:Shake(5)
end

--- Landing. The dip is scaled by how long you were in the air, so a kerb hop
--- and a ramp landing are not the same event.
function RaceUI:FeelLanding(airtime)
  local weight = AK.Math.Clamp((airtime or 0) / 1.1, 0.15, 1)
  self:Feel("dip", 1.5 * weight)
  self:Shake(6 + 10 * weight)
  -- Something hits the ground. A dip and a shake are what the CAMERA does about
  -- it; without a shockwave under the wheels there is nothing at the point of
  -- contact, and a two-second jump ended with the picture wobbling for no
  -- visible reason.
  local x, y, width = self.playerX or 0, self.playerY or 0, self.playerWidth or 60
  self:PlayEffect("shock", x, y + width * 0.08, width * (0.9 + weight * 0.9),
    { 0.92, 0.86, 0.70 })
end

--- Leaving the lip. The landing had a whole beat of its own and the LAUNCH had
--- nothing but a shake -- so a jump began with the kart silently rising, which
--- reads as the camera drifting rather than as being thrown off a ramp.
function RaceUI:FeelLaunch(airtime)
  local weight = AK.Math.Clamp((airtime or 0) / 1.1, 0.2, 1)
  local x, y, width = self.playerX or 0, self.playerY or 0, self.playerWidth or 60
  self:PlayEffect("burst", x, y + width * 0.28, width * (1.5 + weight), AK.COLORS.gold)
  -- Up and away, not down: the opposite channel to the landing's dip, so the
  -- two ends of a jump do not feel like the same event twice.
  self:Feel("push", 1.6 + 1.4 * weight)
  self:Shake(5 + 6 * weight)
end

--- The mini-turbo landing. This is the payoff for the entire drift loop and it
--- has to SNAP: burst, shove, sound, in that order and inside two frames.
--- Anything that ramps here reads as the boost "arriving" rather than firing.
function RaceUI:DriftRelease(tier)
  if (tier or 0) <= 0 then return end
  local x, y, width = self.playerX or 0, self.playerY or 0, self.playerWidth or 60
  -- DRIFT_STAGES is ordered highest-threshold first, so tier 3 is entry 1.
  local hue = DRIFT_STAGES[4 - tier].color
  self:PlayEffect("burst", x, y + width * 0.35, width * (1.4 + tier * 0.5), hue)
  self:Feel("push", 1.6 + tier * 0.9)
  self:Shake(5 + tier * 4)
end

function RaceUI:Build()
  if self.frame then return end
  local frame = CreateFrame("Frame", "AzerothKartRace", UIParent)
  frame:SetAllPoints(UIParent)
  frame:SetFrameStrata("FULLSCREEN_DIALOG")
  frame:EnableKeyboard(true)
  frame:Hide()
  self.frame = frame
  self.T = AK.db.tuning
  self.camDepth = self.T.camDepth
  self.camLateralValue, self.camYawValue = nil, nil
  self.shake, self.shakeX, self.shakeY = 0, 0, 0
  self.previous = {}

  self.sky = makeTexture(frame, "BACKGROUND", { .30, .58, .86, 1 }, 0)
  applyGradient(self.sky, "VERTICAL", .70, .84, .96, 1, .10, .26, .55, 1)
  -- Warm brightening just above the horizon instead of a literal sun quad,
  -- which read as a glowing box.
  self.skyGlow = makeWash(frame, "BACKGROUND", { 1, .88, .62, 1 }, 1)
  applyGradient(self.skyGlow, "VERTICAL", 1, .86, .55, 0, 1, .92, .70, .40)

  -- Clouds as thin banded haze. Wide, soft and low contrast reads as sky depth;
  -- fat opaque quads read as floating bricks.
  -- The Oribos ring, hung on the horizon and parallaxed against the curve.
  self.ring = makeTexture(frame, "BACKGROUND", { 1, 1, 1, 1 }, 2, "ring.tga")
  self.ring:Hide()

  -- Drive-through arches. Pooled and projected like any other track object, so
  -- they scale up and pass overhead as you reach them.
  self.arches = {}
  for i = 1, 4 do
    local arch = makeTexture(frame, "ARTWORK", { 1, 1, 1, 1 }, 3, "arch.tga")
    arch:Hide()
    self.arches[i] = arch
  end

  -- Real cloud art with a soft alpha edge, not banded quads.
  self.clouds = {}
  for i = 1, 14 do
    self.clouds[i] = makeTexture(frame, "BACKGROUND", { 1, 1, 1, 1 }, 2, "cloud.tga")
  end

  -- Distant terrain: a far mountain ridge and a mid hill line, each one
  -- horizontally-wrapping texture spanning the full screen. Created after the
  -- clouds so they draw over them, under the tree wall. These two layers plus
  -- their differing parallax rates are what turn "a row of cones on a seam"
  -- into a world with depth.
  self.mountain = frame:CreateTexture(nil, "BACKGROUND", nil, 2)
  self.mountain:SetTexture(ART .. "mountain.tga", "REPEAT", "CLAMP")
  self.mountain:Hide()
  self.hillLine = frame:CreateTexture(nil, "BACKGROUND", nil, 2)
  self.hillLine:SetTexture(ART .. "hills.tga", "REPEAT", "CLAMP")
  self.hillLine:Hide()

  -- Treeline built from actual conifer silhouettes.
  --
  -- Evenly spaced, near-identical trees read as a picket fence -- which is
  -- exactly what the offline renders showed: a row of clones at one pitch with
  -- every third one shorter. So each slot gets a fixed personality: its own
  -- horizontal offset, height, width and depth. It is drawn once, here, rather
  -- than re-derived from sin() every frame, because none of it ever changes.
  local function jitter(i, a, b)
    local v = math.sin(i * a) * b
    return v - math.floor(v)
  end
  self.trees = {}
  self.treeSeed = {}
  for i = 1, TREES do
    self.trees[i] = makeTexture(frame, "BACKGROUND", { 1, 1, 1, 1 }, 3, "tree.tga")
    self.treeSeed[i] = {
      x = jitter(i, 12.9898, 43758.5453) - 0.5,   -- offset within its own slot
      h = jitter(i, 78.2330, 24634.6345),         -- height
      w = jitter(i, 45.1640, 15731.7430),         -- width
      d = jitter(i, 94.6730, 39871.2930),         -- depth: 0 near, 1 far
    }
  end

  self.ground = makeTexture(frame, "BACKGROUND", { .16, .40, .18, 1 }, 4)
  -- THE HORIZON HAZE, IN TWO HALVES.
  --
  -- It used to be one texture with one gradient, and SetGradient has exactly
  -- two stops: alpha 0 at one edge, half at the other. So the thing whose whole
  -- job was to soften the ground-meets-sky seam ended in a hard cut of its own,
  -- at 50% opacity, a hand's width above the horizon -- a pale band ruled
  -- straight across every circuit in the game. Measured on an Oribos frame it
  -- was twelve pixels of (70,63,113) between a (62,36,90) sky and a (46,54,72)
  -- ground: lighter than either, and nothing in the world is there.
  --
  -- Two textures meeting at the horizon fade to nothing at BOTH outer edges,
  -- which is what atmosphere actually does.
  -- Built white; the track's palette tints them and RE-APPLIES the gradient,
  -- because SetVertexColor and SetGradient are the same state and the second
  -- one to run wins. See the note where the palette is applied.
  self.hazeBelow = makeTexture(frame, "BORDER", { 1, 1, 1, .32 }, 3)
  applyGradient(self.hazeBelow, "VERTICAL", 1, 1, 1, 0, 1, 1, 1, .3)
  self.hazeAbove = makeTexture(frame, "BORDER", { 1, 1, 1, .32 }, 3)
  applyGradient(self.hazeAbove, "VERTICAL", 1, 1, 1, .3, 1, 1, 1, 0)

  -- One strip of textures per road segment, reused every frame.
  -- Built far-to-near: textures in the same layer draw in creation order, and
  -- with hills the nearer strip has to paint over the farther one or a crest
  -- will not hide the road behind it.
  self.strips = {}
  for i = SEGMENTS, 1, -1 do
    self.strips[i] = {
      -- Every one of these is drawn with WORLD-LOCKED texcoords (distance /
      -- tile-size), so at 1150m along a lap the V range is ~230..231 -- and a
      -- texcoord above 1 CLAMPS unless the texture was created with REPEAT
      -- wrapping. Without it the whole quad samples a single edge pixel: the
      -- road and grass art never tiled at all in game (the road only looked
      -- patterned because of the per-strip light/dark banding), and the tunnel
      -- walls sampled one pixel of rock, which is why covered sections had no
      -- walls in them. The offline preview blits with real tiling, which is why
      -- it has always looked better than the game it is supposed to mirror.
      grass = makeTexture(frame, "BACKGROUND", { .16, .40, .18, 1 }, 5, "grass.tga", true),
      road = makeTexture(frame, "ARTWORK", { .34, .34, .38, 1 }, 0, "road.tga", true),
      -- Diagonals, not rectangles -- see makeEdge. These three are the only
      -- things on the road plane narrow enough for the strip staircase to show.
      rumbleLeft = makeEdge(frame, "ARTWORK", { .90, .22, .18, 1 }, 1),
      rumbleRight = makeEdge(frame, "ARTWORK", { .90, .22, .18, 1 }, 1),
      lane = makeEdge(frame, "ARTWORK", { .95, .95, .95, 1 }, 2),
      -- Darkens toward both verges so the road reads as a lit solid rather
      -- than a flat cut-out.
      shade = makeTexture(frame, "ARTWORK", { 1, 1, 1, 1 }, 3, "roadshade.tga"),
      -- Covered sections. Hidden on open road, which is most of the time.
      -- Sublevel 7: ABOVE the full-screen surround fill at 6, so the converging
      -- portal still reads once you are properly under cover.
      wallLeft = makeTexture(frame, "BACKGROUND", { 1, 1, 1, 1 }, 7, "rock.tga", true),
      wallRight = makeTexture(frame, "BACKGROUND", { 1, 1, 1, 1 }, 7, "rock.tga", true),
      ceiling = makeTexture(frame, "BACKGROUND", { 1, 1, 1, 1 }, 7, "rock.tga", true),
    }
  end

  -- The alternate ribbon at a fork. Fewer strips than the main road because it
  -- is only ever drawn for the stretch between the split and the horizon.
  self.forkStrips = {}
  for i = FORK_SEGMENTS, 1, -1 do
    self.forkStrips[i] = {
      -- World-locked texcoords here too (see the main strips above), so this
      -- needs REPEAT wrapping or the branch road clamps to one pixel.
      road = makeTexture(frame, "ARTWORK", { .34, .34, .38, 1 }, 4, "road.tga", true),
      edgeLeft = makeEdge(frame, "ARTWORK", { 1, 1, 1, 1 }, 5),
      edgeRight = makeEdge(frame, "ARTWORK", { 1, 1, 1, 1 }, 5),
    }
  end
  -- The sign at the split. A fork you cannot see coming is just a wall.
  self.forkSign = makeTexture(frame, "OVERLAY", { 1, 1, 1, 1 }, 4, "forkleft.tga")
  self.forkSign:Hide()
  self.forkLabel = UI:NewText(frame, "", 15, AK.COLORS.lime, "CENTER")
  self.forkLabel:Hide()
  self.forkArrow = frame:CreateTexture(nil, "OVERLAY")
  self.forkArrow:SetTexture(ART .. "chevron.tga")
  self.forkArrow:SetSize(10, 14)
  self.forkArrow:SetVertexColor(unpack(AK.COLORS.lime))
  self.forkArrow:Hide()

  -- When the camera is inside a tunnel there is rock in every direction, not
  -- just the ribbon receding ahead. The per-band walls draw the portal from
  -- outside; these three fill the rest of the screen once you are through it.
  self.surround = {
    -- Sublevel 6: above the grass (5), below the per-band walls (7).
    left = makeTexture(frame, "BACKGROUND", { 1, 1, 1, 1 }, 6, "rock.tga", true),
    right = makeTexture(frame, "BACKGROUND", { 1, 1, 1, 1 }, 6, "rock.tga", true),
    top = makeTexture(frame, "BACKGROUND", { 1, 1, 1, 1 }, 6, "rock.tga", true),
  }
  for _, region in pairs(self.surround) do region:Hide() end

  -- Roadside props: the scenery that actually comes AT you.
  --
  -- The "trees" above are skyline decoration pinned to the horizon; they drift
  -- but never approach, which is why the world read as a painted backdrop. A
  -- kart racer sells speed with solid objects rushing past just outside the
  -- verge, at real parallax. That is what these are.
  self.props = {}
  for i = 1, PROPS do
    local prop = CreateFrame("Frame", nil, frame)
    prop.art = prop:CreateTexture(nil, "ARTWORK")
    prop.art:SetAllPoints()
    prop.shadow = prop:CreateTexture(nil, "BACKGROUND")
    prop.shadow:SetTexture(ART .. "shadow.tga")
    prop:Hide()
    self.props[i] = prop
  end

  -- Roadside marker posts. Regular objects rushing past the edge of frame are
  -- the strongest speed cue available; the road surface alone reads as static.
  self.posts = {}
  for i = 1, 24 do
    self.posts[i] = {
      left = makeTexture(frame, "ARTWORK", { 1, 1, 1, 1 }, 3),
      right = makeTexture(frame, "ARTWORK", { 1, 1, 1, 1 }, 3),
    }
  end

  -- Start/finish line: a checkered band plus an overhead gantry.
  self.finish = CreateFrame("Frame", nil, frame)
  self.finish:SetSize(1, 1)
  self.finish:Hide()
  self.finish.blocks = {}
  for i = 1, 28 do
    self.finish.blocks[i] = makeTexture(self.finish, "ARTWORK", { 1, 1, 1, 1 }, 4)
  end
  self.finish.leftPost = makeTexture(self.finish, "ARTWORK", { .82, .84, .90, 1 }, 5)
  self.finish.rightPost = makeTexture(self.finish, "ARTWORK", { .82, .84, .90, 1 }, 5)
  self.finish.banner = makeTexture(self.finish, "ARTWORK", { .10, .14, .22, 1 }, 5)
  self.finish.bannerEdge = makeTexture(self.finish, "OVERLAY", AK.COLORS.gold, 0)
  self.finish.label = UI:NewText(self.finish, "FINISH", 14, AK.COLORS.gold, "CENTER")
  self.finish.label:SetShadowColor(0, 0, 0, 1)
  self.finish.label:SetShadowOffset(1, -1)

  -- ROADSIDE CROWD.
  --
  -- Every one of them used to be Baine, sitting down -- the same seated model
  -- the karts use, the same creature, six of them, all the way round every
  -- circuit of every track. The joke was over some time before the third lap.
  --
  -- The crowd is drawn from the racer roster instead. Two reasons, and the
  -- second is the load-bearing one: it is thematic (the drivers who are not in
  -- this race came to watch), and every id in it is a creature the game already
  -- renders somewhere, so the crowd cannot be a row of blanks the way a guessed
  -- list of npc ids would be. Each SEAT keeps one creature for the whole race
  -- -- a model reload costs a stutter, and the rolling window would otherwise
  -- hand every seat a new one every forty-two metres -- while the POSE varies
  -- by position, which is free, so the same face is not doing the same thing at
  -- every post down the road.
  self.spectators = {}
  for i = 1, SPECTATOR_SLOTS do
    local seat = CreateFrame("Frame", nil, frame)
    seat:SetSize(60, 60)
    seat.model = AK.Model:New(seat, 60, 60, 0, 1, nil, AK.MODEL.anim.cheer)
    seat.model:SetAllPoints()
    self.spectators[i] = seat
  end

  self.speedLines = {}
  for i = 1, 22 do
    local line = makeGlow(frame, "OVERLAY", { .85, .95, 1, 1 }, 3)
    line:SetAlpha(0)
    self.speedLines[i] = line
  end

  -- Screen-space particle pool: drift sparks, boost embers, dust, impacts.
  self.particlePool = {}
  self.particles = {}
  for i = 1, PARTICLES do
    local particle = makeGlow(frame, "OVERLAY", { 1, 1, 1, 1 }, 4, "spark.tga")
    particle:Hide()
    self.particlePool[i] = particle
  end

  -- Weather layer. These persist and wrap rather than being spawned and killed,
  -- which keeps a steady downpour from thrashing the particle pool.
  self.weather = {}
  for i = 1, 90 do
    local drop = makeTexture(frame, "OVERLAY", { 1, 1, 1, 1 }, 2)
    drop:Hide()
    self.weather[i] = { texture = drop, x = 0, y = 0, speed = 0, sway = 0, size = 1 }
  end

  -- A single radial vignette reads far better than two gradient bands.
  self.vignette = makeTexture(frame, "OVERLAY", { 1, 1, 1, 1 }, 5, "vignette.tga")
  self.vignette:SetAllPoints()

  self.boostTint = makeWash(frame, "OVERLAY", { 1, .72, .25, 1 }, 6)
  self.boostTint:SetAllPoints()
  self.boostTint:SetAlpha(0)

  self.flash = makeTexture(frame, "OVERLAY", { 1, 1, 1, 0 }, 7)
  self.flash:SetAllPoints()
  self.flash:SetAlpha(0)

  -- Final-lap urgency: a gold pulse in the corners, on the last lap only.
  -- A full-screen wash, so it belongs on the race frame beside the vignette
  -- rather than on the HUD layer.
  self.urgency = makeTexture(frame, "OVERLAY", { 1, .82, .30, 1 }, 6, "vignette.tga")
  self.urgency:SetAllPoints()
  self.urgency:SetBlendMode("ADD")
  self.urgency:SetAlpha(0)

  -- Chequered flash at the line, built from alternating cells rather than art.
  self.checker = {}
  for i = 1, 24 do
    self.checker[i] = makeTexture(frame, "OVERLAY", { 1, 1, 1, 1 }, 7)
    self.checker[i]:Hide()
  end

  -- ---- HUD ---------------------------------------------------------------
  --
  -- Everything below hangs off self.hud, which is scaled as one piece by
  -- RaceUI:LayoutHud(). See the HUD table at the top of the file for why.
  self.hud = CreateFrame("Frame", nil, frame)
  self.hud:SetAllPoints()
  local hud = self.hud

  -- WHICH LAP -- top left. The lap you are on is the thing you glance at most
  -- and it used to be 15pt text buried in the middle of a bar of eight
  -- readouts, which is why nobody could find it.
  local lapPanel = UI:NewPanel(hud, HUD.lap.w, HUD.lap.h, HUD_PANEL)
  lapPanel:SetPoint(HUD.lap.point, HUD.lap.x, HUD.lap.y)
  self.headerPanel = lapPanel
  -- The word is LAP on a circuit and BALLOONS in an arena. Battle mode had no
  -- readout of its own at all: this panel said "LAP 1 / 999" -- the sentinel
  -- lap count that stops a battle ever ending by distance, printed on the HUD
  -- -- while the one number the whole mode turns on, how many balloons you have
  -- left, was announced in a banner for two seconds and then gone forever.
  self.lapWord = UI:NewText(lapPanel, "LAP", 12, AK.COLORS.gold, "LEFT")
  self.lapWord:SetPoint("TOPLEFT", 14, -9)
  self.lap = UI:NewText(lapPanel, "1 / 3", 27, { .95, .96, 1 }, "LEFT")
  self.lap:SetPoint("TOPLEFT", LAP_NUMBER_X, -4)
  -- One pip per lap, filling as you complete them: the count in the abstract is
  -- a number to read, the pips are a progress bar you take in without reading.
  -- In a battle they are the balloons themselves, and they empty rather than
  -- fill, which is the same glance answering a different question.
  self.lapPips = {}
  for i = 1, 5 do
    local pip = makeTexture(lapPanel, "OVERLAY", { .25, .32, .42, 1 })
    pip:SetSize(30, 5)
    pip:SetPoint("BOTTOMLEFT", 14 + (i - 1) * 34, 11)
    self.lapPips[i] = pip
  end

  -- WHAT ITEM -- top centre, where Mario Kart has always put it, and big enough
  -- to read the icon in peripheral vision. It used to be a 120px box in the
  -- corner with the words "NO ITEM" printed in it, which is a form field.
  local itemPanel = UI:NewPanel(hud, HUD.item.w, HUD.item.h, HUD_PANEL)
  itemPanel:SetPoint(HUD.item.point, HUD.item.x, HUD.item.y)
  self.itemPanel = itemPanel
  self.itemGlow = makeWash(itemPanel, "BACKGROUND", { 1, .82, .25, 1 })
  self.itemGlow:SetPoint("TOPLEFT", 3, -3)
  self.itemGlow:SetPoint("BOTTOMRIGHT", -3, 3)
  self.itemGlow:SetAlpha(0)
  self.itemIcon = itemPanel:CreateTexture(nil, "ARTWORK")
  self.itemIcon:SetSize(ITEM_ICON, ITEM_ICON)
  self.itemIcon:SetPoint("CENTER", 0, 7)
  -- An empty slot is a dim empty frame, not a caption. The label carries the
  -- one thing an icon cannot: how many are left, and "FIRE!" when one is armed.
  self.itemLabel = UI:NewText(itemPanel, "", 12, AK.COLORS.muted, "CENTER")
  self.itemLabel:SetPoint("BOTTOMLEFT", 5, 9)
  self.itemLabel:SetPoint("BOTTOMRIGHT", -5, 9)

  -- THE CLOCK -- top right. Reference material: you look at it between corners,
  -- never during one, so it gets the corner furthest from the racing line.
  local clockPanel = UI:NewPanel(hud, HUD.clock.w, HUD.clock.h, HUD_PANEL)
  clockPanel:SetPoint(HUD.clock.point, HUD.clock.x, HUD.clock.y)
  self.clockPanel = clockPanel
  -- Three rows, all right-aligned off the same edge. Sharing one row between a
  -- left-aligned speed and a right-aligned split meant the two grew toward each
  -- other and, on a long lap time, straight through each other.
  self.timer = UI:NewText(clockPanel, "00:00.000", 22, { .95, .96, 1 }, "RIGHT")
  self.timer:SetPoint("TOPRIGHT", -14, -8)
  self.lapTime = UI:NewText(clockPanel, "", 11, AK.COLORS.muted, "RIGHT")
  self.lapTime:SetPoint("TOPRIGHT", -14, -38)
  self.speed = UI:NewText(clockPanel, "0 km/h", 13, AK.COLORS.lime, "RIGHT")
  self.speed:SetPoint("TOPRIGHT", -14, -56)

  -- WHAT PLACE -- bottom left, and by a wide margin the largest thing on the
  -- screen. This is the single most Mario Kart element there is and it was a
  -- 30pt string sharing a bar with the speedometer. No panel behind it: a plate
  -- reads as an addon window, where bare outlined type reads as a game. A soft
  -- dark halo does the legibility work a plate was doing.
  self.placeGlow = makeTexture(hud, "BACKGROUND", { 0, 0, 0, 1 }, 0, "glow.tga")
  self.placeGlow:SetSize(HUD.place.w, HUD.place.h)
  self.placeGlow:SetPoint("BOTTOMLEFT", HUD.place.x - 46, HUD.place.y - 34)
  self.placeGlow:SetAlpha(0.55)
  self.position = UI:NewText(hud, "1ST", 58, AK.COLORS.gold, "LEFT")
  self.position:SetPoint("BOTTOMLEFT", HUD.place.x, HUD.place.y + 20)
  self.position:SetShadowColor(0, 0, 0, 1)
  self.position:SetShadowOffset(2, -2)
  self.positionOf = UI:NewText(hud, "/ 8", 14, AK.COLORS.muted, "LEFT")
  self.positionOf:SetPoint("BOTTOMLEFT", HUD.place.x + 3, HUD.place.y)

  -- THE MAP -- bottom right, mirroring the place readout. It used to spend a
  -- fifth of its own height on a caption reading "TRACK MAP".
  self.minimapPanel = UI:NewPanel(hud, HUD.map.w, HUD.map.h, HUD_PANEL)
  self.minimap = self.minimapPanel
  self.minimap:SetPoint(HUD.map.point, HUD.map.x, HUD.map.y)
  self.mapRoute = {}
  -- 72 rather than 48. Forty-eight dots were plenty around the ellipse the map
  -- used to be; the circuits have real shapes now, with hairpins and esses, and
  -- at 48 those read as a scatter of marks rather than as a route.
  for i = 1, 72 do
    local node = self.minimap:CreateTexture(nil, "ARTWORK")
    node:SetTexture("Interface\\Buttons\\WHITE8x8")
    node:SetVertexColor(.32, .44, .58, .95)
    node:SetSize(5, 5)
    self.mapRoute[i] = node
  end
  self.mapDots = {}
  for i = 1, AK.MAX_RACERS do
    local dot = self.minimap:CreateTexture(nil, "OVERLAY")
    dot:SetTexture("Interface\\Buttons\\WHITE8x8")
    dot:SetSize(8, 8)
    self.mapDots[i] = dot
  end

  -- DRIFT CHARGE -- a thin bar low and centred, right under the kart, so it can
  -- be read without moving your eyes off the corner you are drifting through.
  -- It used to be a 260px plate with the words "DRIFT BOOST" printed across it
  -- at all times, and "RELEASE FOR BOOST" while charging: a tutorial pinned to
  -- the screen for the whole race. The bar shows the charge; the label now only
  -- names the tier you have actually banked, which is the part you cannot infer.
  local driftPanel = UI:NewPanel(hud, HUD.drift.w, HUD.drift.h, { .02, .04, .08, .78 })
  driftPanel:SetPoint(HUD.drift.point, HUD.drift.x, HUD.drift.y)
  self.driftPanel = driftPanel
  local driftInner = HUD.drift.h - 8
  self.driftFill = makeTexture(driftPanel, "ARTWORK", AK.COLORS.lime)
  self.driftFill:SetPoint("LEFT", 4, 0)
  self.driftFill:SetHeight(driftInner)
  self.driftFill:SetWidth(0)
  self.driftGlow = makeWash(driftPanel, "ARTWORK", { 1, 1, 1, 1 }, 1)
  self.driftGlow:SetPoint("LEFT", 4, 0)
  self.driftGlow:SetHeight(driftInner)
  self.driftGlow:SetWidth(0)
  self.driftGlow:SetAlpha(0)
  self.driftLabel = UI:NewText(driftPanel, "", 13, AK.COLORS.gold, "CENTER")
  self.driftLabel:SetPoint("BOTTOM", driftPanel, "TOP", 0, 5)
  -- Ticks at the three tier thresholds, so the bar reads as a ladder with rungs
  -- rather than as a bar that changes colour for reasons.
  self.driftTicks = {}
  for i, stage in ipairs(DRIFT_TICKS) do
    local tick = makeTexture(driftPanel, "OVERLAY", { .08, .13, .20, 1 })
    tick:SetSize(2, driftInner)
    tick:SetPoint("LEFT", 4 + DRIFT_TRACK * stage, 0)
    self.driftTicks[i] = tick
  end

  -- Surface and effect state, stacked under the place readout rather than over
  -- the middle of the road. Centred above the drift meter it landed squarely on
  -- the player's own kart, and the bigger the client the worse it got: the kart
  -- is drawn in world space and grows with the resolution, so at 1440p "TURBO!"
  -- was printed across the driver. Bottom left is empty, and the eye is already
  -- there reading the position.
  self.status = UI:NewText(hud, "", 15, AK.COLORS.muted, "LEFT")
  self.status:SetPoint("BOTTOMLEFT", HUD.place.x + 3, HUD.place.y - 26)

  -- Track identity, tucked under the lap block rather than centred in the road.
  self.trackName = UI:NewText(hud, "", 13, { .72, .62, .40 }, "LEFT")
  self.trackName:SetPoint("TOPLEFT", lapPanel, "BOTTOMLEFT", 3, -7)
  -- The shortcut blurb, under the item box. It is race-start onboarding -- it
  -- fades out once you are driving -- so it belongs where you are looking
  -- before the lights go out, not across the bottom of the road.
  --
  -- Width-bounded, whatever else moves. Centred on the drift meter with no
  -- width set, it grew outward from its anchor until it ran under the BRAKE and
  -- GAS buttons flanking the meter, and Netherstorm's "SHORTCUT: Blink through
  -- a portal at maximum speed" was cut off mid-word. A fontstring with no width
  -- has no reason to stop.
  self.shortcut = UI:NewText(hud, "", 12, { .9, .92, 1 }, "CENTER")
  self.shortcut:SetPoint("TOP", itemPanel, "BOTTOM", 0, -10)
  self.shortcut:SetWidth(HUD_DESIGN_W * 0.44)
  -- Announcements sat at -250, which is exactly where the player's own kart is
  -- drawn -- and a model frame paints over its parent's fontstrings, so every
  -- "ITEM ACQUIRED" and "BOOST!" was rendering behind the driver. They now live
  -- in a layer above every model, high on screen where nothing can cover them.
  -- A child of the SCALED container, so the countdown, the lap banners and the
  -- FINISHED card are the same size relative to the screen as everything else.
  -- Frame level is absolute within a strata, so the explicit level below still
  -- puts it above the field regardless of who its parent is.
  self.hudLayer = CreateFrame("Frame", nil, hud)
  self.hudLayer:SetAllPoints()
  -- Above the whole depth-sorted field, which tops out at +382.
  self.hudLayer:SetFrameLevel(frame:GetFrameLevel() + 420)

  -- ---- presentation layer ----------------------------------------------
  --
  -- The race had no orchestrated moments: the countdown, the start, the final
  -- lap and the finish were all the same line of centred text. These are the
  -- beats that make a lap feel like an event. They sit on the HUD layer, are
  -- sized from the screen every frame rather than in fixed pixels, and drive
  -- the existing Announce/Flash/Shake plumbing instead of duplicating it.
  --
  -- Start gantry: three lamps that light one per countdown tick and go green
  -- together on GO. A countdown you can SEE beats a number you have to read.
  --
  -- IT IS THE FIRST THING YOU SEE, EVERY SINGLE RACE.
  --
  -- And it was a black rectangle with three red smudges on it: a raw SOLID
  -- quad and three additive blobs, square-cornered, floating in the sky above
  -- the horizon. Nothing else in this game looks like that -- every panel the
  -- player meets in the menus is a rounded plate with a warm edge -- so the
  -- one piece of furniture that opens the race looked like a placeholder
  -- somebody meant to come back to.
  --
  -- It is a plated housing now, with a bezel round each lamp and a dark bulb
  -- behind it, so an unlit lamp reads as a lamp that is off rather than as an
  -- absence, and a lit one has something solid to be bright against.
  self.startLights = UI:NewPanel(self.hudLayer, HUD.lights.w, HUD.lights.h,
    { .05, .06, .09, .96 })
  self.startLights:Hide()
  self.startLights.lamps = {}
  self.startLights.bulbs = {}
  self.startLights.bezels = {}
  for i = 1, 3 do
    -- The bulb: a dark disc, so the lamp has a body when it is not lit.
    local bulb = makeTexture(self.startLights, "ARTWORK", { .07, .07, .09, 1 }, 1, "glow.tga")
    self.startLights.bulbs[i] = bulb
    -- The light itself, additive over the bulb.
    self.startLights.lamps[i] = makeGlow(self.startLights, "ARTWORK", { 1, .22, .18, 1 }, 2)
    -- And the rim that holds it, so three lamps read as three fittings in a
    -- gantry rather than three coloured stains on a board.
    local bezel = makeTexture(self.startLights, "OVERLAY", { .46, .50, .58, 1 }, 0, "socket.tga")
    self.startLights.bezels[i] = bezel
  end

  -- Lap split against your best, shown for a couple of seconds on each cross.
  self.splitText = UI:NewText(self.hudLayer, "", 20, AK.COLORS.lime, "CENTER")
  self.splitText:SetShadowColor(0, 0, 0, 1)
  self.splitText:SetShadowOffset(1, -1)
  self.splitText:SetAlpha(0)

  -- "FINISHED 2ND", held long enough to land before the results screen.
  --
  -- ON A PLATE, like every other card in this game. This was forty points of
  -- gold with a two-pixel shadow and nothing behind it, landed in the middle of
  -- the screen -- which is exactly where the kart is, and the kart is a pale
  -- tan rider three hundred pixels tall. The single most important line the
  -- race ever prints was being read off the back of the thing it was printed
  -- over. The notice banner has had a plate the whole time; this is the same
  -- plate, sized to whatever the card says, because a photo finish is two lines
  -- and a placing is one.
  self.finishPlate = makeTexture(self.hudLayer, "BACKGROUND", { 0.01, 0.02, 0.04, 1 })
  self.finishPlate:SetPoint("CENTER", self.frame, "CENTER", 0, 0)
  self.finishPlate:SetSize(2, 2)
  self.finishPlate:Hide()
  self.finishEdge = makeTexture(self.hudLayer, "BORDER", AK.COLORS.gold)
  self.finishEdge:SetPoint("TOP", self.finishPlate, "BOTTOM", 0, 0)
  self.finishEdge:SetSize(2, 2)
  self.finishEdge:Hide()
  self.finishCard = UI:NewText(self.hudLayer, "", 40, AK.COLORS.gold, "CENTER")
  self.finishCard:SetShadowColor(0, 0, 0, 1)
  self.finishCard:SetShadowOffset(2, -2)
  self.finishCard:SetAlpha(0)

  -- THE FINISHING LADDER.
  --
  -- Crossing the line no longer ends the race -- the field still has to come
  -- home -- so there has to be somewhere to watch it happen. Eight rows, one
  -- per racer, placed in finishing order as each kart crosses: the ones who are
  -- already in show their time, the ones still out there show a dash and their
  -- gap. It slides in from the right on the flag and stays until the results
  -- screen takes over. This is the bit that turns "the race is over, here is a
  -- table" into "you won -- now watch the rest of them scrap for second".
  -- The cooldown lap winds on to as much as twelve times real speed once the
  -- honest beat and a half is over, and a road going past at that rate is not
  -- something anyone wants to watch. The scene recedes behind a scrim in step
  -- with the dilation, which puts the ladder where the eye should be anyway.
  -- On the HUD layer, so it dims the instruments too; the ladder is a child
  -- frame of the same layer and therefore stays above it.
  self.cooldownScrim = makeTexture(self.hudLayer, "BACKGROUND", { 0.01, 0.02, 0.05, 1 }, 0)
  self.cooldownScrim:SetAllPoints()
  self.cooldownScrim:SetAlpha(0)

  -- THE RECOVERY VEIL.
  --
  -- Going off the course repositions the kart -- up to a full respawn spacing
  -- BACKWARDS -- in a single simulation tick, and nothing in the renderer knew
  -- it had happened. The whole world jump-cut, mid-corner, with the camera
  -- still glued to a kart that was suddenly somewhere else. That is the
  -- awkward teleport, and it cannot be smoothed out by moving the camera:
  -- there is nothing continuous between the two places.
  --
  -- So it is hidden. The screen closes over the reposition and opens again
  -- with the kart already set down, which is what every game that has ever
  -- picked a player up and put them back does. Above the world and above the
  -- HUD, because for that moment you are out of play.
  self.recoveryVeil = makeTexture(self.hudLayer, "OVERLAY", { 0.02, 0.03, 0.06, 1 }, 6)
  self.recoveryVeil:SetAllPoints()
  self.recoveryVeil:SetAlpha(0)

  self.ladder = CreateFrame("Frame", nil, self.hudLayer)
  self.ladder:SetSize(LADDER.w, LADDER.h)
  self.ladder:SetPoint("RIGHT", -30, 20)
  self.ladder:Hide()
  self.ladderPlate = makeTexture(self.ladder, "BACKGROUND", { .02, .04, .08, .86 }, 0)
  self.ladderPlate:SetAllPoints()
  self.ladderEdge = makeTexture(self.ladder, "BACKGROUND", AK.COLORS.gold, 1)
  self.ladderEdge:SetPoint("TOPLEFT", 0, 0)
  self.ladderEdge:SetPoint("TOPRIGHT", 0, 0)
  self.ladderEdge:SetHeight(2)
  self.ladderTitle = UI:NewText(self.ladder, "FINISHING ORDER", 12, AK.COLORS.gold, "LEFT")
  self.ladderTitle:SetPoint("TOPLEFT", 12, -10)
  self.ladderRows = {}
  for i = 1, AK.MAX_RACERS do
    local row = CreateFrame("Frame", nil, self.ladder)
    row:SetSize(LADDER.w - 16, LADDER.row)
    row:SetPoint("TOPLEFT", 8, -(LADDER.top + (i - 1) * LADDER.row))
    row.bg = makeTexture(row, "BACKGROUND", { .07, .10, .16, .0 }, 2)
    row.bg:SetAllPoints()
    row.tag = makeTexture(row, "ARTWORK", { .3, .36, .46, 1 }, 0)
    row.tag:SetSize(3, LADDER.row - 5)
    row.tag:SetPoint("LEFT", 2, 0)
    row.place = UI:NewText(row, "", 12, AK.COLORS.muted, "LEFT")
    row.place:SetPoint("LEFT", 10, 0)
    row.place:SetWidth(30)
    row.name = UI:NewText(row, "", 12, { .88, .91, 1 }, "LEFT")
    row.name:SetPoint("LEFT", 42, 0)
    -- 120 wide for a column that has to hold "Illidan Stormrage", which is
    -- about 126 at twelve point -- so the longest name on the grid wrapped to a
    -- second line inside a twenty-two pixel row. The gap column only needs
    -- about 52 for "1:44.21" and had 78, so the room came from there.
    row.name:SetWidth(LADDER.w - 112)
    row.time = UI:NewText(row, "", 12, AK.COLORS.muted, "RIGHT")
    row.time:SetPoint("RIGHT", -10, 0)
    row:Hide()
    self.ladderRows[i] = row
  end

  self.wrongWay = UI:NewText(self.hudLayer, "", 30, AK.COLORS.danger, "CENTER")
  self.wrongWay:SetShadowColor(0, 0, 0, 1)
  self.wrongWay:SetShadowOffset(2, -2)
  self.wrongWay:SetAlpha(0)

  -- Names the beat currently playing during /kart beats. It has to be on
  -- screen: the race frame eats keyboard input, so the chat window is behind
  -- the race and unreadable exactly when this matters.
  self.beatLabel = UI:NewText(self.hudLayer, "", 15, AK.COLORS.blue, "CENTER")
  self.beatLabel:SetShadowColor(0, 0, 0, 1)
  self.beatLabel:SetShadowOffset(1, -1)
  self.beatLabel:SetAlpha(0)
  self.spinyWarn = UI:NewText(self.hudLayer, "", 26, AK.COLORS.danger, "CENTER")
  self.spinyWarn:SetShadowColor(0, 0, 0, 1)
  self.spinyWarn:SetShadowOffset(2, -2)
  self.spinyWarn:SetAlpha(0)

  self.noticePlate = makeTexture(self.hudLayer, "BACKGROUND", { 0, 0, 0, .55 })
  placeHud(self.noticePlate, HUD.notice)
  self.noticePlate:Hide()
  self.noticeEdge = makeTexture(self.hudLayer, "BORDER", AK.COLORS.gold)
  self.noticeEdge:SetPoint("TOP", self.noticePlate, "BOTTOM", 0, 0)
  self.noticeEdge:Hide()
  self.notice = UI:NewText(self.hudLayer, "", 30, AK.COLORS.gold, "CENTER")
  placeHud(self.notice, HUD.notice, "centre")
  self.notice:SetShadowColor(0, 0, 0, 1)
  self.notice:SetShadowOffset(2, -2)
  -- Item icon that pops alongside the banner when something is used.
  self.noticeIcon = self.hudLayer:CreateTexture(nil, "ARTWORK")
  self.noticeIcon:SetPoint("RIGHT", self.notice, "LEFT", -12, 0)
  self.noticeIcon:Hide()
  self.countdown = UI:NewText(frame, "", 74, AK.COLORS.gold, "CENTER")
  self.countdown:SetPoint("CENTER", 0, 40)
  self.countdown:SetShadowColor(0, 0, 0, 1)
  self.countdown:SetShadowOffset(3, -3)

  -- Starting lights. Three reds arm one per second, then all snap green on GO.
  self.lights = {}
  self.lightRig = UI:NewPanel(frame, 214, 62, { .02, .03, .06, .92 })
  self.lightRig:SetPoint("CENTER", 0, 150)
  self.lightRig:Hide()
  for i = 1, 3 do
    local housing = makeTexture(self.lightRig, "ARTWORK", { .06, .07, .10, 1 })
    housing:SetSize(54, 44)
    housing:SetPoint("LEFT", 10 + (i - 1) * 66, 0)
    local lamp = makeTexture(self.lightRig, "OVERLAY", { .16, .05, .05, 1 }, 1)
    lamp:SetSize(42, 32)
    lamp:SetPoint("CENTER", housing, "CENTER")
    local halo = makeGlow(self.lightRig, "OVERLAY", { 1, .2, .15, 1 }, 2)
    halo:SetSize(74, 60)
    halo:SetPoint("CENTER", housing, "CENTER")
    halo:SetAlpha(0)
    self.lights[i] = { lamp = lamp, halo = halo }
  end

  -- Name tags live in their own frame above every kart. A PlayerModel is a
  -- child frame, and child frames always draw over their parent's layers, so a
  -- tag parented to the kart is painted over by that kart's own model.
  self.tagLayer = CreateFrame("Frame", nil, frame)
  self.tagLayer:SetAllPoints()
  self.tagLayer:SetFrameLevel(frame:GetFrameLevel() + 400)

  self.karts = {}
  for i = 1, AK.MAX_RACERS do
    local kart = CreateFrame("Frame", nil, frame)
    kart:SetSize(42, 42)
    kart.shadow = makeTexture(kart, "BACKGROUND", { 0, 0, 0, .55 }, 0, "shadow.tga")
    kart.shadow:SetPoint("BOTTOM", 0, 0)
    kart.trail = makeGlow(kart, "BACKGROUND", { 1, .7, .2, 1 }, 1)
    kart.trail:SetPoint("BOTTOM", kart, "BOTTOM", 0, 0)
    kart.trail:SetAlpha(0)
    kart.flame = makeGlow(kart, "ARTWORK", { 1, .52, .12, 1 }, 0)
    kart.flame:SetPoint("TOP", kart, "BOTTOM", 0, 8)
    kart.flame:SetAlpha(0)
    -- Drift sparks, one per rear wheel. These live ON the kart rather than only
    -- in the HUD meter: the meter is at the bottom of the screen and the corner
    -- is not, so a ladder you can only read by looking away is a ladder nobody
    -- reads. Additive, so they light the road rather than sitting on it.
    kart.sparkL = makeGlow(kart, "OVERLAY", { 1, 1, 1, 1 }, 1, "spark.tga")
    kart.sparkR = makeGlow(kart, "OVERLAY", { 1, 1, 1, 1 }, 1, "spark.tga")
    kart.sparkL:SetAlpha(0)
    kart.sparkR:SetAlpha(0)
    -- Seated racer, seen from behind since the camera chases the field.
    kart.model = AK.Model:New(kart, 72, 72, math.pi, 1)
    -- The kart is drawn in two passes. The whole thing sits BEHIND the driver
    -- (so nothing hides them -- putting the full chassis in front buried every
    -- racer from the waist up), and only the bottom slice, the wheels and
    -- bumper, is repeated in front of their legs. That is what sells sitting in
    -- it without covering the person.
    kart.body = makeTexture(kart, "ARTWORK", { .5, .5, .5, 1 }, 1, "kart.tga")
    kart.body:SetPoint("BOTTOM", 0, 0)
    kart.chassis = CreateFrame("Frame", nil, kart)
    kart.chassis:SetAllPoints()
    kart.lip = makeTexture(kart.chassis, "ARTWORK", { .5, .5, .5, 1 }, 1, "kart.tga")
    kart.lip:SetPoint("BOTTOM", 0, 0)
    kart.icon = kart:CreateTexture(nil, "OVERLAY")
    kart.icon:SetPoint("CENTER", 0, 1)
    -- Item trailing behind the kart, deployed but not yet fired. It doubles as
    -- a shield, so it has to be visible to be a readable decision.
    kart.heldGlow = makeGlow(kart, "BACKGROUND", { 1, 1, 1, 1 }, 2)
    kart.heldGlow:Hide()
    kart.heldIcon = kart:CreateTexture(nil, "ARTWORK", nil, 0)
    kart.heldIcon:Hide()
    kart.tag = UI:NewText(self.tagLayer, "", 11, { 1, 1, 1 }, "CENTER")
    kart.tag:SetShadowColor(0, 0, 0, 1)
    kart.tag:SetShadowOffset(1, -1)
    kart.tagPlate = makeTexture(self.tagLayer, "ARTWORK", { 0, 0, 0, .55 })
    kart.tagPlate:SetPoint("CENTER", kart.tag, "CENTER", 0, 0)
    -- Battle marker: appears over a rival who has been in your pocket for more
    -- than a moment, so a fight for position is legible before it costs you.
    kart.warn = UI:NewText(self.tagLayer, "", 22, AK.COLORS.danger, "CENTER")
    kart.warn:SetShadowColor(0, 0, 0, 1)
    kart.warn:SetShadowOffset(1, -1)
    kart.warn:SetAlpha(0)
    self.karts[i] = kart
  end

  -- One-shot effect sprites: launch flashes, shockwaves, impact stars. These
  -- are what make an item read as *fired* rather than as a silent stat change.
  self.effectPool = {}
  self.effects = {}
  for i = 1, 20 do
    local fx = frame:CreateTexture(nil, "OVERLAY", nil, 6)
    fx:SetBlendMode("ADD")
    fx:Hide()
    self.effectPool[i] = fx
  end

  -- Live power-ups in the world: shells, bananas, bombs.
  self.projectileFrames = {}
  for i = 1, 14 do
    local shot = CreateFrame("Frame", nil, frame)
    shot:SetSize(30, 30)
    shot.glow = makeGlow(shot, "BACKGROUND", { 1, 1, 1, 1 })
    shot.glow:SetPoint("CENTER")
    shot.shadow = makeTexture(shot, "BACKGROUND", { 0, 0, 0, .5 }, 1, "shadow.tga")
    shot.shadow:SetPoint("BOTTOM", 0, -2)
    shot.icon = shot:CreateTexture(nil, "ARTWORK")
    shot.icon:SetAllPoints()
    self.projectileFrames[i] = shot
  end

  -- Course hazards. Red so they can never be mistaken for a pickup.
  self.hazardFrames = {}
  for i = 1, 12 do
    local hz = CreateFrame("Frame", nil, frame)
    hz:SetSize(30, 30)
    -- Contact shadow. Anchored to the RACE frame each tick rather than to this
    -- one, so it stays welded to the road while the hazard above it moves.
    hz.shadow = makeTexture(hz, "BACKGROUND", { 0, 0, 0, .5 }, -3, "shadow.tga")
    hz.glow = makeGlow(hz, "BACKGROUND", { 1, .32, .18, 1 })
    hz.glow:SetPoint("BOTTOM", 0, 0)
    hz.icon = hz:CreateTexture(nil, "ARTWORK")
    hz.icon:SetTexture("Interface\\Icons\\Spell_Fire_SelfDestruct")
    hz.icon:SetPoint("BOTTOM", 0, 0)
    -- A hazard you can identify at a glance is one you can plan around; a red
    -- fire icon is just an abstract "bad". Creature hazards get the actual
    -- creature, and the icon stays as the fallback for anything that has no
    -- model or whose id does not resolve on this client.
    hz.model = CreateFrame("PlayerModel", nil, hz)
    hz.model:SetPoint("CENTER", hz, "CENTER")
    hz.model:Hide()
    hz.label = UI:NewText(hz, "", 11, { 1, .5, .35 }, "CENTER")
    hz.label:SetPoint("BOTTOM", hz, "TOP", 0, 2)
    hz.label:SetShadowColor(0, 0, 0, 1)
    hz.label:SetShadowOffset(1, -1)
    hz:Hide()
    self.hazardFrames[i] = hz
  end

  -- Ghost kart: a sprite only, no model, so it costs nothing and can never be
  -- mistaken for a live racer.
  self.ghostKart = CreateFrame("Frame", nil, frame)
  self.ghostKart:SetSize(40, 40)
  self.ghostKart:Hide()
  self.ghostBody = makeTexture(self.ghostKart, "ARTWORK", { .55, .85, 1, 1 }, 1, "kart.tga")
  self.ghostBody:SetPoint("BOTTOM", 0, 0)

  self.objectFrames = {}
  for i = 1, 16 do
    local object = CreateFrame("Frame", nil, frame)
    object:SetSize(30, 30)
    -- Contact shadow, and the single biggest reason these read as objects in
    -- the world rather than icons pasted on the picture. It is anchored to the
    -- RACE frame every tick, not to this frame, so an item box can bob while
    -- its shadow stays pinned to the tarmac -- that contrast is what sells the
    -- height. A sprite with no shadow always hovers.
    object.shadow = makeTexture(object, "BACKGROUND", { 0, 0, 0, .5 }, -3, "shadow.tga")
    object.pad = makeGlow(object, "BACKGROUND", { 1, .82, .25, 1 }, 0)
    object.pad:SetPoint("BOTTOM", 0, 0)
    object.beam = makeGlow(object, "BORDER", { 1, .82, .25, 1 })
    object.beam:SetPoint("BOTTOM", 0, 0)
    object.icon = object:CreateTexture(nil, "ARTWORK")
    object.icon:SetPoint("BOTTOM", 0, 0)
    object.ring = makeGlow(object, "OVERLAY", { 1, 1, 1, 1 })
    object.ring:SetPoint("BOTTOM", 0, 0)
    object.label = UI:NewText(object, "", 11, { 1, 1, 1 }, "CENTER")
    object.label:SetPoint("BOTTOM", object, "TOP", 0, 2)
    object.label:SetShadowColor(0, 0, 0, 1)
    object.label:SetShadowOffset(1, -1)
    self.objectFrames[i] = object
  end

  -- Grouped in one frame so the whole control bar can be hidden at once. On the
  -- scaled HUD container, so the row is the same fraction of the screen at any
  -- resolution -- it used to span a fixed 816px, which simply does not fit on a
  -- 800-wide window.
  self.controlBar = CreateFrame("Frame", nil, hud)
  self.controlBar:SetAllPoints()
  -- The PADS get their own frame, separate from the keyboard legend that lives
  -- on the bar with them. They are a setting -- off by default -- and the
  -- legend is what replaces them, so hiding the two together would take away
  -- the thing that tells you which keys to press.
  self.controlPads = CreateFrame("Frame", nil, self.controlBar)
  self.controlPads:SetAllPoints()
  -- 52px could not fit "BRAKE" or "RIGHT" at the button font, so the two most
  -- important controls on screen read "BRA..." and "RIG...". Wider, with a
  -- slightly smaller label, and the spacing opened to match so nothing touches.
  local CTRL_W, CTRL_GAP = 68, 6
  local function control(text, x, down, up)
    local button = UI:NewButton(self.controlPads, text, CTRL_W, HUD.controls.h, function() end)
    button.label:SetFont(STANDARD_TEXT_FONT, 13, "OUTLINE")
    button:SetPoint("BOTTOM", x, HUD.controls.y)
    button:SetScript("OnMouseDown", down)
    button:SetScript("OnMouseUp", up or function() end)
    return button
  end
  -- Steering on the left hand, throttle and actions on the right, mirroring the
  -- keyboard layout. There was previously no on-screen throttle at all, so a
  -- player driving with the mouse simply could not move.
  --
  -- The two clusters are now mirrored about the centre and derived from the
  -- row's own width, so the drift meter sits in the gap between them instead of
  -- the row being two hand-placed groups with a 490px hole in the middle.
  local edge = HUD.controls.w * 0.5 - CTRL_W * 0.5
  local pitch = CTRL_W + CTRL_GAP
  control("LEFT", -edge, function() AK.Race:SetControl("left", true) end, function() AK.Race:SetControl("left", false) end)
  control("RIGHT", -edge + pitch, function() AK.Race:SetControl("right", true) end, function() AK.Race:SetControl("right", false) end)
  local brake = control("BRAKE", edge - pitch * 3, function() AK.Race:SetControl("brake", true) end, function() AK.Race:SetControl("brake", false) end)
  brake:SetRestStyle({ .26, .10, .10, .95 }, AK.COLORS.danger)
  local gas = control("GAS", edge - pitch * 2, function() AK.Race:SetControl("accelerate", true) end, function() AK.Race:SetControl("accelerate", false) end)
  gas:SetRestStyle({ .10, .24, .12, .95 }, AK.COLORS.lime)
  control("DRIFT", edge - pitch, function() AK.Race:SetControl("drift", true) end, function() AK.Race:SetControl("drift", false) end)
  control("ITEM", edge, function() AK.Race:UseItem() end)

  -- The name of the corner you are in. Rally-style, and the cheapest possible
  -- way to turn a sequence of bends into a place with landmarks you remember.
  -- Stacked UNDER the track name rather than pinned 86px from the top edge.
  -- That fixed offset took no account of the header's height, so the corner
  -- callout and the track name -- both gold, both centred -- were drawn on top
  -- of each other every time a corner was entered.
  self.sectionLabel = UI:NewText(self.hudLayer, "", 17, AK.COLORS.gold, "LEFT")
  self.sectionLabel:SetPoint("TOPLEFT", self.trackName, "BOTTOMLEFT", 0, -4)
  self.sectionLabel:SetShadowColor(0, 0, 0, 1)
  self.sectionLabel:SetShadowOffset(1, -1)

  -- A legend, because every control above also has a key and none of them were
  -- discoverable. Sits under the buttons so it never covers the road.
  self.controlHint = UI:NewText(self.controlBar,
    "W / UP  GAS      S / DOWN  BRAKE      A D  or  LEFT RIGHT  STEER      "
    .. "SPACE  HOP / DRIFT / TRICK      SHIFT  ITEM      Q  AIM BACK      ESC  PAUSE",
    11, AK.COLORS.muted, "CENTER")
  self.controlHint:SetPoint("BOTTOM", 0, 8)

  -- A mouse route out, for anyone driving without a keyboard. It used to be
  -- always on: a red rectangle pinned to the corner of the screen for the whole
  -- race, which is the single most addon-looking thing a game screen can have.
  -- ESC pauses, and the pause panel has QUIT TO MENU on it, so the keyboard
  -- route out has existed the whole time -- this now travels with the on-screen
  -- controls, because it answers the same question they do.
  self.quit = UI:NewButton(hud, "QUIT", HUD.quit.w, HUD.quit.h, function() AK.Race:Stop(true) end)
  self.quit:SetPoint(HUD.quit.point, HUD.quit.x, HUD.quit.y)
  self.quit:SetRestStyle({ .38, .12, .11 }, AK.COLORS.danger)
  -- TUNE, BEATS and AI used to be a column of buttons stacked down the right
  -- edge for the whole race -- three developer tools permanently occupying the
  -- screen you are trying to look through. They live on the pause panel now,
  -- which is one key away and is where you go when you are not driving.
  self.raceButtons = {}
  local pause = CreateFrame("Frame", nil, frame)
  pause:SetAllPoints()
  -- Above the karts, which climb to +308 for depth sorting.
  pause:SetFrameLevel(frame:GetFrameLevel() + 500)
  pause:Hide()
  self.pause = pause
  local dim = makeTexture(pause, "BACKGROUND", { 0, 0, 0, .6 })
  dim:SetAllPoints()
  local pausePanel = UI:NewPanel(pause, PAUSE_W, 302, { .045, .075, .125, .98 })
  pausePanel:SetPoint("CENTER", 0, -30)
  self.pausePanel = pausePanel
  local pauseTitle = UI:NewText(pausePanel, "PAUSED", 28, AK.COLORS.gold, "CENTER")
  pauseTitle:SetPoint("TOP", 0, -22)
  -- WHICH RACE YOU PAUSED, so the panel is not a floating word -- on two lines,
  -- because it did not fit on one. "NETHERSTORM TURBO CIRCUIT -- LAP 2 OF 3" is
  -- already within a few pixels of the panel's inside width at 12pt, and a
  -- Grand Prix adds "RACE 1 OF 4" to it. The name gets the first line and the
  -- counting gets the second, quieter, which is the right shape for it anyway.
  self.pauseWhere = UI:NewText(pausePanel, "", 12, { .84, .90, 1 }, "CENTER")
  self.pauseWhere:SetPoint("TOP", 0, -PAUSE_WHERE_Y)
  self.pauseWhere:SetWidth(PAUSE_W - 24)
  self.pauseCount = UI:NewText(pausePanel, "", 11, AK.COLORS.muted, "CENTER")
  self.pauseCount:SetPoint("TOP", 0, -PAUSE_COUNT_Y)
  self.pauseCount:SetWidth(PAUSE_W - 24)
  self.pauseResume = UI:NewButton(pausePanel, "RESUME", PAUSE_BTN_W, PAUSE_BTN_H,
    function() AK.Race:TogglePause() end)
  -- RESTART. Every kart game has this and ours did not: a bad start or a shell
  -- on the last corner meant quitting to the menu and rebuilding the entire
  -- selection to try again.
  self.pauseRestart = UI:NewButton(pausePanel, "RESTART RACE", PAUSE_BTN_W, PAUSE_BTN_H,
    function() AK.Race:Restart() end)
  self.pauseRestart.tooltip = "Run this circuit again from the lights, with the same grid."
  -- LEAVING. A single race is one click away from the menu, because losing it
  -- costs a lap time. A Grand Prix is four races and a points table, and one
  -- misplaced click used to bin the lot with no warning at all -- so the cup
  -- arms first and quits second, and says on its face what it is about to
  -- throw away.
  self.pauseQuit = UI:NewButton(pausePanel, "QUIT TO MENU", PAUSE_BTN_W, PAUSE_BTN_H, function(button)
    if button.armed then return AK.Race:Stop(true) end
    if button.needsArming then
      button.armed = true
      button.label:SetText("REALLY ABANDON THE CUP?")
      button:SetRestStyle({ .58, .12, .10, .98 }, AK.COLORS.danger)
      return
    end
    AK.Race:Stop(true)
  end)
  self.pauseQuit:SetRestStyle({ .28, .09, .09, .95 }, AK.COLORS.danger)
  -- The big three, in the order they are stacked. Built here rather than
  -- assembled at layout time so the stack is one list with no holes in it.
  self.pauseStack = { self.pauseResume, self.pauseRestart, self.pauseQuit }
  -- The race tools. They were on the racing screen -- three developer buttons
  -- stacked down the right edge for the whole race -- then here, as a row of
  -- peers beneath QUIT TO MENU. Neither is right: a pause menu that offers a
  -- telemetry dump next to RESUME is not a game's pause menu. They are behind
  -- the developer-tools setting now, off by default, and the shipped panel is
  -- the three choices a kart game's pause menu has ever had.
  self.pauseTools = {}
  local tools = {
    { "TUNE", function() AK.Workshop:Toggle() end,
      "Camera, feel, audio and difficulty, live, while the race runs." },
    { "BEATS", function() self:PlayBeats() end,
      "Play every race moment in sequence -- start lights, splits, final lap, finish -- so they can be seen and screenshotted on demand." },
    { "AI", function() AK.AI:Report() end,
      "Live AI telemetry: drifts, braking, mistakes and catch-up assistance, per opponent." },
  }
  for i, entry in ipairs(tools) do
    local tool = UI:NewButton(pausePanel, entry[1], PAUSE_TOOL_W, PAUSE_TOOL_H, entry[2])
    tool.dx = (i - 2) * (PAUSE_TOOL_W + 4)
    tool:SetPoint("TOP", tool.dx, 0)
    tool.tooltip = entry[3]
    self.pauseTools[i] = tool
  end
  self:LayoutHud()
  -- The race frame is pinned to UIParent, so this fires whenever the client is
  -- resized or the master UI scale changes -- the two things that used to leave
  -- the HUD at the wrong size until a reload.
  frame:SetScript("OnSizeChanged", function() RaceUI:LayoutHud() end)

  frame:SetScript("OnKeyDown", function(_, key) AK.Race:OnKey(key, true) end)
  frame:SetScript("OnKeyUp", function(_, key) AK.Race:OnKey(key, false) end)
  -- Release the keyboard grab whenever the frame goes away, including on error.
  frame:SetScript("OnHide", function(self)
    if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(true) end
  end)
  frame:SetScript("OnShow", function(self)
    if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
  end)
end

-- Per-track distant terrain. Heights are fractions of SCREEN height -- the
-- skyline used to be sized in absolute pixels, tuned against a 1280-wide
-- preview, which is why it shrank to a row of specks on larger clients.
-- `float` lifts the ridge off the horizon: Netherstorm's islands hang in the
-- void. `treeArt`/`treeTint` restyle the near wall so a volcanic waste is not
-- ringed by the same green conifers as a summer forest.
-- `treeTint` is now the treeline's actual COLOUR, not a nudge.
--
-- tree.tga used to have dark green baked into it, so every entry here was
-- multiplying a dark green by something and getting dark green back: Durotar's
-- volcanic waste, Ironforge's frost and the Deadmines' blue-grey were all the
-- same conifer, and the whole treeline read as a near-black cut-out on every
-- track. The art is a pale neutral silhouette now (see Art/generate-art.js),
-- so these values finally decide what a treeline looks like -- which means
-- re-authoring them as real colours, dark enough to read against their own sky
-- instead of as multipliers of something already dark.
local SKYLINE = {
  oribos        = {},
  elwynn        = { mtn = { h = .12, tint = { .55, .64, .80 }, a = .85 }, hill = { h = .085, tint = { .34, .52, .30 } },
                    treeTint = { .26, .46, .27 } },
  durotar       = { mtn = { h = .19, tint = { .60, .32, .22 }, a = .95 }, hill = { h = .07, tint = { .50, .30, .17 } },
                    treeTint = { .46, .25, .13 } },
  stranglethorn = { mtn = { h = .11, tint = { .38, .54, .52 }, a = .80 }, hill = { h = .10, tint = { .16, .36, .25 } },
                    treeTint = { .17, .42, .22 } },
  ironforge     = { mtn = { h = .22, tint = { .80, .87, .97 }, a = 1.0 }, hill = { h = .08, tint = { .60, .70, .83 } },
                    treeTint = { .42, .55, .62 } },
  deadmines     = { mtn = { h = .10, tint = { .20, .24, .40 }, a = .90 }, hill = { h = .06, tint = { .15, .19, .30 } },
                    treeTint = { .24, .28, .44 } },
  netherstorm   = { mtn = { h = .15, tint = { .52, .33, .72 }, a = .90, float = .05 },
                    treeArt = "shard.tga", treeTint = { .58, .38, .86 } },
  -- These three had no entry at all and fell through to the default: no ridge
  -- line behind them, and a wall of plain forest green on the horizon of a
  -- mesa, a bog and a frozen citadel. Same fault the props had, one layer
  -- further back -- and further back is where it is least likely to be noticed
  -- and most likely to make three circuits look like the same place.
  thousandneedles = { mtn = { h = .17, tint = { .66, .40, .26 }, a = .95 },
                    hill = { h = .075, tint = { .54, .32, .20 } },
                    treeArt = "spire.tga", treeTint = { .60, .40, .26 } },
  zangarmarsh   = { mtn = { h = .09, tint = { .28, .46, .50 }, a = .75 },
                    hill = { h = .085, tint = { .18, .38, .38 } },
                    treeArt = "sporecap.tga", treeTint = { .34, .58, .56 } },
  icecrown      = { mtn = { h = .20, tint = { .30, .34, .48 }, a = .95 },
                    hill = { h = .07, tint = { .22, .26, .38 } },
                    treeArt = "spire.tga", treeTint = { .20, .23, .32 } },
  -- THE TWO BATTLE ARENAS, which had no entry here either -- they are in their
  -- own data file and the checks that found the three missing circuits above
  -- only ever read Data/Tracks.lua. A dwarven fighting pit and a flooded cave
  -- were both ringed by the default wall of forest green.
  anvilmar      = { mtn = { h = .21, tint = { .40, .28, .20 }, a = 1.0 },
                    hill = { h = .09, tint = { .32, .22, .15 } },
                    treeArt = "spire.tga", treeTint = { .52, .40, .28 } },
  grotto        = { mtn = { h = .17, tint = { .12, .20, .26 }, a = 1.0 },
                    hill = { h = .08, tint = { .08, .15, .20 } },
                    treeArt = "spire.tga", treeTint = { .20, .30, .36 } },
  -- Open sky over the jungle: a low, hazy ridge a long way off and a close
  -- wall of palms, so the pit reads as outdoors -- the one thing that tells it
  -- apart from the other two arenas at a glance.
  gurubashi     = { mtn = { h = .10, tint = { .44, .58, .56 }, a = .78 },
                    hill = { h = .10, tint = { .18, .38, .24 } },
                    treeTint = { .20, .44, .25 } },
}

--- Re-anchor everything pinned to the horizon. Called whenever the tuned
--- horizon moves, which is the one value that changes static layout.
--- Fit the whole HUD to the screen.
---
--- One SetScale on one container, rather than a screen fraction threaded
--- through fifty offsets. The container is pinned to UIParent, so scaling it
--- leaves its corners on the screen's corners and grows everything anchored to
--- them -- which is exactly the behaviour wanted and exactly what a per-widget
--- rewrite would have had to reimplement by hand.
---
--- Clamped at both ends: below ~0.6 the type stops being legible at all, and
--- above ~1.7 the HUD starts eating the road on an ultrawide, where the height
--- is the binding constraint and the extra width should become view, not chrome.
function RaceUI:LayoutHud()
  if not self.hud then return end
  local frame = self.frame
  local width, height = frame:GetWidth(), frame:GetHeight()
  if not width or width <= 0 or not height or height <= 0 then return end
  local fit = math.min(width / HUD_DESIGN_W, height / HUD_DESIGN_H)
  local dial = (self.T and self.T.hudScale or 100) / 100
  self.hudFit = AK.Math.Clamp(fit, 0.60, 1.70) * AK.Math.Clamp(dial, 0.5, 2.0)
  self.hud:SetScale(self.hudFit)
end

--- Lay the pause panel out for the race that is actually paused.
---
--- Called every time the panel is shown, because what belongs on it depends on
--- the race: a Grand Prix warns before it throws four races away, a battle has
--- no lap count to report, and the developer row is only there if the player
--- asked for developer tools. The panel is then sized to its contents, so
--- nothing that is hidden leaves a hole behind it.
function RaceUI:LayoutPause(race)
  if not self.pausePanel then return end
  local cup = race and race.grandPrix
  local canRestart = race and race.mode ~= "multiplayer" and race.mode ~= "attract"
  local dev = AK.db and AK.db.settings and AK.db.settings.debug

  -- The quit button says what leaving costs, and is disarmed on every fresh
  -- pause: an arming click left over from the last time you looked at this
  -- panel must not turn the NEXT first click into a quit.
  local quit = self.pauseQuit
  quit.needsArming = cup and true or false
  quit.armed = false
  quit.label:SetText(cup and "ABANDON CUP" or "QUIT TO MENU")
  quit:SetRestStyle({ .28, .09, .09, .95 }, AK.COLORS.danger)
  quit.tooltip = cup
    and "Leave the Grand Prix. The cup's points are lost and the remaining heats are not run."
    or nil

  -- Every control is told whether it is on, rather than asked -- a frame in WoW
  -- is visible until something hides it, so "is this shown" answers yes for a
  -- button nobody has ever placed, and the stack would lay itself out around
  -- whatever the last race left behind.
  local y = PAUSE_FIRST_Y
  for _, button in ipairs(self.pauseStack) do
    local on = button ~= self.pauseRestart or canRestart
    button:SetShown(on)
    if on then
      button:ClearAllPoints()
      button:SetPoint("TOP", 0, -y)
      y = y + PAUSE_BTN_H + PAUSE_BTN_GAP
    end
  end
  y = y - PAUSE_BTN_GAP

  for _, tool in ipairs(self.pauseTools) do tool:SetShown(dev and true or false) end
  if dev then
    y = y + PAUSE_TOOL_GAP
    for _, tool in ipairs(self.pauseTools) do
      tool:ClearAllPoints()
      tool:SetPoint("TOP", tool.dx, -y)
    end
    y = y + PAUSE_TOOL_H
  end

  self.pausePanel:SetSize(PAUSE_W, y + PAUSE_BOTTOM)
end

function RaceUI:LayoutHorizon(horizon)
  self.appliedHorizon = horizon
  local frame = self.frame
  local screenH = frame:GetHeight()
  self.sky:ClearAllPoints()
  self.sky:SetPoint("TOPLEFT")
  self.sky:SetPoint("BOTTOMRIGHT", frame, "RIGHT", 0, horizon)
  self.skyGlow:ClearAllPoints()
  self.skyGlow:SetPoint("BOTTOMLEFT", frame, "LEFT", 0, horizon - 4)
  self.skyGlow:SetPoint("TOPRIGHT", frame, "RIGHT", 0, horizon + screenH * 0.17)
  self.ground:ClearAllPoints()
  self.ground:SetPoint("TOPLEFT", frame, "LEFT", 0, horizon)
  self.ground:SetPoint("BOTTOMRIGHT")
  -- Tall and faint: a narrow opaque band reads as a purple stripe painted
  -- across the sky rather than as atmosphere. Scaled with the screen so it
  -- stays atmosphere at any resolution.
  -- Below the horizon it builds from nothing up to full; above it, it decays
  -- back to nothing. Deeper below than above, because the ground recedes for
  -- much further on screen than the sky does.
  self.hazeBelow:ClearAllPoints()
  self.hazeBelow:SetPoint("BOTTOMLEFT", frame, "LEFT", 0, horizon - screenH * 0.12)
  self.hazeBelow:SetPoint("TOPRIGHT", frame, "RIGHT", 0, horizon)
  self.hazeAbove:ClearAllPoints()
  self.hazeAbove:SetPoint("BOTTOMLEFT", frame, "LEFT", 0, horizon)
  self.hazeAbove:SetPoint("TOPRIGHT", frame, "RIGHT", 0, horizon + screenH * 0.05)
end

--- Sky, horizon glow and weather are per-track, so a night circuit reads as
--- night rather than as a day track with a dark sky pasted above it.
function RaceUI:ApplyTrackPalette(track)
  local top = track.skyTop or { 0.24, 0.46, 0.82 }
  local low = track.skyLow or { 0.72, 0.86, 0.97 }
  local glow = track.glow or { 1.00, 0.93, 0.72 }
  applyGradient(self.sky, "VERTICAL", low[1], low[2], low[3], 1, top[1], top[2], top[3], 1)
  -- Strongest AT the horizon, fading upward. This was inverted -- strongest at
  -- the band's top edge with a hard cutoff -- which painted a grey stripe
  -- floating in the sky above the mountains in every daytime video frame.
  applyGradient(self.skyGlow, "VERTICAL", glow[1], glow[2], glow[3], .45, glow[1], glow[2], glow[3], 0)
  self.light = track.light or 1
  self.weatherKind = track.weather or "none"
  self.style = track.style

  -- THE ROCK BELONGS TO THE CIRCUIT.
  --
  -- rock.tga is neutral on purpose -- it is tinted, like the trees and the
  -- ground -- but nothing was tinting it, so Ironforge's ice tunnel, the
  -- Deadmines shaft and Netherstorm's span were all the same grey corridor.
  -- Derived from the track's own road colour lifted halfway to neutral: the
  -- rock a road is cut through is related to the road, and going all the way to
  -- the road's colour would make the walls vanish into the floor.
  local road = track.road or { 0.4, 0.4, 0.44 }
  -- Kept, because the wall's brightness is aimed relative to the road's own
  -- pixel rather than at a fraction of the scene light.
  self.roadColour = road
  local mid = (road[1] + road[2] + road[3]) / 3
  self.rockTint = {
    road[1] * 0.55 + mid * 0.45 + 0.10,
    road[2] * 0.55 + mid * 0.45 + 0.10,
    road[3] * 0.55 + mid * 0.45 + 0.10,
  }
  -- ALWAYS normalised to a peak of 1, not merely clamped when it exceeds one.
  -- A tint multiplies the lighting, so anything under 1 is a second brightness
  -- reduction hiding inside a colour choice -- Deadmines' warm floor produced a
  -- peak of 0.66 and quietly took a third off every wall in the mine. The tint
  -- carries HUE; `rock` carries brightness, and only `rock`.
  local peak = math.max(self.rockTint[1], self.rockTint[2], self.rockTint[3])
  if peak > 0.001 then
    for i = 1, 3 do self.rockTint[i] = self.rockTint[i] / peak end
  end

  -- Distant terrain layers and the near wall's art, all per track.
  self.skyline = SKYLINE[track.id] or {}
  local treeArt = track.style == "oribos" and "spire.tga" or self.skyline.treeArt or "tree.tga"
  for _, tree in ipairs(self.trees) do
    tree:SetTexture(ART .. treeArt)
  end

  -- Anchor the ridge layers for this track. Parallax happens through texture
  -- coordinates in RenderSky, so the quads themselves never move.
  local frame = self.frame
  local screenH = frame:GetHeight()
  local horizon = self.T.horizon
  local function placeRidge(texture, cfg)
    if not cfg then texture:Hide() return end
    local lift = screenH * (cfg.float or 0)
    texture:ClearAllPoints()
    texture:SetPoint("BOTTOMLEFT", frame, "LEFT", 0, horizon + lift)
    texture:SetPoint("BOTTOMRIGHT", frame, "RIGHT", 0, horizon + lift)
    texture:SetHeight(screenH * cfg.h)
    texture:Show()
  end
  placeRidge(self.mountain, self.skyline.mtn)
  placeRidge(self.hillLine, self.skyline.hill)

  local conduit = track.style == "oribos"
  for _, strip in ipairs(self.strips) do
    strip.rumbleLeft:SetTexture(conduit and (ART .. "glow.tga") or SOLID)
    strip.rumbleRight:SetTexture(conduit and (ART .. "glow.tga") or SOLID)
    strip.rumbleLeft:SetBlendMode(conduit and "ADD" or "BLEND")
    strip.rumbleRight:SetBlendMode(conduit and "ADD" or "BLEND")
  end

  -- Seed the weather field across the whole screen so it is already falling
  -- when the countdown starts, rather than sweeping in from the top edge.
  local kind = self.weatherKind
  for _, drop in ipairs(self.weather) do
    if kind == "none" then
      drop.texture:Hide()
    else
      drop.x = (math.random() - .5) * self.halfWidth * 2.4
      drop.y = (math.random() - .5) * self.halfHeight * 2.4
      drop.phase = math.random() * math.pi * 2
      if kind == "rain" then
        drop.speed = -900 - math.random() * 500
        drop.size, drop.sway = 1.6, 0
        -- Reset the texture each time: a track switch must not inherit the
        -- previous weather's art.
        drop.texture:SetTexture(SOLID)
        drop.texture:SetSize(1.6, 22 + math.random() * 16)
        drop.texture:SetVertexColor(.62, .74, .92, 1)
        drop.texture:SetAlpha(.34)
        drop.texture:SetBlendMode("BLEND")
      elseif kind == "snow" then
        drop.speed = -70 - math.random() * 70
        drop.sway = 24 + math.random() * 34
        local size = 4 + math.random() * 6
        drop.texture:SetTexture(ART .. "spark.tga")
        drop.texture:SetSize(size, size)
        drop.texture:SetVertexColor(1, 1, 1, 1)
        drop.texture:SetAlpha(.6 + math.random() * .35)
        drop.texture:SetBlendMode("BLEND")
      else -- ember
        drop.speed = 46 + math.random() * 90
        drop.sway = 16 + math.random() * 26
        -- Soft and dim: hard bright dots read as dust on the monitor.
        local size = 4 + math.random() * 7
        drop.texture:SetTexture(ART .. "spark.tga")
        drop.texture:SetSize(size, size)
        drop.texture:SetVertexColor(1, .58 + math.random() * .3, .22, 1)
        drop.texture:SetAlpha(.18 + math.random() * .22)
        drop.texture:SetBlendMode("ADD")
      end
      drop.texture:Show()
    end
  end
end

--- Weather wraps around the viewport instead of respawning, so the field stays
--- constant density no matter how long the race runs.
function RaceUI:RenderWeather(race, dt)
  if self.weatherKind == "none" or AK.db.settings.reducedEffects then return end
  local limitX, limitY = self.halfWidth * 1.2, self.halfHeight * 1.2
  -- Density is a tuning value, so the field is thinned by hiding drops rather
  -- than by rebuilding the pool.
  local amount = self.T.weatherAmount
  local visible = math.floor(#self.weather * math.min(1, amount))
  for index, drop in ipairs(self.weather) do
    drop.texture:SetShown(index <= visible)
  end
  for _, drop in ipairs(self.weather) do
    drop.phase = drop.phase + dt * 2.2
    drop.y = drop.y + drop.speed * dt
    drop.x = drop.x + math.sin(drop.phase) * drop.sway * dt
    if drop.y < -limitY then
      drop.y = limitY
      drop.x = (math.random() - .5) * limitX * 2
    elseif drop.y > limitY then
      drop.y = -limitY
      drop.x = (math.random() - .5) * limitX * 2
    end
    if drop.x < -limitX then drop.x = limitX elseif drop.x > limitX then drop.x = -limitX end
    drop.texture:ClearAllPoints()
    drop.texture:SetPoint("CENTER", self.frame, "CENTER", drop.x, drop.y)
  end
end

function RaceUI:Show(race)
  self:Build()
  -- The race itself decides whether models run, rather than a sticky toggle
  -- that some other path is trusted to reset. Only the attract demo goes
  -- sprites-only, and a single missed restore used to leave every racer as a
  -- flat icon for the rest of the session.
  self:SetModelsEnabled(race.mode ~= "attract")
  self.T = AK.db.tuning
  self.frame:SetScale(AK.db.settings.uiScale or 1)
  self.halfWidth = self.frame:GetWidth() * .5
  self.halfHeight = self.frame:GetHeight() * .5
  self.camDepth = self.T.camDepth
  self.camLateralValue, self.camYawValue = nil, nil
  -- Full driver HUD: the previous race may have ended with it faded back for
  -- the cooldown lap, and nothing else restores it.
  self.driverFade = 1
  self.shake, self.shakeX, self.shakeY = 0, 0, 0
  -- Every presentation deadline is stored in race time, so starting a race
  -- resets the clock underneath any beat still counting down from the last one
  -- and it can never expire. Clear them before the new race's clock begins.
  self:ClearPresentation()
  -- Hand live particles back before clearing, or their textures stay visible
  -- and are lost to the pool for the rest of the session.
  for _, particle in ipairs(self.particles) do
    particle.texture:Hide()
    table.insert(self.particlePool, particle.texture)
  end
  wipe(self.particles)
  wipe(self.previous)
  self:LayoutHorizon(self.T.horizon)
  self:LayoutHud()
  self:ApplyTrackPalette(race.track)
  self.roulette, self.lastItem = nil, race.player and race.player.item or nil
  -- Only name the theme when it adds something. "Netherstorm Turbo Circuit  /
  -- NETHERSTORM" reads like a debug string, and most circuits are named after
  -- the zone they run through.
  local theme = race.track.theme
  local redundant = theme and race.track.name:upper():find(theme:upper(), 1, true)
  self.trackName:SetText(redundant and race.track.name
    or (race.track.name .. "  /  " .. theme))
  -- Concatenating a nil `shortcut` throws here and takes the whole race start
  -- down with it -- and a battle arena has no shortcut to speak of, so this
  -- would fire on the very first fixture. Every circuit happens to define one
  -- today, but a HUD line should not be a landmine for the next track that
  -- forgets to.
  self.shortcut:SetText(race.track.shortcut and ("SHORTCUT: " .. race.track.shortcut) or "")
  -- "BALLOONS" is four times the width of "LAP", so the number beside it starts
  -- further along. Done once per race rather than per frame: the mode cannot
  -- change underneath a running race.
  self.lap:ClearAllPoints()
  self.lap:SetPoint("TOPLEFT", race.battle and BALLOON_NUMBER_X or LAP_NUMBER_X, -4)
  self.notice:SetText("")
  self.countdown:SetText("")
  self:BuildMinimapRoute(race.track)
  self:SeatTheCrowd(race)
  self.frame:Show()
end

--- Hand each spectator seat a face, once per race.
---
--- Racers who are NOT on this grid first -- the roster is eleven and a grid is
--- eight, so on most races there are people to spare and the ones watching are
--- the ones who are not driving. When the grid is full enough that there are
--- not, it wraps back into the whole roster rather than leaving empty seats.
function RaceUI:SeatTheCrowd(race)
  if not self.spectators then return end
  local racing = {}
  for _, vehicle in ipairs(race.vehicles or {}) do
    if vehicle.racer then racing[vehicle.racer.id] = true end
  end
  local pool = {}
  for _, racer in ipairs(AK.Racers) do
    if not racing[racer.id] and racer.model then pool[#pool + 1] = racer end
  end
  if #pool < SPECTATOR_SLOTS then
    for _, racer in ipairs(AK.Racers) do
      if racer.model then pool[#pool + 1] = racer end
    end
  end
  if #pool == 0 then return end
  for slot, seat in ipairs(self.spectators) do
    local racer = pool[(slot - 1) % #pool + 1]
    AK.Model:SetSpec(seat.model, racer.model)
    -- Their own scale, so a gnome in the crowd is a gnome and not a tauren.
    seat.model.akSeatScale = racer.seatScale or 1
    seat.model.akSeatZ = 0
  end
end

function RaceUI:Hide()
  if self.frame then self.frame:Hide() end
end

--- Attract mode shows the world but none of the interface: no HUD, no controls,
--- no banners. The menu sits on top of it.
--- Whether racer models run at all. Nothing protected here, so this is safe to
--- call from any path -- including a slash command typed into chat.
---
--- Attract mode runs behind the menu, which already has its own preview model
--- plus one per racer card. Adding 8 karts and 6 spectators on top pushed the
--- client past the number of PlayerModels it will render at once and models
--- started dropping out everywhere, so the demo runs on sprites only.
function RaceUI:SetModelsEnabled(enabled)
  self:Build()
  local wasSuppressed = self.suppressModels
  self.suppressModels = not enabled
  if not enabled then
    for _, kart in ipairs(self.karts) do kart.model:Hide() end
    for _, seat in ipairs(self.spectators) do seat:Hide() end
  elseif wasSuppressed then
    -- Coming back from sprites-only: the models were hidden and may have been
    -- unloaded underneath us, so drop the caches and let them load again.
    for _, kart in ipairs(self.karts) do AK.Model:Invalidate(kart.model) end
    for _, seat in ipairs(self.spectators) do AK.Model:Invalidate(seat.model or seat) end
  end
end

function RaceUI:SetHudShown(shown)
  self:Build()
  self.hudShown = shown
  self:SetModelsEnabled(shown)
  forEachPresent(function(region) region:SetShown(shown) end,
    self.hudLayer, self.tagLayer, self.minimapPanel,
    self.headerPanel, self.clockPanel, self.itemPanel, self.driftPanel,
    self.placeGlow, self.position, self.positionOf, self.status,
    self.controlBar, self.trackName, self.shortcut, self.countdown,
    self.lightRig)
  for _, button in ipairs(self.raceButtons or {}) do button:SetShown(shown) end
  -- Any beat still counting down when the race ended stays up over the results
  -- and then over the menu -- "LAP 2" was sitting on the title screen. Announce
  -- already refuses to fire while the HUD is hidden, but nothing ever cleared
  -- what was ALREADY on screen when attract mode started.
  if not shown then self:ClearPresentation() end
  if self.frame then
    -- Attract mode must not swallow the keyboard; the menu needs it.
    -- Release the keyboard grab in attract mode so the menu stays usable.
    -- Mouse state is deliberately untouched: the race frame never captured the
    -- mouse, and enabling it here would start swallowing clicks.
    -- Protected, and blocked outright when this is reached from Blizzard's
    -- chat edit box. Failing to release the grab is survivable; throwing here
    -- is not, so the call is guarded.
    if self.frame.SetPropagateKeyboardInput then
      pcall(self.frame.SetPropagateKeyboardInput, self.frame, not shown)
    end
    pcall(self.frame.EnableKeyboard, self.frame, shown)
  end
end

--- Wipe any in-flight announcement. Without this a banner fired in the last
--- moments of a race stays on screen over the results.
--- Drop every live presentation beat. Call this whenever a race begins or ends.
---
--- Every deadline in here is stored in RACE TIME, not wall-clock -- `now()`
--- returns `race.elapsed`. So "finishUntil = elapsed + 2.4" on a race that ended
--- at 93s is 95.4, and the NEXT race restarts elapsed at zero: the deadline is
--- still 95 seconds in the "future", and the FINISHED 1ST card, the chequered
--- flash and every other beat sat on screen through the following race's
--- countdown and most of the race itself. Nothing expires them, because from
--- their point of view they have not happened yet.
function RaceUI:ClearPresentation()
  self.finishUntil, self.checkerUntil, self.lightsUntil = nil, nil, nil
  self.splitUntil, self.wrongWayUntil, self.beatUntil = nil, nil, nil
  self.noticeUntil, self.sectionUntil = nil, nil
  self.lightsLit, self.lightsGreen = nil, nil
  self.flashAlpha, self.urgencyAlpha = 0, 0
  -- Feel channels are offsets on the camera baseline; a race must never inherit
  -- one still easing out of the last one.
  self.feel = { push = 0, dip = 0, lean = 0, kickX = 0 }

  -- These are driven purely by ALPHA in UpdatePresentation and never by
  -- SetShown, so hiding them would leave them permanently invisible -- the beat
  -- would fire again and set an alpha on a hidden widget forever after.
  forEachPresent(function(region) region:SetAlpha(0) end,
    self.finishCard, self.splitText, self.wrongWay,
    self.beatLabel, self.urgency, self.flash, self.spinyWarn)
  -- THE NOTICE IS FOUR WIDGETS AND THIS KNEW ABOUT ONE.
  --
  -- The text above is faded to nothing, and the black plate behind it, its gold
  -- border and its icon were left exactly as they were -- so starting a new
  -- race cleared the words and left the empty banner sitting on the HUD. Worse,
  -- nothing could ever take it down again: UpdatePresentation only hides those
  -- three when a notice deadline EXPIRES, and the line above has just set that
  -- deadline to nil, so the branch that would clean up never runs.
  --
  -- ClearBanner already owns the full list. Calling it is the fix, and it is
  -- the reason to have had it: a second hand-written copy of "what a notice is
  -- made of" is how this went wrong in the first place.
  self:ClearBanner()

  -- These two manage their own shown state, so they have to actually be hidden:
  -- UpdatePresentation only runs during a race, and between races nothing would
  -- take them down. `checker` is a LIST of 24 cells, not a single texture --
  -- calling :Hide() on the table itself is what threw "attempt to call a nil
  -- value" here.
  if self.startLights then self.startLights:Hide() end
  for _, tile in ipairs(self.checker or {}) do tile:Hide() end
  if self.ladder then self.ladder:Hide() end
  if self.cooldownScrim then self.cooldownScrim:SetAlpha(0) end
  self.ladderIn = nil
  self:ClearBanner()
end

function RaceUI:ClearBanner()
  if not self.notice then return end
  self.noticeUntil = nil
  self.notice:SetText("")
  self.noticePlate:Hide()
  self.noticeEdge:Hide()
  self.noticeIcon:Hide()
end

--- Draw the circuit's real plan-view shape. This used to be a fixed ellipse
--- with the centreline offset added on top, which drew the same ring for every
--- track and now overflows the panel entirely at real corner amplitudes.
-- Half the span the route drawing may use inside the map panel, derived from
-- the panel rather than fixed at 46 against a 128px box that no longer exists.
local MAP_RADIUS = HUD.map.w * 0.36

function RaceUI:BuildMinimapRoute(track)
  local count = #self.mapRoute
  for index, node in ipairs(self.mapRoute) do
    local fraction = (index - 1) / count
    local x, y
    if track.mapPath then
      x, y = AK.TrackBuilder:MapPoint(track, fraction * track.length)
      x, y = x * MAP_RADIUS * 2, y * MAP_RADIUS * 2
    else
      local angle = fraction * math.pi * 2 - math.pi * .5
      x, y = math.cos(angle) * MAP_RADIUS, math.sin(angle) * MAP_RADIUS * 0.71
    end
    node:ClearAllPoints()
    -- Dead centre. The old -7 shift made room for a "TRACK MAP" caption that
    -- the panel no longer carries, so the route sat low in its own box.
    node:SetPoint("CENTER", self.minimap, "CENTER", x, y)
    node:Show()
  end
end

--- Where a racer sits on the track map.
function RaceUI:MapPosition(track, distance)
  if track.mapPath then
    local x, y = AK.TrackBuilder:MapPoint(track, distance)
    return x * MAP_RADIUS * 2, y * MAP_RADIUS * 2
  end
  local angle = (distance % track.length) / track.length * math.pi * 2 - math.pi * .5
  return math.cos(angle) * MAP_RADIUS, math.sin(angle) * MAP_RADIUS * 0.71
end

--- Banner announcement. `icon` gives it a matching item icon, which is what
--- makes using something feel like it actually happened.
function RaceUI:Announce(message, color, icon)
  -- The title-screen demo runs the full simulation; it must stay silent.
  if self.hudShown == false then return end
  color = color or AK.COLORS.gold
  self.notice:SetTextColor(unpack(color))
  self.notice:SetText(message)
  self.notice:SetAlpha(1)
  self.noticeIcon:SetShown(icon ~= nil)
  if icon then self.noticeIcon:SetTexture(icon) end
  self.noticeUntil = (AK.Race.current and AK.Race.current.elapsed or 0) + 1.9
  self.noticeStart = (AK.Race.current and AK.Race.current.elapsed or 0)
  self.noticeColor = color
end

-- ---- presentation beats -------------------------------------------------
--
-- Each of these sets a deadline; UpdatePresentation draws whatever is still
-- live. Keeping the trigger and the drawing apart means a beat can be fired
-- from RaceManager, or from /kart beats with no race running at all, and look
-- identical either way.

--- Presentation deadlines run on a MONOTONIC clock, never on race time.
---
--- This used to return `race.elapsed`, which restarts at zero every race. A
--- beat set at "elapsed + 2.4" near the end of a 93-second race therefore held
--- a deadline of 95.4, and the next race's clock began at 0 -- so from the
--- beat's point of view it had not happened yet, and the FINISHED 1ST card and
--- the chequered flash sat on screen through the whole following race. Nothing
--- could expire them. A clock that only ever moves forward makes the entire
--- class of bug impossible; the `race` argument is kept so callers read the
--- same, and is deliberately ignored.
local function now(_race)
  return GetTime()
end

--- Light `lit` of the three lamps. 3 lit and green means GO.
function RaceUI:SetStartLights(lit, green)
  self.lightsLit, self.lightsGreen = lit, green
  self.lightsUntil = green and (now() + 1.4) or nil
  if self.startLights then self.startLights:SetShown(lit ~= nil) end
end

--- Your split for the lap just completed, against your best so far.
function RaceUI:ShowLapSplit(lapNumber, split, best)
  if not self.splitText then return end
  local delta = best and (split - best) or nil
  local text = ("LAP %d   %s"):format(lapNumber, self:FormatTime(split))
  if delta and math.abs(delta) > 0.005 then
    text = text .. ("   %s%.2fs"):format(delta < 0 and "-" or "+", math.abs(delta))
  elseif not best then
    text = text .. "   FIRST LAP"
  end
  self.splitText:SetText(text)
  -- Green when you improved, gold when you did not: readable at a glance
  -- without having to parse the number.
  self.splitText:SetTextColor(unpack((not delta or delta <= 0) and AK.COLORS.lime or AK.COLORS.gold))
  self.splitUntil = now() + 2.2
end

local ORDINAL = { "1ST", "2ND", "3RD", "4TH", "5TH", "6TH", "7TH", "8TH" }
function RaceUI:Ordinal(place)
  return ORDINAL[place] or ((place or 0) .. "TH")
end

--- The player is home; the race is not over. Chequered flash, a card naming
--- their place, and the ladder slides in to show the rest of the field coming
--- in behind them.
function RaceUI:BeginCooldown(race, place)
  self.checkerUntil = now() + 1.4
  self:Flash({ 1, 1, 1 }, .25)
  self:Shake(10)
  if self.finishCard then
    self.finishCard:SetText("FINISHED " .. self:Ordinal(place))
    self.finishCard:SetTextColor(unpack(place <= 3 and AK.COLORS.gold or AK.COLORS.muted))
  end
  self.finishUntil = now() + 2.0
  self.ladderIn = now()
  if self.ladder then self.ladder:Show() end
end

--- Fills the ladder in from the real finishing order, then lists whoever is
--- still out there in running order underneath. Called every frame from the
--- moment the player crosses.
function RaceUI:UpdateLadder(race)
  if not self.ladder or not self.ladder:IsShown() then return end
  -- Slide and fade in over a third of a second, from the right edge.
  local age = now() - (self.ladderIn or 0)
  local ease = AK.Math.Clamp(age / 0.35, 0, 1)
  ease = 1 - (1 - ease) * (1 - ease)
  self.ladder:SetAlpha(ease)
  self.ladder:ClearAllPoints()
  self.ladder:SetPoint("RIGHT", -30 + (1 - ease) * 60, 20)

  -- Dim the world in step with the fast-forward. Real time stays clear.
  if self.cooldownScrim then
    local rate = (race.cooldown and race.cooldown.rate) or 1
    self.cooldownScrim:SetAlpha(AK.Math.Clamp((rate - 1.5) / 7, 0, 0.55) * ease)
  end

  local rows = self.ladderRows
  local order = race.ordered or race.vehicles
  for index, row in ipairs(rows) do
    local vehicle = order[index]
    if vehicle then
      local home = vehicle.finished
      row.place:SetText(self:Ordinal(index))
      row.name:SetText(vehicle.racer and vehicle.racer.name or "")
      if home then
        row.time:SetText(self:FormatTime(vehicle.finishTime or 0))
        row.time:SetTextColor(.86, .90, 1)
      else
        -- Still on circuit: how far back, in the same units the HUD uses.
        local leader = order[1]
        local gap = leader and leader.finishTime
          and (race.elapsed - leader.finishTime) or 0
        row.time:SetText(gap > 0 and ("+%.1fs"):format(gap) or "--")
        row.time:SetTextColor(unpack(AK.COLORS.muted))
      end
      local isPlayer = vehicle == race.player
      row.bg:SetVertexColor(isPlayer and 0.10 or 0.07, isPlayer and 0.26 or 0.10,
        isPlayer and 0.18 or 0.16, home and 0.95 or 0.35)
      row.tag:SetVertexColor(unpack(isPlayer and AK.COLORS.lime
        or (index == 1 and AK.COLORS.gold or { .3, .36, .46, 1 })))
      row.place:SetTextColor(unpack(index == 1 and AK.COLORS.gold or AK.COLORS.muted))
      row.name:SetAlpha(home and 1 or 0.6)
      row:Show()
    else
      row:Hide()
    end
  end
end

--- The one thing that could not be known when the player crossed: whether the
--- kart behind was close enough to make it a photo finish.
function RaceUI:PhotoFinishCard(photo)
  if not self.finishCard or not photo then return end
  self.finishCard:SetText(("PHOTO FINISH\n%s %s BY %.2fs")
    :format(photo.won and "BEAT" or "LOST TO", photo.rival:upper(), photo.margin))
  self.finishCard:SetTextColor(unpack(photo.won and AK.COLORS.lime or AK.COLORS.gold))
  self.finishUntil = now() + 2.4
  self:Shake(14)
end

--- Close the screen over a recovery and open it again on the other side.
---
--- The simulation's fall runs FALL_TIME, then repositions, then holds for
--- LIFT_TIME + DROP_TIME. The veil has to be FULLY closed at the reposition --
--- that is the single frame with a cut in it -- so it shuts over the fall and
--- opens over the set-down. Read from AK.Race so the two cannot drift: the
--- renderer asking "how far through is this" beats the renderer keeping its own
--- copy of a timeline the simulation owns.
function RaceUI:UpdateRecovery(race)
  if not self.recoveryVeil then return end
  local player = race.player
  local falling = player and player.falling
  if not falling or player.finished then
    self.recoveryVeil:SetAlpha(0)
    return
  end
  local closeBy = AK.Race.FALL_TIME
  local openFrom = closeBy + AK.Race.LIFT_TIME
  local total = openFrom + AK.Race.DROP_TIME
  local alpha
  if falling < closeBy then
    -- Shutting. Eased so the last of it is quick and the cut lands in the dark.
    alpha = AK.Math.Clamp(falling / closeBy, 0, 1) ^ 0.7
  elseif falling < openFrom then
    alpha = 1
  else
    alpha = 1 - AK.Math.Clamp((falling - openFrom) / math.max(0.01, total - openFrom), 0, 1)
  end
  self.recoveryVeil:SetAlpha(alpha)
end

--- Chequered flash plus the position card, held before the results screen.
function RaceUI:FinishSequence(position, photo)
  local ordinal = { "1ST", "2ND", "3RD" }
  self.checkerUntil = now() + 1.1
  if self.finishCard then
    local text = "FINISHED " .. (ordinal[position] or (position .. "TH"))
    -- A race decided by a third of a second deserves to be named as such. This
    -- is the difference between "you came 3rd" and a story you retell.
    if photo then
      text = text .. "\n" .. ("PHOTO FINISH -- %s %s BY %.2fs")
        :format(photo.won and "BEAT" or "LOST TO", photo.rival:upper(), photo.margin)
    end
    self.finishCard:SetText(text)
    self.finishCard:SetTextColor(unpack(photo and AK.COLORS.lime
      or (position <= 3 and AK.COLORS.gold or AK.COLORS.muted)))
  end
  if photo then self:Shake(14) end
  self.finishUntil = now() + 2.4
  self:Flash({ 1, 1, 1 }, .25)
  self:Shake(10)
end

function RaceUI:ShowWrongWay(active)
  self.wrongWayUntil = active and (now() + 0.6) or nil
end

--- Draw whatever beats are still live. Sizes come off the screen every frame,
--- so nothing here can shrink into specks at a higher resolution.
function RaceUI:UpdatePresentation(race, dt)
  local t = now(race)
  local w, h = self.halfWidth * 2, self.halfHeight * 2
  local reduced = AK.db.settings.reducedEffects

  -- Start gantry.
  if self.startLights then
    local live = self.lightsLit ~= nil and (not self.lightsUntil or t < self.lightsUntil)
    self.startLights:SetShown(live)
    if live then
      -- DESIGN UNITS, from the HUD table. These were `h * 0.055` and
      -- `-h * 0.20` off the FRAME's height in real pixels, applied inside a
      -- coordinate space scaled to 1600x900 -- so the gantry was only ever the
      -- right size in the right place at exactly the design resolution. At
      -- 1440p that arithmetic gives a 127-pixel lamp four hundred and sixty
      -- pixels down the screen.
      local lampSize = HUD.lights.h / 1.7
      local gap = lampSize * 1.5
      self.startLights:ClearAllPoints()
      placeHud(self.startLights, HUD.lights)
      self.startLights:SetSize(HUD.lights.w, HUD.lights.h)
      for i, lamp in ipairs(self.startLights.lamps) do
        local x = (i - 2) * gap
        local on = self.lightsGreen or i <= (self.lightsLit or 0)
        local bulb = self.startLights.bulbs[i]
        bulb:SetSize(lampSize * 0.92, lampSize * 0.92)
        bulb:ClearAllPoints()
        bulb:SetPoint("CENTER", self.startLights, "CENTER", x, 0)
        -- A lit bulb takes some of its own colour, so the dark disc under the
        -- glow does not grey it out.
        if self.lightsGreen then
          bulb:SetVertexColor(0.06, 0.20, 0.10, 1)
        elseif on then
          bulb:SetVertexColor(0.22, 0.05, 0.05, 1)
        else
          bulb:SetVertexColor(0.07, 0.07, 0.09, 1)
        end
        lamp:SetSize(lampSize, lampSize)
        lamp:ClearAllPoints()
        lamp:SetPoint("CENTER", self.startLights, "CENTER", x, 0)
        if self.lightsGreen then
          lamp:SetVertexColor(0.30, 1.0, 0.38, 1)
          lamp:SetAlpha(0.95)
        else
          lamp:SetVertexColor(1.0, 0.22, 0.18, 1)
          lamp:SetAlpha(on and 0.95 or 0.10)
        end
        local bezel = self.startLights.bezels[i]
        bezel:SetSize(lampSize * 1.18, lampSize * 1.18)
        bezel:ClearAllPoints()
        bezel:SetPoint("CENTER", self.startLights, "CENTER", x, 0)
        -- The rim catches the lamp it is holding.
        if self.lightsGreen then
          bezel:SetVertexColor(0.52, 0.78, 0.56, 1)
        elseif on then
          bezel:SetVertexColor(0.78, 0.46, 0.42, 1)
        else
          bezel:SetVertexColor(0.34, 0.37, 0.44, 1)
        end
      end
    end
  end

  -- Final-lap urgency: gold corners, breathing. Suppressed entirely under
  -- reduced effects, like every other full-screen treatment.
  if self.urgency then
    local finalLap = race and race.player and race.laps
      and race.player.lap == race.laps and not race.player.finished
    local target = (finalLap and not reduced) and (0.10 + 0.06 * math.sin(t * 3.4)) or 0
    self.urgencyAlpha = AK.Math.Lerp(self.urgencyAlpha or 0, target, math.min(1, (dt or 0.016) * 3))
    self.urgency:SetAlpha(self.urgencyAlpha)
    self.finalLapUrgency = finalLap and not reduced
  end

  -- Lap split.
  if self.splitText then
    local left = (self.splitUntil or 0) - t
    self.splitText:ClearAllPoints()
    self.splitText:SetPoint("TOP", self.frame, "TOP", 0, -h * 0.155)
    self.splitText:SetAlpha(AK.Math.Clamp(left / 0.5, 0, 1))
  end

  -- Chequered flash: alternating cells sweeping the top and bottom edges.
  if self.checker then
    local left = (self.checkerUntil or 0) - t
    local live = left > 0
    local cell = w / 12
    for i, tile in ipairs(self.checker) do
      tile:SetShown(live)
      if live then
        local col = (i - 1) % 12
        local row = math.floor((i - 1) / 12)
        local dark = ((col + row) % 2) == 0
        tile:SetVertexColor(dark and 0.05 or 1, dark and 0.05 or 1, dark and 0.06 or 1, 1)
        tile:ClearAllPoints()
        tile:SetPoint("TOPLEFT", self.frame, "TOPLEFT", col * cell,
          row == 0 and 0 or -(h - cell * 0.7))
        tile:SetSize(cell, cell * 0.7)
        tile:SetAlpha(AK.Math.Clamp(left / 0.35, 0, 1) * 0.85)
      end
    end
  end

  -- Position card.
  if self.finishCard then
    local left = (self.finishUntil or 0) - t
    local alpha = AK.Math.Clamp(left / 0.4, 0, 1)
    self.finishCard:ClearAllPoints()
    self.finishCard:SetPoint("CENTER", self.frame, "CENTER", 0, h * 0.06)
    self.finishCard:SetAlpha(alpha)
    -- The plate takes its size from the card's own string, so it fits a one
    -- line placing and a two line photo finish without either being told about
    -- the other. Hidden outright at zero rather than left as an invisible
    -- rectangle, because a texture at alpha 0 still costs a draw every frame.
    if self.finishPlate then
      local cardW = self.finishCard:GetStringWidth() + 56
      local cardH = self.finishCard:GetStringHeight() + 26
      self.finishPlate:ClearAllPoints()
      self.finishPlate:SetPoint("CENTER", self.finishCard, "CENTER", 0, 0)
      self.finishPlate:SetSize(math.max(2, cardW), math.max(2, cardH))
      self.finishPlate:SetAlpha(alpha * 0.72)
      self.finishPlate:SetShown(alpha > 0.01)
      self.finishEdge:SetSize(math.max(2, cardW), 2)
      self.finishEdge:SetAlpha(alpha * 0.9)
      self.finishEdge:SetShown(alpha > 0.01)
    end
  end

  -- Beat name, while /kart beats is running.
  if self.beatLabel then
    local left = (self.beatUntil or 0) - t
    self.beatLabel:ClearAllPoints()
    self.beatLabel:SetPoint("BOTTOM", self.frame, "BOTTOM", 0, h * 0.13)
    self.beatLabel:SetAlpha(AK.Math.Clamp(left / 0.4, 0, 1))
  end

  -- SPINY SHELL INCOMING. Dread has to build, so this is driven by the shell's
  -- closing TIME rather than by a fixed flash: the pulse accelerates and the
  -- vignette deepens as it arrives, and the caption tells you the out. A player
  -- who knows a boost saves them has a decision; one who does not just loses.
  if self.spinyWarn then
    local eta = race and race.spinyEta
    local live = eta ~= nil and eta < 6
    self.spinyWarn:ClearAllPoints()
    self.spinyWarn:SetPoint("TOP", self.frame, "TOP", 0, -h * 0.36)
    if live then
      local urgency = AK.Math.Clamp(1 - eta / 6, 0, 1)
      local beat = 0.5 + 0.5 * math.sin(t * (7 + urgency * 22))
      self.spinyWarn:SetText(eta < 2.2 and "BOOST NOW" or "SPINY SHELL INCOMING")
      self.spinyWarn:SetTextColor(1, 0.30 + 0.25 * (1 - urgency), 0.22)
      self.spinyWarn:SetAlpha((0.45 + 0.55 * beat) * (0.5 + 0.5 * urgency))
    else
      self.spinyWarn:SetAlpha(0)
    end
  end

  -- Wrong way.
  if self.wrongWay then
    local live = self.wrongWayUntil and t < self.wrongWayUntil
    self.wrongWay:ClearAllPoints()
    self.wrongWay:SetPoint("TOP", self.frame, "TOP", 0, -h * 0.28)
    self.wrongWay:SetText(live and "WRONG WAY" or "")
    self.wrongWay:SetAlpha(live and (0.55 + 0.45 * math.sin(t * 14)) or 0)
  end
end

--- Fire every beat in sequence, two seconds apart, with no race running.
---
--- These moments are, by nature, things you see once a lap at most and cannot
--- summon on demand -- which makes them almost impossible to judge or to
--- screenshot. This plays the whole set to an empty track.
function RaceUI:PlayBeats()
  if not self.frame or not self.frame:IsShown() then
    AK:Print("The beats play over the race scene, so start a race first "
      .. "(|cffffd100/kart race|r) and press the |cffffd100BEATS|r button on the right.")
    return
  end
  local steps = {
    { "start lights: 1", function() self:SetStartLights(1, false) end },
    { "start lights: 2", function() self:SetStartLights(2, false) end },
    { "start lights: 3", function() self:SetStartLights(3, false) end },
    { "GO", function()
        self:SetStartLights(3, true)
        self:Flash(AK.COLORS.lime, .22)
        self:Announce("GO!", AK.COLORS.lime)
      end },
    { "rocket start", function()
        self:Announce("ROCKET START!", AK.COLORS.gold)
        self:LaunchEffect(AK.COLORS.gold, true)
        self:Shake(14)
      end },
    { "false start", function()
        self:Announce("FALSE START!", AK.COLORS.danger)
        self:Shake(10)
      end },
    { "lap split (improved)", function() self:ShowLapSplit(2, 41.28, 42.60) end },
    { "lap split (slower)", function() self:ShowLapSplit(3, 43.90, 41.28) end },
    { "final lap", function()
        self:Announce("FINAL LAP!", AK.COLORS.gold)
        self:Flash(AK.COLORS.gold, .18)
      end },
    { "wrong way", function() self.wrongWayUntil = (AK.Race.current and AK.Race.current.elapsed or GetTime()) + 2.0 end },
    { "finish", function() self:FinishSequence(2) end },
  }
  AK:Print("Playing " .. #steps .. " race beats, one every 2s.")
  for index, step in ipairs(steps) do
    C_Timer.After((index - 1) * 2, function()
      if not self.frame or not self.frame:IsShown() then return end
      AK:Print("  " .. step[1])
      if self.beatLabel then
        self.beatLabel:SetText(("%d/%d   %s"):format(index, #steps, step[1]:upper()))
        self.beatUntil = ((AK.Race.current or {}).elapsed or GetTime()) + 1.9
      end
      step[2]()
    end)
  end
  -- Put the gantry away once the run is over so it does not sit on screen.
  C_Timer.After(#steps * 2 + 1, function()
    self:SetStartLights(nil, false)
    if self.beatLabel then self.beatLabel:SetText("") end
  end)
end

function RaceUI:Flash(color, alpha)
  if not self.flash or AK.db.settings.reducedEffects then return end
  self.flash:SetVertexColor(unpack(color or AK.COLORS.gold))
  self.flashAlpha = math.max(self.flashAlpha or 0, alpha or .12)
end

function RaceUI:FormatTime(seconds)
  local minutes = math.floor(seconds / 60)
  return string.format("%02d:%05.2f", minutes, seconds - minutes * 60)
end

-- --------------------------------------------------------------------------
-- Particles
-- --------------------------------------------------------------------------

--- Emit one screen-space particle. Positions are already projected, so sparks
--- inherit the perspective of whatever spawned them without extra maths.
function RaceUI:Emit(x, y, size, color, life, vx, vy, gravity)
  if AK.db.settings.reducedEffects then return end
  local texture = table.remove(self.particlePool)
  if not texture then return end
  local particle = {
    texture = texture, x = x, y = y, vx = vx, vy = vy,
    gravity = gravity or -420, size = size, life = life, maxLife = life, color = color,
  }
  texture:SetVertexColor(color[1], color[2], color[3], 1)
  texture:Show()
  table.insert(self.particles, particle)
end

-- Effect presets: start scale, end scale, lifetime, spin per second.
local EFFECTS = {
  burst   = { file = "burst.tga", from = 0.35, to = 2.10, life = 0.34, spin = 2.2 },
  shock   = { file = "shock.tga", from = 0.15, to = 3.20, life = 0.50, spin = 0.0 },
  pop     = { file = "burst.tga", from = 0.20, to = 1.15, life = 0.26, spin = -3.0 },
  bloom   = { file = "glow.tga",  from = 0.60, to = 2.60, life = 0.55, spin = 0.0 },
}

--- Fire a one-shot effect sprite at a screen position.
function RaceUI:PlayEffect(kind, x, y, size, color)
  if AK.db.settings.reducedEffects then return end
  local preset = EFFECTS[kind]
  if not preset then return end
  local texture = table.remove(self.effectPool)
  if not texture then return end
  texture:SetTexture(ART .. preset.file)
  texture:SetVertexColor(color[1], color[2], color[3], 1)
  texture:Show()
  table.insert(self.effects, {
    texture = texture, x = x, y = y, size = size, preset = preset,
    life = preset.life, maxLife = preset.life, rotation = 0,
  })
end

function RaceUI:UpdateEffects(dt)
  for i = #self.effects, 1, -1 do
    local fx = self.effects[i]
    fx.life = fx.life - dt
    if fx.life <= 0 then
      fx.texture:Hide()
      table.insert(self.effectPool, fx.texture)
      table.remove(self.effects, i)
    else
      local t = 1 - fx.life / fx.maxLife
      -- Ease out, so it snaps open and then drifts: a linear expand reads soft.
      local eased = 1 - (1 - t) * (1 - t) * (1 - t)
      local scale = fx.preset.from + (fx.preset.to - fx.preset.from) * eased
      local size = fx.size * scale
      fx.texture:ClearAllPoints()
      fx.texture:SetPoint("CENTER", self.frame, "CENTER", fx.x, fx.y)
      fx.texture:SetSize(size, size)
      fx.texture:SetAlpha((1 - t) * (1 - t))
      if fx.preset.spin ~= 0 and fx.texture.SetRotation then
        fx.rotation = fx.rotation + fx.preset.spin * dt
        fx.texture:SetRotation(fx.rotation)
      end
    end
  end
end

--- The full "something just launched" package at the player's kart.
function RaceUI:LaunchEffect(color, big)
  local x, y, width = self.playerX or 0, self.playerY or 0, self.playerWidth or 60
  self:PlayEffect("burst", x, y + width * 0.45, width * (big and 2.2 or 1.5), color)
  self:PlayEffect("shock", x, y + width * 0.30, width * (big and 2.0 or 1.3), color)
end

--- Ring of sparks off the player's kart when they fire something.
function RaceUI:ItemBurst(color)
  local x, y, width = self.playerX or 0, self.playerY or 0, self.playerWidth or 60
  for i = 1, 26 do
    local angle = (i / 26) * math.pi * 2
    self:Emit(x, y + width * 0.35, width * 0.20, color or AK.COLORS.gold,
      0.45 + math.random() * 0.3,
      math.cos(angle) * (280 + math.random() * 160),
      math.sin(angle) * (240 + math.random() * 160) + 120, -420)
  end
end

function RaceUI:UpdateParticles(dt)
  for i = #self.particles, 1, -1 do
    local particle = self.particles[i]
    particle.life = particle.life - dt
    if particle.life <= 0 then
      particle.texture:Hide()
      table.insert(self.particlePool, particle.texture)
      table.remove(self.particles, i)
    else
      particle.vy = particle.vy + particle.gravity * dt
      particle.x = particle.x + particle.vx * dt
      particle.y = particle.y + particle.vy * dt
      local fade = particle.life / particle.maxLife
      local size = particle.size * (0.3 + fade * 0.7) * self.T.particleScale
      particle.texture:ClearAllPoints()
      particle.texture:SetPoint("CENTER", self.frame, "CENTER", particle.x, particle.y)
      particle.texture:SetSize(size, size)
      particle.texture:SetAlpha(fade * fade)
    end
  end
end

--- Per-vehicle effects driven by state changes since the previous frame.
function RaceUI:VehicleEffects(vehicle, index, x, y, width, isPlayer)
  local previous = self.previous[index]
  if not previous then
    self.previous[index] = { stun = vehicle.stun, boost = vehicle.boostTime, charge = vehicle.driftCharge, lateral = vehicle.lateral }
    return
  end

  local rear = y - width * 0.08
  if vehicle.drifting and vehicle.driftCharge > 0.12 and width > 18 then
    local color = driftColor(vehicle.driftCharge)
    for side = -1, 1, 2 do
      self:Emit(x + side * width * 0.42, rear, width * (0.09 + math.random() * 0.09), color,
        0.26 + math.random() * 0.2,
        side * (40 + math.random() * 110), 60 + math.random() * 150, -520)
    end
  end

  -- Drift charge crossing into a new colour stage. This is the beat the whole
  -- drift mechanic is built around and it had no feedback whatsoever.
  if isPlayer and vehicle.drifting then
    for _, stage in ipairs(DRIFT_STAGES) do
      if stage.threshold > 0 and previous.charge < stage.threshold and vehicle.driftCharge >= stage.threshold then
        -- One cue PER TIER, not one cue for "a tier changed". Rising through
        -- the ladder has to be audibly a ladder: hearing the same blip three
        -- times tells you something happened, not what you have earned. This is
        -- the beat you need with your eyes still on the corner.
        if AK.PlaySfx then AK:PlaySfx("driftTier" .. stage.tier) end
        self:PlayEffect("pop", x, rear, width * 1.1, stage.color)
        self:Shake(2 + stage.tier * 2)
      end
    end
  end

  if previous.charge > 0.5 and vehicle.driftCharge < previous.charge - 0.3 then
    local color = driftColor(previous.charge)
    for _ = 1, 16 do
      local angle = math.random() * math.pi * 2
      self:Emit(x, rear, width * 0.14, color, 0.4 + math.random() * 0.3,
        math.cos(angle) * 260, math.abs(math.sin(angle)) * 300 + 60, -560)
    end
    if isPlayer then self:Shake(7) end
  end

  if vehicle.boostTime > 0 and width > 16 then
    for _ = 1, 2 do
      self:Emit(x + (math.random() - .5) * width * 0.7, rear, width * (0.10 + math.random() * 0.12),
        { 1, 0.55 + math.random() * 0.35, 0.15 }, 0.3 + math.random() * 0.25,
        (math.random() - .5) * 90, 130 + math.random() * 190, -430)
    end
    if previous.boost <= 0 and isPlayer then self:Shake(9) end
  end

  if vehicle.offroad and width > 16 then
    self:Emit(x + (math.random() - .5) * width * 0.9, rear, width * 0.11,
      { 0.62, 0.52, 0.34 }, 0.35, (math.random() - .5) * 130, 90 + math.random() * 120, -480)
  end

  if vehicle.stun > previous.stun + 0.05 then
    for _ = 1, 14 do
      local angle = math.random() * math.pi * 2
      self:Emit(x, y + width * 0.3, width * 0.16, { 1, 0.85, 0.45 }, 0.35 + math.random() * 0.25,
        math.cos(angle) * 320, math.sin(angle) * 320 + 90, -600)
    end
    if isPlayer then self:Shake(18) end
  end

  previous.stun, previous.boost, previous.charge = vehicle.stun, vehicle.boostTime, vehicle.driftCharge
end

-- --------------------------------------------------------------------------
-- Scene
-- --------------------------------------------------------------------------

function RaceUI:RenderSky(race, camX)
  -- UNDER A MOUNTAIN THERE IS NO SKY.
  --
  -- The tunnel fill is a full-screen quad on BACKGROUND sublevel 6, so it does
  -- cover the sky, the clouds, the ridges and the treeline -- but only in
  -- proportion to how far in you are, and `self.haze` sits a whole layer above
  -- it on BORDER and was only ever dimmed, not hidden. The result in a tunnel
  -- was a pale horizon band straight across the rock, with the odd ridge behind
  -- it. Everything that belongs to the horizon is now taken down together, by
  -- the same cover value the rock fades in with.
  local cover = self.tunnelDepth or 0
  local outside = AK.Math.Clamp(1 - cover * 1.35, 0, 1)
  self.skylineAlpha = outside
  local horizon = self.T.horizon
  local screenW = self.halfWidth * 2
  local screenH = self.halfHeight * 2
  local grassColor = race.track.color or { .16, .40, .18 }
  local glow = race.track.glow or { 1, .93, .72 }
  local light = (self.light or 1) * self.T.nightBoost
  local drift = -camX * 6

  self.skyGlow:SetAlpha(0.55)

  local skyTint = race.track.skyLow or { .8, .88, .96 }
  for i, band in ipairs(self.clouds) do
    local spread = self.halfWidth * 3
    local scale = 0.55 + ((i * 37) % 70) / 70
    local x = ((i * 263 + drift * .5 + race.elapsed * (2 + i % 5)) % spread) - spread * .5
    local y = horizon + screenH * 0.08 + ((i * 83) % math.floor(screenH * 0.38))
    band:ClearAllPoints()
    band:SetPoint("CENTER", self.frame, "CENTER", x, y)
    -- Cloud size follows the screen; absolute pixels shrink into specks on a
    -- large client, which is exactly what happened to the whole old skyline.
    band:SetSize(screenW * 0.20 * scale, screenW * 0.10 * scale)
    band:SetVertexColor(0.55 + skyTint[1] * 0.45, 0.55 + skyTint[2] * 0.45, 0.58 + skyTint[3] * 0.42, 1)
    band:SetAlpha(self.T.cloudAlpha)
  end

  -- Distant terrain, parallaxed through texture coordinates: the quad never
  -- moves, the ridge slides inside it. Each layer drifts at its own rate --
  -- far ridge slowest, hills faster, tree wall fastest -- which is the whole
  -- trick that turns three flat strips into depth.
  local skyline = self.skyline or {}
  local function scrollRidge(texture, cfg, ridgeDrift)
    if not cfg or not texture:IsShown() then return end
    -- The art is 4:1, so one repeat covers four times its drawn height.
    local repeatPx = math.max(1, screenH * cfg.h * 4)
    local u0 = -ridgeDrift / repeatPx
    texture:SetTexCoord(u0, u0 + screenW / repeatPx, 0, 1)
    local tint = cfg.tint
    texture:SetVertexColor(tint[1] * light, tint[2] * light, tint[3] * light, 1)
    texture:SetAlpha(cfg.a or 1)
  end
  scrollRidge(self.mountain, skyline.mtn, -camX * 1.1)
  scrollRidge(self.hillLine, skyline.hill, -camX * 2.0)

  -- Near wall: conifers, spires or void-shards depending on the track.
  local treeDrift = -camX * 3.4
  local spread = self.halfWidth * 2.4
  local slice = spread / TREES
  local oribos = race.track.style == "oribos"
  local spirey = oribos or skyline.treeArt ~= nil
  local treeTint = skyline.treeTint

  -- The ring hangs behind everything, drifting only slightly: it is enormous
  -- and far away, so it must barely move relative to the spires.
  self.ring:SetShown(oribos)
  if oribos then
    self.ring:ClearAllPoints()
    self.ring:SetPoint("BOTTOM", self.frame, "CENTER", -camX * 0.9, horizon - 40)
    self.ring:SetSize(self.halfWidth * 1.9, self.halfWidth * 1.9)
    self.ring:SetVertexColor(0.72 * light, 0.66 * light, 0.86 * light, 1)
    self.ring:SetAlpha(0.55)
  end

  -- Aerial perspective on the near wall. The old code made far trees DARKER,
  -- which raises their contrast against a pale horizon -- the opposite of what
  -- distance does, and why the back row read as a stencil cut out of the sky.
  -- Distance washes a silhouette toward the colour of the air in front of it,
  -- so that is what this does, mixing toward the horizon between sky and glow.
  local wash = {
    (skyTint[1] * 0.6 + glow[1] * 0.4) * light,
    (skyTint[2] * 0.6 + glow[2] * 0.4) * light,
    (skyTint[3] * 0.6 + glow[3] * 0.4) * light,
  }
  for i, tree in ipairs(self.trees) do
    local seed = self.treeSeed[i]
    -- The offset belongs to the SLOT, not to a position, so a tree keeps its
    -- own spacing as the row wraps: irregular, but it never crawls or shuffles.
    local x = ((i * slice + seed.x * slice * 0.9 + treeDrift) % spread) - spread * .5
    -- Depth is continuous rather than "every third one is a back row". Two
    -- discrete rows is still a pattern, and the eye finds a pattern instantly.
    local depth = seed.d
    tree:ClearAllPoints()
    -- All heights are fractions of the screen, never absolute pixels.
    local height = (spirey and (0.085 + seed.h * 0.240) or (0.034 + seed.h * 0.105))
      * screenH * self.T.treeHeight * (1 - depth * 0.34)
    tree:SetPoint("BOTTOM", self.frame, "CENTER", x, horizon - screenH * (0.004 + depth * 0.017))
    tree:SetSize(height * (spirey and 0.26 or 0.5) * (0.80 + seed.w * 0.44), height)
    local tone = (spirey and 0.68 or 0.92) * (1 - depth * 0.12) * light
    local r, g, b
    if oribos then
      r, g, b = tone * 0.80, tone * 0.70, tone * 1.15
    elseif treeTint then
      r, g, b = tone * treeTint[1], tone * treeTint[2], tone * treeTint[3]
    else
      -- Tracks with no treeTint of their own: a plain forest green. This was
      -- (0.8, 1.0, 0.86), a near-white nudge that only worked at all because
      -- the art underneath it was already dark green. It is not any more.
      r, g, b = tone * 0.30, tone * 0.52, tone * 0.31
    end
    local haze = depth * 0.40
    tree:SetVertexColor(
      r + (wash[1] - r) * haze,
      g + (wash[2] - g) * haze,
      b + (wash[3] - b) * haze, 1)
  end

  -- Enough haze to soften the horizon seam. Too little and ground meets sky on
  -- a hard cut line, which is the strongest "flat 2D" tell in the scene.
  --
  -- SetVertexColor WIPES THE GRADIENT. They are the same per-vertex state, so
  -- tinting these two here -- which is what the last three lines used to do --
  -- threw away the fade-to-nothing built onto them at construction and left a
  -- FLAT translucent slab seventeen per cent of the screen tall, with hard
  -- edges, laid exactly across the horizon. Photographed off a Deadmines run it
  -- is a lavender band ruled over the far field, the walls and the sky
  -- together: the very thing the gradient exists to prevent, and a good part of
  -- "hard to see in the distance".
  --
  -- The colour goes on first so a client without SetGradient still gets a tint,
  -- and the gradient goes on second carrying the same colour and the fade.
  local hr, hg, hb = glow[1] * .8, glow[2] * .8, glow[3] * .85
  self.hazeBelow:SetVertexColor(hr, hg, hb, .30)
  applyGradient(self.hazeBelow, "VERTICAL", hr, hg, hb, 0, hr, hg, hb, .30)
  self.hazeAbove:SetVertexColor(hr, hg, hb, .30)
  applyGradient(self.hazeAbove, "VERTICAL", hr, hg, hb, .30, hr, hg, hb, 0)
  -- Aerial perspective on the ground itself: sky-tinted and pale at the
  -- horizon, full colour at the bottom edge. A flat fill was the single
  -- biggest "the world is a sheet" tell in every screenshot.
  local ground = shade(grassColor, 0.62 * light)
  local hazeMix = {
    (skyTint[1] * .5 + glow[1] * .5) * light,
    (skyTint[2] * .5 + glow[2] * .5) * light,
    (skyTint[3] * .5 + glow[3] * .5) * light,
  }
  self.ground:SetVertexColor(1, 1, 1, 1)
  applyGradient(self.ground, "VERTICAL",
    ground[1], ground[2], ground[3], 1,
    ground[1] * .28 + hazeMix[1] * .72, ground[2] * .28 + hazeMix[2] * .72, ground[3] * .28 + hazeMix[3] * .72, 1)

  -- Take the whole horizon down together. Alpha rather than Hide, so entering
  -- and leaving a tunnel is a transition rather than a switch -- and applied
  -- last, so nothing above has just set an alpha of its own back to 1.
  if outside < 1 then
    self.sky:SetAlpha(outside)
    self.skyGlow:SetAlpha(0.55 * outside)
    self.mountain:SetAlpha((skyline.mtn and skyline.mtn.a or 1) * outside)
    self.hillLine:SetAlpha((skyline.hill and skyline.hill.a or 1) * outside)
    self.ring:SetAlpha(0.55 * outside)
    for _, cloud in ipairs(self.clouds) do cloud:SetAlpha(self.T.cloudAlpha * outside) end
    for _, tree in ipairs(self.trees) do tree:SetAlpha(outside) end
    self.ground:SetAlpha(outside)
  else
    self.sky:SetAlpha(1)
    self.ground:SetAlpha(1)
    for _, tree in ipairs(self.trees) do tree:SetAlpha(1) end
  end
end

--- Drive-through arches. Same rolling-window trick as the posts.
---
--- This used to let the quad grow until it engulfed the screen, on the argument
--- that engulfing you is what sells "you went under that". Rendered, it does
--- not: a billboard cannot pass overhead, so all the growth buys is two hard
--- vertical bars pinned to the edges of the display. It is dropped at 6m
--- instead -- see the note at the near cutoff below.
function RaceUI:RenderArches(race, camX, camZ)
  local spacing = race.track.archSpacing
  if not spacing then
    for _, arch in ipairs(self.arches) do setShown(arch, false) end
    return
  end
  local tuning = self.T
  local light = (self.light or 1) * tuning.nightBoost
  -- Further out than the posts, because an arch is a 17m structure you drive
  -- through and want to see coming -- but nothing like the 297m it used to use,
  -- where the road is on screen only 40% of a lap.
  -- Pulled in twice as the circuits got firmer corners. A tighter lap swings
  -- the road off the side of the screen sooner, so an arch spawned at 149m was
  -- faded away 58% of the time -- put into space the road has already left. At
  -- 92m it is still a second and a half of warning, and it is on screen.
  local archFar = reach(92)
  local phase = self:GridPhase(self.route or race.track, spacing)
  local first = math.ceil((camZ - phase) / spacing)
  for slot, arch in ipairs(self.arches) do
    local index = first + slot - 1
    local archZ = index * spacing + phase
    local dz = archZ - camZ
    -- Dropped once you are underneath it, not at 0.6m. An arch is a flat
    -- billboard 17m wide, and its projected size grows without bound as dz
    -- falls -- at a metre out it is thousands of pixels across, so what the
    -- player actually saw was two hard vertical bars pinned to the left and
    -- right edges of the screen, sliding as they passed. A real gateway leaves
    -- the frame overhead; a billboard cannot, so it stops being drawn instead.
    -- By 6m the top of a 13m arch is already well above the screen.
    if dz > 6 and dz < archFar then
      local worldX, worldY = self:RoadAt(self.route or race.track, archZ)
      local x, y, pixelsPerMetre = self:Project(dz, worldX, camX, worldY)
      -- 17m wide, 13m tall; the art's opening lines up with the road.
      local width = pixelsPerMetre * 17
      local fog = AK.Math.Clamp(1 - (dz / HAZE_Z) * tuning.fogStrength * 0.8, 0.3, 1) * light
      arch:ClearAllPoints()
      arch:SetPoint("BOTTOM", self.frame, "CENTER", x, y)
      arch:SetSize(width, width * 0.95)
      arch:SetVertexColor(self:Aerial(1, 0.98, 1.02, fog, dz))
      arch:SetAlpha(self:DepthFade(dz, archFar) * self:EdgeFade(x, dz))
      setShown(arch, true)
    else
      setShown(arch, false)
    end
  end
end

--- Marker posts along both verges, from a rolling window ahead of the camera.
--- Where a route's evenly-spaced roadside furniture starts counting from.
---
--- Posts, arches and the crowd are all laid out at whole multiples of their own
--- spacing measured from the route's zero. A branch's zero is the split, and the
--- split is at some arbitrary distance along the main line -- so the moment you
--- committed, every post, arch and spectator ahead of you slid sideways by up
--- to a whole spacing at once. On top of a forest that changed at the same
--- instant, that is the "port". Offsetting a branch's grid by where its own
--- zero falls on the parent keeps every one of them standing still.
function RaceUI:GridPhase(route, spacing)
  if not route or not route.parent or not spacing or spacing <= 0 then return 0 end
  return (route.entry or 0) % spacing
end

function RaceUI:RenderPosts(race, camX, camZ)
  local tuning = self.T
  local spacing = math.max(2, tuning.postSpacing)
  -- The same band the pickups use, because it is the same question: how far
  -- ahead is the road still ON SCREEN? Measured, the worst track keeps it there
  -- 93% of the lap at 88m and 42% at the 264m these were drawn to -- so well
  -- over half of every post spawned out there was never seen, and the ones that
  -- were came in from the side of the display. The speed cue posts exist for
  -- comes from the ones sweeping past inside 40m.
  local postFar = reach(88)
  local phase = self:GridPhase(self.route or race.track, spacing)
  local first = math.ceil((camZ - phase) / spacing)
  for slot, pair in ipairs(self.posts) do
    local index = first + slot - 1
    local segZ = index * spacing + phase
    local dz = segZ - camZ
    if dz > 1 and dz < postFar then
      local worldX, worldY = self:RoadAt(self.route or race.track, segZ)
      local x, y, pixelsPerMetre = self:Project(dz, worldX, camX, worldY)
      local halfWidthPixels = pixelsPerMetre * tuning.roadHalf * AK.Math.RoadWidth(self.route or race.track, segZ)
      -- Posts are the second-brightest flicker in a frame difference: a
      -- one-pixel white bar, redrawn a whole pixel left or right every frame
      -- once its true width drops under one. See thinLine.
      local width, thin = thinLine(pixelsPerMetre * 0.18)
      local height = math.max(2, pixelsPerMetre * 1.15)
      local fog = AK.Math.Clamp(1 - (dz / HAZE_Z) * tuning.fogStrength, 0.22, 1)
      -- Alternating colour so the posts strobe past rather than blur together.
      local red = (index % 2 == 0)
      local r, g, b = red and .88 or .95, red and .26 or .95, red and .20 or .96
      local offset = halfWidthPixels + width * 2.2
      -- Faded on each post's OWN screen position, not the road centre's: on the
      -- outside of a bend the far verge is a long way further off-axis than the
      -- middle of the road, and it is the outer post that streams in from the
      -- edge first. These are the most numerous thing in the scene -- a pair
      -- every `postSpacing` metres, out to 0.8 of the draw distance -- so they
      -- were the loudest source of "stuff sliding in from the side".
      pair.left:ClearAllPoints()
      pair.left:SetPoint("BOTTOM", self.frame, "CENTER", x - offset, y)
      pair.left:SetSize(width, height)
      pair.left:SetVertexColor(self:Aerial(r, g, b, fog, dz))
      local near = self:DepthFade(dz, postFar)
      pair.left:SetAlpha(near * thin * self:EdgeFade(x - offset, dz))
      setShown(pair.left, true)
      pair.right:ClearAllPoints()
      pair.right:SetPoint("BOTTOM", self.frame, "CENTER", x + offset, y)
      pair.right:SetSize(width, height)
      pair.right:SetVertexColor(self:Aerial(r, g, b, fog, dz))
      pair.right:SetAlpha(near * thin * self:EdgeFade(x + offset, dz))
      setShown(pair.right, true)
    else
      setShown(pair.left, false)
      setShown(pair.right, false)
    end
  end
end

--- Start/finish line, drawn at the next lap boundary ahead of the camera.
function RaceUI:RenderFinish(race, camX, camZ)
  local tuning = self.T
  local finish = self.finish
  local length = race.track.length
  local lineZ = math.ceil(camZ / length) * length
  local dz = lineZ - camZ
  -- Kept longer than the scenery -- knowing the line is coming is information,
  -- not decoration -- but pulled in from 248m, where it was on screen under
  -- half the lap and arrived by sliding in from the edge.
  -- Same reason as the arches, and the same measurement: at 0.55 the gantry sat
  -- 182m out and was readable on only 39% of a lap. 92m is still a second and a
  -- half of warning at racing pace, for a landmark the lap counter and the map
  -- have both already told you about.
  local finishFar = reach(92)
  if dz < 0.5 or dz > finishFar then
    setShown(finish, false)
    return
  end

  local worldX, worldY = self:RoadAt(self.route or race.track, lineZ)
  local x, y, pixelsPerMetre = self:Project(dz, worldX, camX, worldY)
  local farWorldX, farWorldY = self:RoadAt(self.route or race.track, lineZ + 2.5)
  local farX, farY = self:Project(dz + 2.5, farWorldX, camX, farWorldY)
  local halfWidthPixels = pixelsPerMetre * tuning.roadHalf * AK.Math.RoadWidth(self.route or race.track, lineZ)
  local bandHeight = math.max(2, farY - y)
  local fog = AK.Math.Clamp(1 - (dz / HAZE_Z) * tuning.fogStrength, 0.25, 1)

  finish:SetFrameLevel(self.frame:GetFrameLevel() + 2 + depthBucket(dz) * 2)
  -- One alpha on the parent, so the checkerboard, both gantry posts, the banner
  -- and the label all fade together rather than the line dissolving in pieces.
  finish:SetAlpha(self:DepthFade(dz, finishFar) * self:EdgeFade(x, dz))
  finish:ClearAllPoints()
  finish:SetPoint("BOTTOM", self.frame, "CENTER", 0, 0)
  finish:SetSize(1, 1)

  -- Checkerboard: 14 columns across the road, two rows deep.
  local columns, rows = 14, 2
  local columnWidth = (halfWidthPixels * 2) / columns
  local rowHeight = bandHeight / rows
  for index, block in ipairs(finish.blocks) do
    local column = (index - 1) % columns
    local row = math.floor((index - 1) / columns)
    if row < rows then
      -- Lerp toward the far edge so the band follows the road's curve.
      local blend = (row + 0.5) / rows
      local centre = x + (farX - x) * blend
      local shadeValue = ((column + row) % 2 == 0) and 0.97 or 0.09
      block:ClearAllPoints()
      block:SetPoint("BOTTOM", self.frame, "CENTER",
        centre - halfWidthPixels + columnWidth * (column + 0.5), y + rowHeight * row)
      block:SetSize(columnWidth + 1, rowHeight + 1)
      block:SetVertexColor(self:Aerial(shadeValue, shadeValue, shadeValue, fog, dz))
      setShown(block, true)
    else
      setShown(block, false)
    end
  end

  -- Overhead gantry. Only worth drawing once it is close enough to read.
  local postWidth = math.max(1, pixelsPerMetre * 0.34)
  local postHeight = pixelsPerMetre * 5.2
  -- Big enough to read, and not so close that the billboard has swollen past
  -- the frame -- the same unbounded near-field growth the arches had. The
  -- checkerboard on the ground keeps drawing right up to the line; it lies flat
  -- and stays where it should. It is the upright gantry that blows up.
  local showGantry = postHeight > 16 and dz > 6
  finish.leftPost:SetShown(showGantry)
  finish.rightPost:SetShown(showGantry)
  finish.banner:SetShown(showGantry)
  finish.bannerEdge:SetShown(showGantry)
  finish.label:SetShown(postHeight > 90)
  if showGantry then
    local span = halfWidthPixels + postWidth * 2
    finish.leftPost:ClearAllPoints()
    finish.leftPost:SetPoint("BOTTOM", self.frame, "CENTER", x - span, y)
    finish.leftPost:SetSize(postWidth, postHeight)
    finish.leftPost:SetVertexColor(self:Aerial(.82, .84, .90, fog, dz))
    finish.rightPost:ClearAllPoints()
    finish.rightPost:SetPoint("BOTTOM", self.frame, "CENTER", x + span, y)
    finish.rightPost:SetSize(postWidth, postHeight)
    finish.rightPost:SetVertexColor(self:Aerial(.82, .84, .90, fog, dz))
    local bannerHeight = math.max(3, pixelsPerMetre * 1.1)
    finish.banner:ClearAllPoints()
    finish.banner:SetPoint("BOTTOM", self.frame, "CENTER", x, y + postHeight - bannerHeight)
    finish.banner:SetSize(span * 2 + postWidth, bannerHeight)
    finish.banner:SetVertexColor(self:Aerial(.10, .14, .22, fog, dz))
    finish.bannerEdge:ClearAllPoints()
    finish.bannerEdge:SetPoint("BOTTOM", self.frame, "CENTER", x, y + postHeight - bannerHeight)
    finish.bannerEdge:SetSize(span * 2 + postWidth, math.max(1, bannerHeight * 0.14))
    finish.bannerEdge:SetVertexColor(self:Aerial(1, .76, .20, fog, dz))
    finish.label:ClearAllPoints()
    finish.label:SetPoint("CENTER", self.frame, "CENTER", x, y + postHeight - bannerHeight * 0.5)
    local player = race.player
    finish.label:SetText(player.lap >= race.laps and "FINISH" or ("LAP " .. math.min(player.lap + 1, race.laps)))
  end
  setShown(finish, true)
end

--- Roadside crowd, projected like everything else. Slots are assigned from a
--- rolling window ahead of the camera so six models cover the whole track.
function RaceUI:RenderSpectators(race, camX, camZ)
  local tuning = self.T
  CROWD_POSES = CROWD_POSES or {
    AK.MODEL.anim.cheer, AK.MODEL.anim.wave,
    AK.MODEL.anim.dance, AK.MODEL.anim.talk,
  }
  -- Skip entirely in attract mode: model budget is reserved for the menu.
  if AK.db.settings.reducedEffects or self.suppressModels then
    for _, seat in ipairs(self.spectators) do setShown(seat, false) end
    return
  end
  -- The crowd is decoration, so it gets the shortest range of the scenery: a
  -- spectator at the old 205m was a faded speck off the side of the screen
  -- half the time, and these are MODELS -- the most expensive thing per head.
  local crowdFar = reach(90)
  -- WHY THE SEAT IS PICKED BY POSITION AND NOT BY LOOP ORDER.
  --
  -- Each seat holds one creature for the whole race, because a model reload
  -- costs a stutter. The seats were then handed out in loop order to a window
  -- of posts that rolls forward as you drive -- so every forty-two metres the
  -- window advanced by one and every post got the SEAT NEXT DOOR, which is a
  -- different person. Stand still and the crowd was fine; drive past it and
  -- each figure cycled through the whole roster: "spectators kind of cycle
  -- through people over and over as you pass by them... a random thing that
  -- keeps glitching into something else".
  --
  -- The window is exactly SPECTATOR_SLOTS people wide, so numbering people
  -- globally and taking that number modulo the slot count hits every seat
  -- exactly once -- a bijection, not a hash with collisions. A given person at
  -- a given spot therefore always draws from the same seat, which means always
  -- the same creature, with no reload anywhere.
  local route = self.route or race.track
  local phase = self:GridPhase(route, SPECTATOR_SPACING)
  local first = math.ceil((camZ - phase) / SPECTATOR_SPACING)
  local used = {}
  for step = 0, CROWD_SPOTS - 1 do
    local index = first + step
    local postZ = index * SPECTATOR_SPACING + phase
    -- How many people are at this spot: one, two or three. Two hashes of
    -- different period summed into three, so the sequence repeats only every
    -- thirty-five spots and all three sizes really do occur -- a pair of
    -- independent coin flips looks varied and almost never lands on three,
    -- which is a crowd of ones and twos with the groups quietly missing.
    local crowd = 1 + (((index * 5) % 7) + ((index * 3) % 5)) % 3
    -- OFF THE ROAD, WHICH IS NOT A CONSTANT WIDTH.
    --
    -- The offset was roadHalf plus 1.8m -- the NOMINAL half-width, ignoring the
    -- width multiplier every circuit varies along its length. Elwynn's ramp is
    -- 1.22 and Deadmines' gallery is wide too, so on exactly the sections a
    -- crowd is worth having the tarmac reached 8.5m and the spectators stood at
    -- 8.8: on the kerb, and with the model drawn about its own centre, half of
    -- them overhanging the racing line.
    --
    -- Measured against the road's ACTUAL half-width, with enough clearance for
    -- the body -- and every jitter below pushes further out, never in.
    local roadEdge = tuning.roadHalf * AK.Math.RoadWidth(route, postZ)
    -- A group stands together, so the whole spot picks one side. Runs of two
    -- and three spots on the same side, rather than strict alternation, which
    -- is the other half of not reading as fence posts.
    -- No division in here on purpose: check.js treats a local computed with one
    -- as world-locked, and `side` is read again by the fork sign's texcoords
    -- further down, where that would read as a tiling bug.
    local side = ((index * 3) % 7 < 3) and -1 or 1
    for member = 0, CROWD_PER_SPOT - 1 do
      local person = index * CROWD_PER_SPOT + member
      local seat = self.spectators[person % SPECTATOR_SLOTS + 1]
      used[seat] = true
      -- Spread along the road as well as across it, so a group of three is a
      -- knot of people rather than a rank.
      local slip = ((person * 13) % 9 - 4) * 0.95
      local dz = postZ + slip - camZ
      if member < crowd and dz > 4 and dz < crowdFar then
        local lateral = side * (roadEdge + CROWD_CLEAR
          + member * 1.45 + ((person * 37) % 23) * 0.11)
        local baseX, worldY = self:RoadAt(route, postZ + slip)
        local x, y, pixelsPerMetre = self:Project(dz, baseX + lateral, camX, worldY)
        -- A crowd is not one height. Keyed by the PERSON, so two people
        -- standing together are two different builds, and so that a given spot
        -- is always the same on every lap.
        local build = 0.86 + ((person * 53) % 29) * 0.011
        local size = AK.Math.Clamp(pixelsPerMetre * tuning.specScale * build, 14, 300)
        -- Who this is and how much clear ground they have, recorded so the
        -- harness can drive past a crowd and check that nobody changes face and
        -- nobody is standing on the tarmac. Both were shipped bugs.
        seat.akPerson, seat.akClear = person, math.abs(lateral) - roadEdge
        seat:ClearAllPoints()
        -- Anchored by CENTRE: a model renders about its own origin, so anchoring
        -- the frame's bottom to the road buries the lower half of the body.
        seat:SetPoint("CENTER", self.frame, "CENTER", x, y + size * 0.34)
        seat:SetSize(size * 2.2, size * 2.2)
        seat:SetFrameLevel(self.frame:GetFrameLevel() + 2 + depthBucket(dz) * 2)
        seat:SetAlpha(self:DepthFade(dz, crowdFar) * self:EdgeFade(x, dz))
        seat.model.akZoom = tuning.specZoom / math.max(0.01, tuning.modelZoom)
        AK.Model:Reframe(seat.model)
        -- Turned toward the road, but not all to exactly the same degree, and
        -- people in a group are not all facing the same way as each other.
        seat.model:SetFacing((side > 0 and -1.35 or 1.35)
          + (((person * 31) % 17) - 8) * 0.035)
        -- One of four things, decided by WHO this is rather than by which seat
        -- frame happens to be drawing them, so a given person at a given spot
        -- always does the same thing however you approach it -- and two people
        -- standing together are not doing it in unison.
        local pose = CROWD_POSES[person % #CROWD_POSES + 1]
        if seat.model.akPose ~= pose then
          seat.model.akPose, seat.model.akAnim = pose, pose
          seat.model:SetAnimation(pose)
        end
        -- Shown regardless of load state, for the same reason the karts are: a
        -- hidden PlayerModel never streams in, so gating on IsReady kept the
        -- crowd permanently invisible.
        setShown(seat, true)
      else
        setShown(seat, false)
      end
    end
  end
  -- A seat the window did not reach this frame. It cannot happen while the
  -- arithmetic above is a bijection, and saying so in code is cheaper than
  -- finding a figure frozen at the roadside if it ever stops being one.
  for _, seat in ipairs(self.spectators) do
    if not used[seat] then setShown(seat, false) end
  end
end

--- Draw the road strip. Returns the camera position so sprites project against
--- exactly the same camera the road used.
--- Everything in the world sits on some route. The camera is on the player's,
--- so a racer who took the other side of a fork is not merely far away -- they
--- are on a different piece of road and must not be drawn on this one at all.
function RaceUI:OnRoute(race, entity)
  local route = self.route or race.track
  return (entity.route or race.track) == route
end

--- The alternate route at a fork.
---
--- A branch is compiled exactly like a track, so it exposes the same centre,
--- height and width tables and can be projected with the same maths. It is
--- drawn peeling off the side of the main road it leaves from, which is the
--- only thing that tells a driver the split is coming while they can still
--- choose it.
--- Lay out a route's roadside scenery.
---
--- Deterministic from the track id, so the world is identical every lap and
--- every session -- scenery that reshuffles is worse than none, because you
--- stop trusting what you are looking at. Built once and cached on the route.
-- The scenery you actually drive PAST, keyed per track.
--
-- Two separate things went wrong here and they hid each other. First, this was
-- keyed on `track.style`, which only Oribos sets -- so every other circuit in
-- the game got the same `default` entry: green conifers beside the lava in
-- Durotar, beside the ice in Ironforge, and in the middle of the Netherstorm's
-- void. Second, these tints were authored to multiply a tree texture that had
-- dark green baked into it. That texture is a pale neutral silhouette now (see
-- Art/generate-art.js), so the same numbers came out as washed-out sage.
--
-- Worth being clear about how this was missed: the skyline treeline was fixed
-- last pass and these are a DIFFERENT table -- the small trees on the horizon
-- versus the big ones rushing past your wheels -- and the gameplay footage
-- showed the second, which I read as the first.
local PROP_KINDS = {
  oribos = {
    { art = "spire.tga", w = 0.30, h = 1.00, tint = { 0.62, 0.55, 0.85 }, min = 5.5, max = 13.0 },
    { art = "shard.tga", w = 0.70, h = 0.70, tint = { 0.45, 0.85, 1.00 }, min = 1.4, max = 3.0 },
  },
  elwynn = {
    { art = "tree.tga",  w = 0.55, h = 1.00, tint = { 0.26, 0.48, 0.28 }, min = 4.5, max = 11.0 },
    { art = "tree.tga",  w = 0.60, h = 0.90, tint = { 0.19, 0.38, 0.22 }, min = 6.0, max = 14.0 },
    { art = "boulder.tga", w = 1.50, h = 1.00, tint = { 0.46, 0.44, 0.38 }, min = 1.2, max = 2.6 },
  },
  -- Scorched stumps and red rock. Sparse and low: it is a wasteland.
  durotar = {
    { art = "tree.tga",  w = 0.60, h = 0.85, tint = { 0.44, 0.24, 0.12 }, min = 3.4, max = 8.0 },
    { art = "boulder.tga", w = 1.50, h = 1.00, tint = { 0.58, 0.29, 0.18 }, min = 1.6, max = 4.2 },
    { art = "boulder.tga", w = 1.50, h = 1.00, tint = { 0.40, 0.21, 0.15 }, min = 2.2, max = 5.5 },
  },
  -- Dense, dark and tall. The jungle closes over the road.
  stranglethorn = {
    { art = "tree.tga",  w = 0.62, h = 1.05, tint = { 0.16, 0.40, 0.21 }, min = 7.0, max = 16.0 },
    { art = "tree.tga",  w = 0.55, h = 1.00, tint = { 0.22, 0.50, 0.26 }, min = 5.0, max = 12.0 },
    { art = "sporecap.tga", w = 1.00, h = 1.00, tint = { 0.66, 0.50, 0.32 }, min = 1.4, max = 3.0 },
  },
  -- Snow-laden firs and ice. Pale, and it reads against the white ground.
  -- Dark evergreens and bare grey rock, so the snow has something to be white
  -- against. Both used to be tinted almost the colour of the snow itself.
  ironforge = {
    { art = "tree.tga",  w = 0.58, h = 1.00, tint = { 0.13, 0.30, 0.28 }, min = 4.0, max = 10.0 },
    { art = "tree.tga",  w = 0.52, h = 1.15, tint = { 0.09, 0.22, 0.24 }, min = 5.0, max = 12.0 },
    { art = "boulder.tga", w = 1.50, h = 1.00, tint = { 0.46, 0.54, 0.62 }, min = 1.8, max = 4.5 },
  },
  -- Underground: no trees at all, just cut rock and timber.
  deadmines = {
    { art = "boulder.tga", w = 1.50, h = 1.00, tint = { 0.32, 0.33, 0.42 }, min = 1.6, max = 4.4 },
    { art = "spire.tga", w = 0.34, h = 1.00, tint = { 0.36, 0.32, 0.28 }, min = 3.0, max = 7.0 },
  },
  -- Void crystal. Nothing grows here.
  netherstorm = {
    { art = "shard.tga", w = 0.75, h = 1.00, tint = { 0.62, 0.36, 0.92 }, min = 2.2, max = 6.5 },
    { art = "spire.tga", w = 0.30, h = 1.00, tint = { 0.44, 0.34, 0.70 }, min = 4.0, max = 10.0 },
  },
  -- Sandstone pillars, and the odd dead thing.
  thousandneedles = {
    { art = "spire.tga", w = 0.36, h = 1.00, tint = { 0.74, 0.52, 0.30 }, min = 6.0, max = 15.0 },
    { art = "boulder.tga", w = 1.50, h = 1.00, tint = { 0.68, 0.50, 0.32 }, min = 1.4, max = 3.4 },
    { art = "tree.tga",  w = 0.58, h = 0.80, tint = { 0.42, 0.32, 0.20 }, min = 2.6, max = 6.0 },
  },
  -- Giant mushrooms, which is the entire point of Zangarmarsh.
  zangarmarsh = {
    { art = "sporecap.tga", w = 1.00, h = 1.00, tint = { 0.38, 0.70, 0.70 }, min = 3.5, max = 9.0 },
    { art = "sporecap.tga", w = 1.00, h = 1.00, tint = { 0.60, 0.48, 0.76 }, min = 2.0, max = 5.0 },
    { art = "tree.tga",  w = 0.55, h = 1.00, tint = { 0.24, 0.46, 0.40 }, min = 4.0, max = 9.0 },
  },
  -- Bone and black spire.
  icecrown = {
    { art = "spire.tga", w = 0.32, h = 1.00, tint = { 0.30, 0.32, 0.40 }, min = 5.0, max = 13.0 },
    { art = "boulder.tga", w = 1.50, h = 1.00, tint = { 0.72, 0.76, 0.82 }, min = 1.6, max = 4.0 },
  },
  -- A dwarven fighting pit: cut columns and broken masonry, and not one tree.
  anvilmar = {
    { art = "spire.tga", w = 0.40, h = 1.00, tint = { 0.58, 0.46, 0.34 }, min = 4.5, max = 11.0 },
    { art = "boulder.tga", w = 1.50, h = 1.00, tint = { 0.50, 0.40, 0.30 }, min = 1.4, max = 3.6 },
  },
  -- A flooded cave: stalagmites, wet rock, and the pale stuff growing on it.
  grotto = {
    { art = "spire.tga", w = 0.38, h = 1.00, tint = { 0.28, 0.40, 0.46 }, min = 3.5, max = 9.0 },
    { art = "boulder.tga", w = 1.50, h = 1.00, tint = { 0.22, 0.32, 0.36 }, min = 1.4, max = 3.4 },
    { art = "sporecap.tga", w = 1.00, h = 1.00, tint = { 0.34, 0.56, 0.62 }, min = 1.8, max = 4.2 },
  },
  -- An open-air pit in the jungle: palms over the wall, and the torch posts the
  -- corner is named for.
  gurubashi = {
    { art = "tree.tga",  w = 0.60, h = 1.05, tint = { 0.20, 0.44, 0.24 }, min = 6.0, max = 14.0 },
    { art = "spire.tga", w = 0.30, h = 0.80, tint = { 0.52, 0.34, 0.20 }, min = 2.6, max = 6.0 },
    { art = "boulder.tga", w = 1.50, h = 1.00, tint = { 0.56, 0.46, 0.30 }, min = 1.3, max = 3.2 },
  },
  default = {
    { art = "tree.tga",  w = 0.55, h = 1.00, tint = { 0.26, 0.48, 0.28 }, min = 4.5, max = 11.0 },
    { art = "tree.tga",  w = 0.60, h = 0.90, tint = { 0.19, 0.38, 0.22 }, min = 6.0, max = 14.0 },
    { art = "boulder.tga", w = 1.50, h = 1.00, tint = { 0.46, 0.44, 0.38 }, min = 1.2, max = 2.6 },
  },
}

--- @param route the road being decorated (main line or a branch)
--- @param style the track's own id, so scenery is per CIRCUIT rather than per
---   "style" -- only Oribos ever set a style, so keying on it gave nine of the
---   ten tracks the same green conifers.
function RaceUI:BuildProps(route, style)
  if route.props then return route.props end
  local kinds = PROP_KINDS[style or "default"] or PROP_KINDS.default
  -- Resolve each art path ONCE. RenderProps used to build it with a concat per
  -- prop per frame, which is 54 short-lived strings every frame for a value
  -- that never changes.
  for _, kind in ipairs(kinds) do kind.artPath = kind.artPath or (ART .. kind.art) end
  -- Seed from the whole id, not its length: half the tracks share a name
  -- length and would otherwise grow byte-identical forests.
  local name = route.id or route.name or "route"
  local seed = math.floor(route.length)
  for i = 1, #name do seed = (seed * 31 + name:byte(i)) % 2147483647 end
  local rng = AK.RNG:New(seed)
  local props = {}

  -- THE SCENERY MUST NOT CHANGE THE FRAME YOU TAKE A FORK.
  --
  -- Every route grows its own forest from its own seed, so committing to a
  -- branch replaced every tree, rock and bush within half a kilometre between
  -- one frame and the next. The ROAD is continuous through the junction now,
  -- and the world beside it was still cutting -- which is what is left of "they
  -- just kinda port you somewhere". A junction is a place, and the trees
  -- standing at it belong to both roads.
  --
  -- So the first and last stretch of a branch borrows the parent's props over
  -- the matching stretch of the main line. They coincide with the road there
  -- (the fork turn has not opened yet), so this is not a trick: they are the
  -- same trees, seen from a road that has not left yet.
  local JUNCTION_BLEND = 130
  local blend = 0
  if route.parent then
    blend = math.min(JUNCTION_BLEND, route.length * 0.35)
    local shared = self:BuildProps(route.parent, style)
    for _, prop in ipairs(shared) do
      -- Into the branch's own distance space, at whichever end it belongs to.
      local intoEntry = (prop.distance - route.entry) % route.parent.length
      if intoEntry < blend then
        local copy = {}
        for k, v in pairs(prop) do copy[k] = v end
        copy.distance = intoEntry
        props[#props + 1] = copy
      end
      local beforeExit = (route.exit - prop.distance) % route.parent.length
      if beforeExit < blend and beforeExit > 0 then
        local copy = {}
        for k, v in pairs(prop) do copy[k] = v end
        copy.distance = route.length - beforeExit
        props[#props + 1] = copy
      end
    end
  end

  local distance = blend
  while distance < route.length - blend do
    for _, side in ipairs({ -1, 1 }) do
      -- Skip some slots outright, so the verge has clearings and thickets
      -- rather than a metronome of identical trunks.
      if rng:Next() > 0.22 then
        local kind = kinds[rng:Range(1, #kinds)]
        props[#props + 1] = {
          distance = (distance + rng:Next() * PROP_SPACING) % route.length,
          side = side,
          -- Just beyond the verge, with a scattering set further back.
          offset = 1.35 + rng:Next() * (rng:Next() < 0.3 and 3.2 or 0.9),
          size = kind.min + rng:Next() * (kind.max - kind.min),
          kind = kind,
          -- Slight per-prop tint variation so a stand of trees is not one
          -- colour stamped repeatedly.
          shade = 0.82 + rng:Next() * 0.36,
        }
      end
    end
    distance = distance + PROP_SPACING
  end
  table.sort(props, function(a, b) return a.distance < b.distance end)
  route.props = props
  return props
end

--- Draw the scenery nearest the camera, sorted so near props occlude far ones.
function RaceUI:RenderProps(race, camX, camZ)
  local tuning = self.T
  local route = self.route or race.track
  -- The track's ID, with `style` as a fallback so Oribos keeps its own entry.
  local props = self:BuildProps(route, race.track.style or race.track.id)
  local light = (self.light or 1) * tuning.nightBoost
  local shown = 0
  local length = route.length

  for _, prop in ipairs(props) do
    if shown >= PROPS then break end
    local dz = AK.Math.SignedLoopDistance(camZ % length, prop.distance, length)
    -- A TREE UNDER A MOUNTAIN IS NOT A TREE.
    --
    -- Props are child frames, so they draw ABOVE the tunnel rock rather than
    -- behind it, and the only thing stopping them was a single gate on the
    -- CAMERA's cover. That let a conifer stand inside the Frozen Tunnel for as
    -- long as the camera had not finished entering -- which in the footage is
    -- most of the tunnel, because the camera trails the kart and the cover
    -- ramps over 14m. Each prop is now tested where IT stands.
    if dz > 0.8 and dz < FAR_Z
      and AK.TrackBuilder:TunnelDepth(route, prop.distance) < 0.5 then
      shown = shown + 1
      local frame = self.props[shown]
      -- camZ + dz, NOT prop.distance.
      --
      -- `Bend` measures from `bendFrom = camZ`, which is an ABSOLUTE distance
      -- that keeps accumulating across laps, while props/objects/hazards store
      -- LAP-RELATIVE distances (0..length). From lap two onward the subtraction
      -- goes hugely negative, clamps to t = 0, and every one of them is handed
      -- bend 0 -- pinned to the road's centreline AT THE CAMERA while the road
      -- curves away from it. They then appear off the track at distance and
      -- only slide into place as you arrive on top of them. `dz` is already the
      -- forward distance from the camera, so camZ + dz is the honest position.
      local propZ = camZ + dz
      local baseX, worldY = self:RoadAt(route, propZ)
      local edge = AK.Math.RoadWidth(route, propZ)
      -- Anchored outside the road edge, so props never encroach on the racing
      -- surface however much the road narrows or widens.
      local lateral = prop.side * (edge + prop.offset) * tuning.roadHalf
      local x, y, pixelsPerMetre = self:Project(dz, baseX + lateral, camX, worldY)
      local height = pixelsPerMetre * prop.size
      if height > 2 and x > -self.halfWidth * 2.2 and x < self.halfWidth * 2.2 then
        local kind = prop.kind
        local width = height * (kind.w / kind.h)
        -- DISTANCE WASHES A TREE OUT; IT DOES NOT PAINT IT BLACK.
        --
        -- Two distance treatments were being applied on top of each other and
        -- they pull opposite ways. `fog` multiplies the colour DOWN, to a floor
        -- of a fifth, while Aerial blends it TOWARD the haze -- and the haze
        -- blend is capped at about half. So a prop at the horizon came out at
        -- roughly 0.15 of its own colour and then only got halfway to the sky:
        -- a black blob hanging on a pale green skyline, which is the one thing
        -- on that horizon the eye goes straight to. Photographed on
        -- Stranglethorn, that is exactly what it was.
        --
        -- Aerial is the correct model and already carries the depth cue, so the
        -- prop's own shade no longer decays with distance. `fog` is kept for
        -- the contact SHADOW, which genuinely should fade away with the ground
        -- it is cast on.
        local fog = AK.Math.Clamp(1 - (dz / HAZE_Z) * tuning.fogStrength, 0.20, 1) * light
        local tint = kind.tint
        local shade = prop.shade * light

        frame:ClearAllPoints()
        frame:SetPoint("BOTTOM", self.frame, "CENTER", x, y)
        frame:SetSize(math.max(1, width), math.max(1, height))
        -- Nearer props draw over farther ones, matching the road strips.
        frame:SetFrameLevel(self.frame:GetFrameLevel() + 1
          + depthBucket(dz) * 2)
        -- Only when it actually changes, for the reason RenderKarts already
        -- states: re-binding the same file every frame costs for nothing. Props
        -- are the worse case of the two -- 54 of them against eight karts -- and
        -- the path was being CONCATENATED here as well, so a fresh string was
        -- allocated per prop per frame purely to hand back a texture the widget
        -- was already showing. `artPath` is resolved once in BuildProps.
        if frame.artApplied ~= kind.artPath then
          frame.artApplied = kind.artPath
          frame.art:SetTexture(kind.artPath)
        end
        frame.art:SetVertexColor(self:Aerial(tint[1], tint[2], tint[3], shade, dz))
        -- A contact shadow is what stops a sprite looking pasted onto the
        -- grass; without one everything hovers.
        --
        -- SIZED OFF THE FOOTPRINT, NOT THE HEIGHT. A shadow's extent is what
        -- the thing COVERS, and this took its ellipse height from the sprite's
        -- own height -- so a squat boulder, which is half again as wide as it
        -- is tall, got a thinner shadow than a sixteen-metre tree standing on a
        -- trunk. Worse, the sprite is drawn over the top half of its own
        -- shadow, so at 0.14 of height there were about three pixels of it left
        -- showing under a boulder: photographed on Ironforge snow, where a
        -- shadow should be unmissable, there was a smudge.
        frame.shadow:ClearAllPoints()
        frame.shadow:SetPoint("CENTER", frame, "BOTTOM", 0, height * 0.02)
        frame.shadow:SetSize(width * 1.20, math.max(1, width * 0.30))
        frame.shadow:SetVertexColor(0, 0, 0, 0.34 * fog)
        -- Props had NO edge fade and were drawn out to 2.2 half-widths off
        -- axis, which is well past the display -- so a tree the corner had
        -- swung aside stayed fully opaque and could be watched travelling in
        -- from nowhere. Objects and hazards already fade; scenery is the most
        -- numerous thing on screen and needed it most.
        frame:SetAlpha(self:EdgeFade(x, dz))
        setShown(frame, true)
      else
        shown = shown - 1
      end
    end
  end
  for i = shown + 1, PROPS do setShown(self.props[i], false) end
end

--- Accumulated lateral offset along `route`, starting `from` metres into it.
---
--- The same forward double integral the main road uses, so a ribbon bends by
--- exactly what the road it stands for bends by. Pulled out of RenderFork
--- because there are two ribbons now: the branch peeling off the main line at
--- the split, and the MAIN LINE peeling back in at the rejoin.
local function bendAlong(route, from)
  -- Read the tuned gain once per ribbon rather than per step, and from the same
  -- accessor the main road uses.
  local gain = bendGain()
  local cache, lateral, offset, built = {}, 0, 0, 0
  return function(bd)
    while built * BEND_STEP <= bd + BEND_STEP do
      cache[built + 1] = offset
      lateral = lateral + AK.Math.RoadCurve(route, from + built * BEND_STEP) * gain * BEND_STEP
      offset = offset + lateral * BEND_STEP
      built = built + 1
    end
    local t = bd / BEND_STEP
    local index = math.floor(t)
    local a, b = cache[index + 1] or 0, cache[index + 2] or 0
    return a + (b - a) * (t - index)
  end
end

--- Draw one alternate line as a ribbon of road, and return how many strips it
--- used.
---
--- TWO RIBBONS, NOT ONE. This was inline in RenderFork and drew exactly one
--- thing: the branch peeling off the main line at the split. The moment you
--- committed, it stopped -- "once committed to a branch there is no fork left
--- to advertise" -- which is true of the split and completely wrong about the
--- REJOIN. The main line you are about to be put back onto was invisible until
--- the frame you arrived on it, so a shortcut ended with the whole world ahead
--- being replaced between one frame and the next. That is the "especially
--- jarring to exit" in the report, and it is the same junction seen from the
--- other side, so it gets the same ribbon.
---
--- @param route the road the ribbon represents
--- @param from where along `route` the ribbon starts
--- @param startDz metres from the camera to that point
--- @param centre the world X the ribbon leaves from -- where the road being
---   driven has already bent to by the junction
--- @param baseY the world height at the junction
--- @param span how much of `route` to draw
--- @param shown how many fork strips are already in use this frame
---
--- NO SIDEWAYS OFFSET ANY MORE. The ribbon used to be shoved a road's width to
--- the side with a fade of its own, and the road you were driving was not --
--- so the instant you committed, everything ahead swung across by that width
--- between one frame and the next. Take the right-hand fork and the world
--- turns left. A branch's departure is authored curvature now
--- (AK.Math.ForkTurn), which this integrates along the route exactly as the
--- main road integrates its own: the ribbon and the road it becomes are the
--- same curve, so crossing between them costs nothing.
function RaceUI:DrawRibbon(race, route, from, startDz, centre, baseY, span,
    shown, camX)
  if span <= 2 then return shown end
  local tuning = self.T
  local track = race.track
  local light = (self.light or 1) * tuning.nightBoost
  local roadColor = track.road or { .34, .34, .38 }
  local bend = bendAlong(route, from)
  local previousX, previousY, previousW
  for i = 0, FORK_SEGMENTS - 1 do
    local bd = span * (i / (FORK_SEGMENTS - 1))
    local dz = startDz + bd
    if dz > 1.2 then
      -- The ribbon starts where the road being driven has bent to by the
      -- junction and accumulates its own curvature -- fork turn included --
      -- from there.
      local worldX = centre + bend(bd)
      -- FADED IN BY HOW FAR APART THE TWO ROADS ACTUALLY ARE.
      --
      -- At the junction itself a branch and the road it leaves are the same
      -- piece of tarmac, so the ribbon drew a second road exactly on top of the
      -- first and painted its bright rails straight across the road the player
      -- is driving on: standing at the split, that filled the bottom half of
      -- the screen with green. Measured against whatever road the camera is on
      -- at the same depth, so it works from either side of the junction.
      local apart = worldX - self:Bend((self.bendFrom or 0) + dz)
      local reveal = AK.Math.Clamp(math.abs(apart) / (tuning.roadHalf * 0.8), 0, 1)
        -- And out at its own draw limit, so the far end of the ribbon dissolves
        -- instead of ending in a hard bright line across the world.
        * AK.Math.Clamp((FORK_DRAW - dz) / FORK_DRAW_FADE, 0, 1)
      -- Height along the ribbon's own route, hung off the junction's height so
      -- the two roads meet at the same level.
      local worldY = AK.Math.RoadHeight(route, from + bd) - AK.Math.RoadHeight(route, from)
        + baseY
      local x, y, pixelsPerMetre = self:Project(dz, worldX, camX, worldY)
      local halfWidthPixels = pixelsPerMetre * tuning.roadHalf * AK.Math.RoadWidth(route, from + bd)

      if previousY and y > previousY and shown < FORK_SEGMENTS then
        shown = shown + 1
        local strip = self.forkStrips[shown]
        local height = math.max(1, y - previousY)
        local midX = (x + previousX) * .5
        local midHalf = (halfWidthPixels + previousW) * .5
        -- Narrowest of the two edges, never the average -- see the same note in
        -- RenderRoad. The ribbon can then only fall short of its own edge, and
        -- the rails drawn along that edge are the one thing covering it.
        local quadLo = math.max(previousX - previousW, x - halfWidthPixels)
        local quadHi = math.min(previousX + previousW, x + halfWidthPixels)
        local quadNarrow = (quadHi - quadLo) >= 2
        if not quadNarrow then
          quadLo, quadHi = midX - midHalf, midX + midHalf
        end
        local quadX, quadHalf = (quadLo + quadHi) * .5, (quadHi - quadLo) * .5
        -- Same rule as the main road: a texture minified past MIN_TEXEL
        -- is a moire pattern, so out there the ribbon is flat colour
        -- with road.tga's own baked mean folded in.
        local flatRibbon = pixelsPerMetre * ROAD_TILE < MIN_TEXEL
        if strip.roadFlat ~= flatRibbon then
          strip.roadFlat = flatRibbon
          if flatRibbon then
            strip.road:SetTexture(SOLID)
            strip.road:SetTexCoord(0, 1, 0, 1)
          else
            strip.road:SetTexture(ART .. "road.tga", "REPEAT", "REPEAT")
          end
        end
        if not flatRibbon then
          local uRoad = tuning.roadHalf / ROAD_TILE
          local vNear = (bd - span / FORK_SEGMENTS) / ROAD_TILE
          local vFar = bd / ROAD_TILE
          local cap = math.max(0.08, height / MIN_TEXEL)
          if vFar - vNear > cap then vFar = vNear + cap end
          strip.road:SetTexCoord(-uRoad, uRoad, vNear, vFar)
        end
        strip.road:ClearAllPoints()
        strip.road:SetPoint("BOTTOM", self.frame, "CENTER", quadX, previousY)
        strip.road:SetSize(math.max(2, quadHalf * 2), height)
        -- A BRANCH CAN BE A RAMP TOO. Four of them are -- Ridge Drop and Rim
        -- Gap are launches you can miss, which is the whole point of taking
        -- them -- and every one was painted the same tarmac as the road it
        -- leaves, so the one shortcut in the game you can fail by being too
        -- slow gave you nothing to aim at. Same hazard bands and same white
        -- lip as the main road, from the same table.
        local rampR, rampG, rampB = roadColor[1], roadColor[2], roadColor[3]
        -- By COVERAGE, like the main road's -- see rampCover. A point test out
        -- where one ribbon strip spans tens of metres decides whether the whole
        -- jump is painted on the roll of a die, and rolls it again next frame.
        local ribMix, ribLip = rampCover(route, from + bd - span / FORK_SEGMENTS,
          from + bd)
        if ribMix > 0.02 then
          local cr, cg, cb
          if math.floor((from + bd) / 2.4) % 2 == 0 then
            cr, cg, cb = 1.00, 0.78, 0.10
          else
            cr, cg, cb = 0.13, 0.10, 0.06
          end
          if ribLip > 0 then
            cr, cg, cb = cr + (1.00 - cr) * ribLip, cg + (0.97 - cg) * ribLip,
              cb + (0.88 - cb) * ribLip
          end
          rampR = rampR + (cr - rampR) * ribMix
          rampG = rampG + (cg - rampG) * ribMix
          rampB = rampB + (cb - rampB) * ribMix
        end
        -- The same wash the main road gets. Fogging the ribbon by
        -- brightness alone while the tarmac beside it recedes toward the
        -- horizon made the shortcut read as a decal laid over the scene.
        local ribR, ribG, ribB = self:Aerial(rampR, rampG, rampB,
          0.94 * light * (flatRibbon and ROAD_MEAN or 1), dz)
        strip.road:SetVertexColor(ribR, ribG, ribB, reveal)
        setShown(strip.road, true)

        -- Bright rails so the alternate line reads as a road and not as
        -- a shadow on the grass.
        --
        -- THE FLOOR IS THE POINT. Scaled off the ribbon's own width alone,
        -- the rails came out at ONE PIXEL between about sixty and a
        -- hundred and fifty metres -- which is the entire window in which
        -- the player has to notice a shortcut and decide to take it. By
        -- the time they were wide enough to see you were already at the
        -- split. Two and a half pixels is still a hairline on the near
        -- ribbon and is the difference between a lit alternate line and a
        -- speckle in the grass at distance.
        local rail = AK.Math.Clamp(midHalf * 0.055, 2.5, 18)
        -- LOUD. Photographed thirty metres from Elwynn's river ford, the
        -- rails came out at RGB (0.21, 0.60, 0.27) -- a mid green on
        -- brown tarmac, which is a marking, not a signal. The alternate
        -- line has to be picked out of a scene it is lying directly on
        -- top of, because a branch leaves from the road's own edge and
        -- overlaps it for the first fifty metres. The pulse now runs
        -- between three quarters and full rather than between a little
        -- over half and full, and the hue is a lime rather than a leaf.
        local glow = 0.75 + 0.25 * math.sin(race.elapsed * 6 - bd * 0.2) * flicker(dz)
        local rr, rg, rb = self:Aerial(0.48 * glow, 1.0 * glow, 0.30 * glow, light, dz)
        -- Unrolled. This was `ipairs({ { strip.edgeLeft, -1 }, ... })`,
        -- which allocated three tables per strip per frame -- a hundred
        -- and twenty pieces of garbage every frame a fork is on screen,
        -- for a two-element loop.
        --
        -- Diagonals, like the main road's kerbs: a branch is at its most
        -- oblique exactly where it leaves the road, so its rails were the
        -- worst staircase on screen -- on the one piece of geometry whose
        -- entire job is to be read at a glance from a long way off.
        -- Diagonals, like the main road's kerbs, and for a sharper
        -- reason: a branch is at its most oblique exactly where it leaves
        -- the road, so its rails were the worst staircase on screen -- on
        -- the one piece of geometry whose whole job is to be read at a
        -- glance from a long way off.
        local nearL, farL = previousX - previousW, x - halfWidthPixels
        local nearR, farR = previousX + previousW, x + halfWidthPixels
        -- Collapsed to the midpoint on a degenerate strip, as the main road's
        -- kerbs are: a diagonal across a strip that turns further than it is
        -- wide is a rule across the frame, not an edge.
        if not quadNarrow then
          nearL, farL, nearR, farR = quadLo, quadLo, quadHi, quadHi
        end
        local travelL = math.abs(farL - nearL)
        local travelR = math.abs(farR - nearR)
        strip.edgeLeft:SetVertexColor(rr, rg, rb, reveal)
        setEdge(strip.edgeLeft, self.frame,
          nearL + (travelL - rail) * 0.5, previousY,
          farL + (travelL - rail) * 0.5, y, rail + travelL)
        setShown(strip.edgeLeft, true)
        strip.edgeRight:SetVertexColor(rr, rg, rb, reveal)
        setEdge(strip.edgeRight, self.frame,
          nearR - (travelR - rail) * 0.5, previousY,
          farR - (travelR - rail) * 0.5, y, rail + travelR)
        setShown(strip.edgeRight, true)
      end
      previousX, previousY, previousW = x, y, halfWidthPixels
    end
  end
  return shown
end

function RaceUI:RenderFork(race, player, camX, camZ)
  local tuning = self.T
  local track = race.track
  local shown = 0
  local signShown = false
  -- THE OTHER ROAD, RECORDED FOR EVERYTHING ELSE IN THE FRAME.
  --
  -- Rebuilt every frame and cleared when there is no junction in sight, so
  -- nothing can be placed against a stale one. RenderKarts reads it: a rival
  -- who took the other side of the fork used to be hidden outright, so the six
  -- seconds you spend on a shortcut were spent alone and you found out whether
  -- it worked by reading a number afterwards. Now you can watch them.
  self.crossRoute = nil

  -- FROM THE BRANCH, LOOKING BACK AT THE MAIN LINE.
  --
  -- This block did not exist. RenderFork ran only while you were on the main
  -- line, on the reasoning that a committed kart has no fork left to advertise
  -- -- which is true of the SPLIT and wrong about the REJOIN. The road you are
  -- about to be put back onto was drawn nowhere at all until the frame the
  -- physics moved you onto it, and then the whole world ahead changed between
  -- two frames: a different centreline, a different width, a different set of
  -- scenery. That is the "especially jarring to exit" in the report.
  --
  -- So the main line gets exactly the ribbon the branch gets, from the other
  -- side of the same junction: it peels IN toward you over the last stretch of
  -- the shortcut, so the rejoin is somewhere you can see yourself arriving.
  local route = player.route or track
  if route ~= track and route.parent == track then
    local branch = route
    local toExit = branch.length - player.distance
    if toExit > -tuning.camBack and toExit < REJOIN_NOTICE then
      -- DRAWN FROM THE CAMERA, NOT FROM THE EXIT. The main line runs alongside
      -- the shortcut for its whole closing stretch -- that is what the branch's
      -- fork turn coming back MEANS -- so starting the ribbon at the junction
      -- drew the merge and hid the approach to it. Beginning at the camera
      -- shows the two roads converging, which is the part worth seeing. The
      -- branch is shorter than the span it replaces, so the main line is walked
      -- at its own rate: the two only have to agree at the junction itself.
      local camBranch = player.distance - tuning.camBack
      local pace = branch.span / math.max(1, branch.length)
      local mainAtCam = branch.exit - (branch.length - camBranch) * pace
      local startCentre = self:Bend(camBranch)
      local span = math.max(0,
        math.min(REJOIN_DRAW + tuning.camBack, FAR_Z, FORK_DRAW))
      shown = self:DrawRibbon(race, track, mainAtCam, tuning.camBack, startCentre,
        AK.Math.RoadHeight(branch, camBranch), span, shown, camX)
      self.crossRoute = { route = track, from = mainAtCam, dzAt = tuning.camBack,
        centre = startCentre, bend = bendAlong(track, mainAtCam),
        baseY = AK.Math.RoadHeight(branch, camBranch) }
    end
  end

  -- Only from the main line: the SPLIT is only ahead of you while you are still
  -- on the road it leaves.
  if (player.route or track) == track then
    local branch, gap = AK.TrackBuilder:ForkAt(track, player.distance, FAR_Z)
    if branch and gap then
      -- Distance from the camera to the split. camBack is added because the
      -- camera trails the kart, so the split is that much further away again.
      local entryDz = gap + tuning.camBack
      -- Where the main road has already bent to by the time it reaches the
      -- split; the ribbon has to leave from exactly there or it detaches.
      local entryCentre = self:Bend(branch.entry)
      local entryWidth = AK.Math.RoadWidth(track, branch.entry)
      -- The branch's own curvature, accumulated along the branch the same way
      -- the main road is accumulated along itself.
      local branchBend = bendAlong(branch, 0)
      -- The ribbon leaves along the branch's own curvature -- fork turn and all,
      -- the same curve the road is drawn with once you are on it, so committing
      -- changes nothing about where the branch appears to be.
      local side = AK.Math.ForkSide(branch)
      local span = math.min(branch.length,
        math.max(0, math.min(FAR_Z, FORK_DRAW) - entryDz))
      local light = (self.light or 1) * tuning.nightBoost
      local roadColor = track.road or { .34, .34, .38 }
      -- The wash comes from RenderRoad, which has already run this frame. It
      -- used to be recomputed here from the track's own sky and glow, which was
      -- the same arithmetic minus one term: the copy left out the `(1 -
      -- camDepth)` that kills the haze under cover, so inside Deadmines the
      -- shortcut ribbon receded toward a SKY that is not there while the tarmac
      -- beside it stayed rock-lit.
      shown = self:DrawRibbon(race, branch, 0, entryDz, entryCentre,
        AK.Math.RoadHeight(track, branch.entry), span, shown, camX)
      self.crossRoute = { route = branch, from = 0, dzAt = entryDz,
        centre = entryCentre, bend = bendAlong(branch, 0),
        baseY = AK.Math.RoadHeight(track, branch.entry) }
      -- The sign, planted on the branch's side of the split.
      --
      -- NOTICED AT A FIXED DISTANCE, not at the draw distance. Both the gate
      -- and the label's fade were measured against FAR_Z, so winding the
      -- See-ahead slider out lit the shortcut sign up half a kilometre early
      -- and pinned its name to the sky above the treeline for most of a lap.
      -- "There is a shortcut coming" is a fact about the road, not about how
      -- far the renderer has been told to draw.
      if entryDz > 2 and entryDz < FORK_NOTICE then
        local signX, signY = self:RoadAt(track, branch.entry)
        local x, y, pixelsPerMetre = self:Project(entryDz,
          signX + side * tuning.roadHalf * entryWidth * 1.05, camX, signY)
        local size = AK.Math.Clamp(pixelsPerMetre * 2.6, 16, 190)
        self.forkSign:ClearAllPoints()
        self.forkSign:SetPoint("BOTTOM", self.frame, "CENTER", x, y)
        self.forkSign:SetSize(size * 0.9, size)
        -- Two files rather than one flipped texture: SetRotation turns the UVs
        -- inside a fixed rectangle, it does not mirror the quad.
        self.forkSign:SetTexture(ART .. (side < 0 and "forkleft.tga" or "forkright.tga"))
        -- LIT WHEN YOU ARE LINED UP FOR IT, dim when you are not.
        --
        -- The sign said a shortcut existed and nothing else, so the one thing
        -- the player needed to know on the approach -- am I on the right side
        -- of the road to take this -- was invisible until it was decided for
        -- them. Same predicate the physics commits on, so the sign cannot say
        -- one thing and the road do another.
        local aimed = AK.Math.ForkAimed(branch, player.lateral)
        local flash = aimed and (0.72 + 0.28 * math.sin(race.elapsed * 7)) or 0.42
        if aimed then
          self.forkSign:SetVertexColor(0.55 * flash, 1.0 * flash, 0.62 * flash, 1)
        else
          self.forkSign:SetVertexColor(0.62 * flash, 0.68 * flash, 0.72 * flash, 1)
        end
        setShown(self.forkSign, true)
        self.forkLabel:ClearAllPoints()
        -- KEPT ON SCREEN. The sign stands beside the road, and on a bend the
        -- road is off at the edge of the display long before the split arrives
        -- -- so the label, anchored to the sign, was being drawn half off the
        -- right of the frame with its own name unreadable. The arrow beside it
        -- still says which way; the words only have to be legible.
        local labelX = AK.Math.Clamp(x, -self.halfWidth + 130, self.halfWidth - 130)
        self.forkLabel:SetPoint("BOTTOM", self.frame, "CENTER", labelX, y + size * 1.05)
        -- The name alone; the direction is the ARROW beside it. This used to
        -- read "RIVER FORD  <<", with the arrow typed out of angle brackets on
        -- the one screen the player is actually looking at.
        self.forkLabel:SetText((branch.name or "SHORTCUT"):upper())
        -- And the words take the same state, so a glance at either one answers
        -- the question. Lime is "you are going that way"; grey is "you are not".
        if aimed then
          self.forkLabel:SetTextColor(unpack(AK.COLORS.lime))
          self.forkArrow:SetVertexColor(unpack(AK.COLORS.lime))
        else
          self.forkLabel:SetTextColor(0.62, 0.68, 0.78)
          self.forkArrow:SetVertexColor(0.62, 0.68, 0.78)
        end
        self.forkArrow:ClearAllPoints()
        self.forkArrow:SetPoint(side < 0 and "RIGHT" or "LEFT", self.forkLabel,
          side < 0 and "LEFT" or "RIGHT", side < 0 and -6 or 6, 0)
        self.forkArrow:SetTexCoord(side < 0 and 1 or 0, side < 0 and 0 or 1, 0, 1)
        self.forkArrow:SetAlpha(self.forkLabel:GetAlpha())
        setShown(self.forkArrow, true)
        self.forkLabel:SetAlpha(AK.Math.Clamp((FORK_NOTICE - entryDz) / 90, 0, 1))
        setShown(self.forkLabel, true)
        signShown = true
      end
    end
  end

  if not signShown then
    setShown(self.forkSign, false)
    setShown(self.forkLabel, false)
    setShown(self.forkArrow, false)
  end
  for i = shown + 1, FORK_SEGMENTS do
    local strip = self.forkStrips[i]
    setShown(strip.road, false)
    setShown(strip.edgeLeft, false)
    setShown(strip.edgeRight, false)
  end
end

function RaceUI:RenderRoad(race, player)
  local tuning = self.T
  -- The road drawn is the road the player is on, branch or main line.
  local track = player.route or race.track
  self.route = track
  local roadHalf = tuning.roadHalf
  -- The feel channels are OFFSETS on the tuned baseline, applied here at read
  -- time and never stored back. `push` pulls the camera away from the kart on a
  -- boost; `dip` drops it on a landing.
  local feel = self.feel or {}
  local alpha = race.alpha
  local camZ = self:Lerped(player.prevDistance, player.distance, alpha, 3)
    - (tuning.camBack + (feel.push or 0))
  -- A BRANCH IS A LINE, NOT A LOOP -- and that is Builder:At's problem now.
  --
  -- The camera used to be clamped to zero on a branch, because every lookup
  -- downstream wrapped a negative distance round to the branch's EXIT. Clamping
  -- the camera froze the entire world for camBack metres at the split while the
  -- kart kept moving, so the kart slid out from under the camera and snapped
  -- back -- the "disorienting and glitchy" fork. The lookups clamp instead, so
  -- the camera can sit where it physically is: just behind the split, looking
  -- at a road that continues.
  -- Draw distance is tunable, and everything downstream -- props, posts, arches,
  -- the fork ribbon, the fog curve -- reads this same upvalue, so setting it
  -- here is what makes the slider apply live.
  FAR_Z = tuning.drawDistance or 560
  -- Rebuild the forward bend for this frame before anything is projected; every
  -- road, prop, post and racer position below reads from it.
  self:BuildBend(track, camZ)
  -- The bend is already measured from the kart, so the only lateral the camera
  -- still owns is how far across the road the player has moved.
  -- The camera follows the kart ACROSS the road, but not instantly.
  --
  -- camX used to be exactly the player's lateral position, which pins the kart
  -- to one column of pixels for the entire race: steer, get thrown wide by a
  -- corner, get shoved by a rival -- the kart never moves, the world moves
  -- under it. That is the OutRun read, and it is most of why being pushed
  -- around by curvePush never felt like being pushed around by anything.
  --
  -- Letting the camera trail lets the kart slide toward the outside of a corner
  -- and settle back on the exit, which is what a chase camera actually does and
  -- what every kart racer since 1992 has done. The clamp is the safety rail:
  -- the camera may lag, but the kart must not walk off toward the edge of the
  -- screen where you cannot see what you are about to hit.
  local targetLateral = self:Lerped(player.prevLateral, player.lateral, alpha, 0.5)
  local followed = self.camLateralValue or targetLateral
  followed = AK.Math.Lerp(followed, targetLateral,
    math.min(1, (race.renderDelta or 0.016) * tuning.camFollow))
  local lagLimit = tuning.camFollowMax
  self.camLateralValue =
    AK.Math.Clamp(followed, targetLateral - lagLimit, targetLateral + lagLimit)
  local camX = self.camLateralValue * roadHalf
  -- THE CAMERA GOES UP WITH YOU.
  --
  -- A jump used to be one thing: the kart sprite translating up the screen by
  -- 2.1 of its own widths. Its own width is enormous in the near field, so at
  -- 1440p that is most of the screen -- filmed on the Deadmines ramp the kart
  -- leaves the top of the frame entirely and the JUMP! banner is left pointing
  -- at empty sky. It does not read as height, it reads as the kart falling out
  -- of the picture.
  --
  -- What a jump looks like is the WORLD dropping away. The camera climbs the
  -- same arc, so the road recedes, the horizon falls, and the kart stays framed
  -- where the player can see what it is doing. The sprite's own hop is cut to
  -- match (see the airRise note in RenderKarts) -- between the two you get the
  -- height without losing the kart.
  local airLift = 0
  local height, phase = jumpArc(race and race.player)
  if height then
    -- Raised to a power above one so the camera is proportionally LOWER than
    -- the kart early in the arc and catches up over the top: a chase camera
    -- lags, and a camera that rises in lockstep cancels the whole effect out.
    airLift = height * JUMP_CAMERA_SHARE
      * (math.sin(phase * math.pi) ^ 0.35)
  end
  -- The camera rides above the road beneath it, so it crests and dips with the
  -- terrain instead of flying level through hills.
  self.camWorldY = AK.Math.RoadHeight(track, camZ) + tuning.camHeight
    - (feel.dip or 0) + airLift
  local roadColor = track.road or { .34, .34, .38 }
  local grassColor = track.color or { .16, .40, .18 }
  local light = (self.light or 1) * tuning.nightBoost
  -- The verge has to be lifted well above the track's base colour or the grass
  -- texture has nothing to show through. The old lift was a per-channel
  -- multiply (2.3/2.1/1.9), which brightens by SATURATING: Elwynn's green came
  -- out at (0.50, 0.97, 0.43) -- a 2:1 channel ratio that reads as poster paint
  -- rather than as turf, and it did the same to every other track's ground.
  -- Lift toward the colour's own luminance instead: same brightness, far less
  -- scream, hue preserved so the tracks still look nothing like each other.
  local grassLum = grassColor[1] * 0.30 + grassColor[2] * 0.59 + grassColor[3] * 0.11
  local vergeColor = {
    (grassColor[1] * 0.58 + grassLum * 0.42) * 2.15 + .05,
    (grassColor[2] * 0.58 + grassLum * 0.42) * 2.15 + .05,
    (grassColor[3] * 0.58 + grassLum * 0.42) * 2.15 + .05,
  }
  -- SetVertexColor clamps each channel at 1.0 INDEPENDENTLY, which does not
  -- dim a colour -- it changes its hue. Ironforge's pale blue snow lifts to
  -- (1.49, 1.69, 1.82), all three clamp to white, and what you actually see is
  -- whatever hue the grass texture has of its own. The track's colour is thrown
  -- away entirely on every bright track. Scaling instead of clamping keeps the
  -- hue and only costs brightness, which the lift had to spare anyway.
  local vergePeak = math.max(vergeColor[1], vergeColor[2], vergeColor[3])
  if vergePeak > 1 then
    for c = 1, 3 do vergeColor[c] = vergeColor[c] / vergePeak end
  end

  -- Derive the nearest sampled distance from the camera rather than fixing it:
  -- any tuned camera height or horizon must still put the first segment below
  -- the bottom edge, or a band of bare ground shows under the road.
  local lift = (self.camDepth or tuning.camDepth) * tuning.camHeight * self.halfHeight
  local nearZ = math.max(1.2, lift / (tuning.horizon + self.halfHeight + 60))
  -- ROAD DETAIL.
  --
  -- The road is drawn as a stack of textured strips, and every one of them
  -- costs seven textures moved, resized and tinted from Lua every frame -- the
  -- single largest block of per-frame work in the addon by a wide margin.
  -- Sampling is uniform in 1/z, so all the strips are roughly the same height
  -- on screen: at 150 they are about five pixels each, which is finer than the
  -- eye can use and more than the frame can always afford.
  --
  -- So the count is a setting. The strips are all BUILT (150 of them) and the
  -- setting decides how many are USED, with the remainder parked off screen --
  -- that way the dial applies while you watch instead of on the next reload.
  local detail = SEGMENT_DETAIL[AK.db.settings.roadDetail] or SEGMENTS
  if self.activeSegments ~= detail then
    for i = detail + 1, SEGMENTS do
      local strip = self.strips[i]
      setShown(strip.grass, false) setShown(strip.road, false) setShown(strip.shade, false)
      setShown(strip.rumbleLeft, false) setShown(strip.rumbleRight, false) setShown(strip.lane, false)
      setShown(strip.wallLeft, false) setShown(strip.wallRight, false) setShown(strip.ceiling, false)
    end
    self.activeSegments = detail
  end
  -- HOW THE ROAD IS SLICED, AND WHY IT IS NOT ALL ONE RULE.
  --
  -- Uniform in 1/z gives every strip the same height on screen. That is the
  -- right answer for the near road and the wrong one for the far road, because
  -- 1/z is a singularity at the horizon: measured, the LAST strip was covering
  -- everything from 262m to 560m -- three hundred metres of road -- as a single
  -- flat quad at a single lateral position. A corner out there was therefore
  -- not drawn as a corner. It was drawn as a straight smear pointing wherever
  -- the midpoint of that quad happened to land, and the three strips before it
  -- were not much better. That is the whole of "distance gets tough": the band
  -- you read an approaching corner in, roughly 100m to 300m out, was being
  -- described by about four quads.
  --
  -- So the budget is split. The near band is spread in 1/z out to DETAIL_Z and
  -- still carries ~98% of the road's height on screen, so the tarmac in front
  -- of you is sliced exactly as smoothly as before. The tail is spread in
  -- METRES from there to the draw distance: those strips are thin -- the last
  -- few are sub-pixel and pile into the dozen rows below the horizon -- but
  -- they are sampled often enough to FOLLOW the bend, so the far road curves
  -- away instead of pointing off in one straight line.
  local tailCount = 0
  if FAR_Z > DETAIL_Z * 1.15 then
    tailCount = math.min(TAIL_SEGMENTS, math.floor(detail * 0.16))
  end
  local nearCount = detail - tailCount
  local detailZ = tailCount > 0 and DETAIL_Z or FAR_Z
  local nearU, farU = 1 / nearZ, 1 / detailZ
  local step = (nearU - farU) / math.max(1, nearCount - 1)
  local tailStep = tailCount > 0 and (FAR_Z - detailZ) / tailCount or 0
  local previousX, previousY, previousW, previousZ
  local previousCeilY, previousPPM
  -- How enclosed the CAMERA is, which drives the whole scene's lighting.
  local camDepth = AK.TrackBuilder:TunnelDepth(track, camZ)
  self.tunnelDepth = camDepth
  -- Under cover the whole scene loses its daylight, which is most of what
  -- sells a tunnel as a place rather than as a differently textured road.
  --
  -- But not the ROAD, not that hard. Deadmines is authored dark (light 0.72) on
  -- a dark palette, and inside its shafts the full 0.48 took the tarmac to RGB
  -- 13 -- measured, on a rendered frame. That is not atmosphere, it is a track
  -- you cannot see, and it is the same fault the palette comment above this
  -- circuit says was already fixed once for the open sections. The walls and
  -- the verge carry the dark; the road stays the lit ribbon running through it,
  -- which is both legible and what a tunnel actually looks like.
  local roadLight = light * (1 - camDepth * 0.20)
  light = light * (1 - camDepth * 0.48)

  -- Aerial perspective on the ground plane.
  --
  -- Distance used to be expressed only as `fog`, a brightness scale -- and then
  -- both ground tints added the brightness straight back: the road's
  -- `+ (1 - fog) * 1.1` term actually made the FAR road BRIGHTER than the road
  -- under your own bumper, and the verge's `+ (1 - fog) * 0.9` left grass at
  -- the horizon 8% darker than grass at your front wheels. So the two surfaces
  -- that fill most of the screen carried no depth cue whatsoever, which is most
  -- of why the world read as painted flats no matter what else was fixed.
  --
  -- What distance actually does is drain contrast and pull hue toward the
  -- colour of the air, so that is what this does: lerp the lit surface toward
  -- the horizon. It is the same wash the treeline and the sky already use, so
  -- ground, verge and skyline now recede together instead of arguing.
  local skyLow = track.skyLow or { .8, .88, .96 }
  local trackGlow = track.glow or { 1, .93, .72 }
  local haze = {
    (skyLow[1] * 0.58 + trackGlow[1] * 0.42) * light,
    (skyLow[2] * 0.58 + trackGlow[2] * 0.42) * light,
    (skyLow[3] * 0.58 + trackGlow[3] * 0.42) * light,
  }
  -- Under cover there is no sky to wash toward; the tunnel fill carries depth
  -- there instead. Capped so the far road never washes out entirely -- you
  -- still have to be able to read where it goes.
  local hazeCap = AK.Math.Clamp(0.62 * tuning.fogStrength, 0, 0.72) * (1 - camDepth)
  -- Published for :Aerial, so every renderer that runs after this one -- props,
  -- posts, arches, the finish gantry, pickups, hazards, shells and karts -- can
  -- recede into the SAME air as the ground they are standing on.
  self.haze, self.hazeCap = haze, hazeCap
  --- Lit surface colour blended toward the horizon. Returns r, g, b, a so it
  --- drops straight into SetVertexColor.
  local function aerial(r, g, b, lit, mix)
    r, g, b = r * lit, g * lit, b * lit
    return r + (haze[1] - r) * mix, g + (haze[2] - g) * mix, b + (haze[3] - b) * mix, 1
  end

  local nearestTunnelBand

  -- NO ClearAllPoints IN THIS LOOP.
  --
  -- Every strip texture below is anchored the same way on every frame -- one
  -- point, always "BOTTOM", always against self.frame's CENTER -- and SetPoint
  -- REPLACES the anchor of the same name. Clearing first was therefore a pure
  -- no-op, and at ten of them per strip across a hundred and fifty strips it
  -- was about nine hundred wasted calls into the client every single frame,
  -- which on a road that is already the most expensive thing on screen is not
  -- nothing. Anything that mixes anchors, or that has ever had SetAllPoints
  -- called on it, still needs the clear -- this shortcut is only safe because
  -- these particular textures never do either.
  for i = 0, detail - 1 do
    local dz
    if i < nearCount then
      dz = 1 / (nearU - i * step)
    else
      dz = detailZ + tailStep * (i - nearCount + 1)
    end
    local segZ = camZ + dz
    local strip = self.strips[i + 1]
    local worldX, worldY = self:RoadAt(track, segZ)
    local x, y, pixelsPerMetre = self:Project(dz, worldX, camX, worldY)
    local halfWidthPixels = pixelsPerMetre * roadHalf * AK.Math.RoadWidth(track, segZ)
    -- Where the roof would be at this sample, projected through the same
    -- camera as the ground so the two converge on the horizon together.
    local coverage = AK.TrackBuilder:TunnelDepth(track, segZ)
    local ceilY
    if coverage > 0 then
      local _
      _, ceilY = self:Project(dz, worldX, camX, worldY + TUNNEL_HEIGHT)
    end

    if previousY and y > previousY then
      local height = math.max(1, y - previousY)
      local midX = (x + previousX) * .5
      local midHalf = (halfWidthPixels + previousW) * .5
      -- THE ROAD QUAD IS DRAWN NARROW ON PURPOSE.
      --
      -- A strip is one axis-aligned rectangle standing in for a trapezoid, and
      -- wherever the rectangle disagrees with the true edge something is drawn
      -- in the wrong place. Drawn at the average of the two edges, as it was,
      -- it disagrees in BOTH directions: it spills tarmac over the verge on one
      -- half of the strip and lets the verge eat into the tarmac on the other.
      -- Two kinds of error need two things to cover them.
      --
      -- Drawn at the NARROWEST of the two edges it can only ever fall short,
      -- never overhang -- so the kerb, which has to be drawn along that edge
      -- anyway, is the one thing that has to cover it, and it covers it by
      -- growing INWARD onto the tarmac exactly as far as the strip turns. A
      -- kerb that fattens on the inside of a corner is what a kerb does; a
      -- staircase of tarmac teeth against green is not.
      local quadLo = math.max(previousX - previousW, x - halfWidthPixels)
      local quadHi = math.min(previousX + previousW, x + halfWidthPixels)
      -- Unless the strip turns further than it is wide, which happens in the
      -- last metre before the horizon. There the average is the only sane
      -- answer -- and the edges have to collapse to the midpoint with it. A
      -- diagonal drawn between the true edges of a strip that sweeps a hundred
      -- pixels sideways in one is not a kerb, it is a red rule ruled across the
      -- frame; measured on Deadmines it reached most of the way over the
      -- tunnel. Beyond this point the strip is a single pixel of road and the
      -- honest drawing of a kerb on it is one pixel at its middle.
      local quadNarrow = (quadHi - quadLo) >= 2
      if not quadNarrow then
        quadLo, quadHi = midX - midHalf, midX + midHalf
      end
      local quadX, quadHalf = (quadLo + quadHi) * .5, (quadHi - quadLo) * .5
      -- Stripes keyed to world position, so they scroll toward the camera
      -- rather than sitting still relative to the player.
      local index = math.floor(segZ / STRIPE_LENGTH)
      local dark = (index % 2 == 0)
      -- How much of the paving/kerb pattern this strip can still resolve. See
      -- stripeFade: below 1 the pattern is finer than the sampling and every
      -- periodic thing on this strip has to ease toward its own average.
      local stripe = stripeFade(STRIPE_LENGTH, segZ - previousZ)
      -- Launch ramps get their own surface. Without this the road just tilted
      -- slightly and you took off with nothing on screen explaining why.
      -- The ramp, and HOW FAR ALONG IT this strip is. The lip -- the last two
      -- metres, where the wheels actually leave -- is the one place on a jump
      -- the player has to be able to see exactly, and it was drawn the same
      -- mustard as the forty metres of run-up before it.
      local rampMix, lipMix = rampCover(track, previousZ, segZ)
      local onRamp = rampMix > 0.02
      -- Distance fog, scaled by the track's ambient light so night circuits go
      -- dark into the distance instead of staying flatly lit.
      local fog = AK.Math.Clamp(1 - (dz / HAZE_Z) * tuning.fogStrength, 0.22, 1) * light
      -- How much air is between the camera and this strip, 0 at the bumper.
      -- Slightly super-linear so the near half of the road stays crisp and the
      -- wash concentrates where the depth cue is actually needed.
      local mix = hazeCap * (AK.Math.Clamp(dz / HAZE_Z, 0, 1) ^ 0.85)

      -- Subtle banding. High contrast turned the field into a striped lawn.
      -- World-locked UVs. Tying the texture to metres rather than to pixels is
      -- what keeps the paving a constant real size: the old pixel-based repeat
      -- crammed ~15 tilings across the near road, so the slabs were a blur.
      -- The strip spans prevSegZ..segZ, so map exactly that range.
      -- A STRIP MAY NOT TILE ITSELF INTO A MOIRE PATTERN.
      --
      -- There is no mipmapping here, so a quad four pixels tall with sixty
      -- repeats of the paving mapped down it does not read as distant paving:
      -- it reads as an interference pattern. It was far worse for the grass,
      -- which is drawn the full width of the screen -- at 300m the verge
      -- texture repeated over two hundred times inside a single strip. That
      -- shimmering scalloped band under the treeline in every screenshot was
      -- that, not terrain.
      --
      -- One repeat of a ground texture is TILE metres across and lands on
      -- `pixelsPerMetre * TILE` pixels of screen, so that product is the whole
      -- test: while it is comfortably above a pixel the texture is a surface,
      -- and below MIN_TEXEL it is noise. Down the strip the same is true of the
      -- V range, which is capped against the strip's own height. Past the
      -- crossover the texture is dropped for flat colour with the file's mean
      -- folded in -- capping the repeat count instead was tried first and only
      -- traded the shimmer for a regular, obviously artificial lattice.
      local vSpanCap = math.max(0.08, height / MIN_TEXEL)

      local flatRoad = pixelsPerMetre * ROAD_TILE < MIN_TEXEL
      if strip.roadFlat ~= flatRoad then
        strip.roadFlat = flatRoad
        -- Only ON THE CHANGE. Re-binding the same file every frame across 150
        -- strips is exactly the waste the no-ClearAllPoints note above is
        -- about, and a strip's distance barely moves between frames.
        if flatRoad then
          strip.road:SetTexture(SOLID)
          strip.road:SetTexCoord(0, 1, 0, 1)
        else
          strip.road:SetTexture(ART .. "road.tga", "REPEAT", "REPEAT")
        end
      end
      if not flatRoad then
        local vNear, vFar = previousZ / ROAD_TILE, segZ / ROAD_TILE
        if vFar - vNear > vSpanCap then vFar = vNear + vSpanCap end
        local uRoad = roadHalf / ROAD_TILE
        strip.road:SetTexCoord(-uRoad, uRoad, vNear, vFar)
      end

      local flatGround = pixelsPerMetre * GRASS_TILE < MIN_TEXEL
      if strip.grassFlat ~= flatGround then
        strip.grassFlat = flatGround
        if flatGround then
          strip.grass:SetTexture(SOLID)
          strip.grass:SetTexCoord(0, 1, 0, 1)
        else
          strip.grass:SetTexture(ART .. "grass.tga", "REPEAT", "REPEAT")
        end
      end
      if not flatGround then
        -- The coord RANGE is -u..u, so the texture repeats 2u times across the
        -- quad; the pitch that MIN_TEXEL is measured against is the product
        -- above, not this number.
        local uGrass = (self.halfWidth / math.max(1, pixelsPerMetre)) / GRASS_TILE
        local vGrassNear, vGrassFar = previousZ / GRASS_TILE, segZ / GRASS_TILE
        if vGrassFar - vGrassNear > vSpanCap then
          vGrassFar = vGrassNear + vSpanCap
        end
        strip.grass:SetTexCoord(-uGrass, uGrass, vGrassNear, vGrassFar)
      end

      strip.grass:SetPoint("BOTTOM", self.frame, "CENTER", 0, previousY)
      strip.grass:SetSize(self.halfWidth * 2, height)
      -- The verge is lifted well above the track's base colour. Tinting the
      -- texture by the raw colour produced a flat slab with no visible detail
      -- at all -- the ground read as void rather than as terrain.
      -- Flat past FLAT_Z, texture-mean folded in so the join does not show. The
      -- light/dark banding goes too: at this range the bands are compressed to
      -- less than a strip each, so all they can do is flicker.
      if flatGround then
        strip.grass:SetVertexColor(aerial(vergeColor[1], vergeColor[2], vergeColor[3],
          GRASS_MEAN * light, mix))
      else
        strip.grass:SetVertexColor(aerial(vergeColor[1], vergeColor[2], vergeColor[3],
          (dark and (1 - (1 - tuning.grassContrast) * stripe) or 1.0) * light, mix))
      end
      setShown(strip.grass, true)

      strip.road:SetPoint("BOTTOM", self.frame, "CENTER", quadX, previousY)
      strip.road:SetSize(math.max(2, quadHalf * 2), height)
      if onRamp then
        -- A LAUNCH RAMP HAS TO READ AS A RAMP FROM A HUNDRED METRES.
        --
        -- This was one gold tint with a brightness that alternated 1.0 / 0.55
        -- every 2.2m. Photographed from the ramp itself, that is a road that
        -- has turned mustard: the two bands land seven values apart once the
        -- aerial wash has been through them, so there is no stripe, and from
        -- the approach -- where a jump most needs to be legible, so you can
        -- decide to be flat out for it -- it is a smudge the colour of sand.
        --
        -- Two COLOURS, not two brightnesses. Hazard gold against near-black is
        -- the one paint scheme that survives being forty metres away, half a
        -- pixel tall and washed toward the horizon, and it is what a launch
        -- ramp is painted in everywhere outside this game.
        -- 2.4m bands, so they alias sooner than the paving does -- and a ramp
        -- is most of what you are looking at on the approach. Same easing.
        local rampStripe = stripeFade(2.4, segZ - previousZ)
        local band = (math.floor(segZ / 2.4) % 2 == 0)
        local cr, cg, cb = towardMean(1.00, 0.78, 0.10, 0.22, 0.16, 0.07, rampStripe)
        if not band then cr, cg, cb = towardMean(0.22, 0.16, 0.07, 1.00, 0.78, 0.10, rampStripe) end
        -- The lip. Two metres of white, so the exact moment you leave the
        -- ground is a line you can aim at rather than something that happens --
        -- and mixed in by how much of the strip it really covers, or it is the
        -- same coin flip the ramp itself was, on the highest-contrast thing in
        -- the frame.
        if lipMix > 0 then
          cr = cr + (1.00 - cr) * lipMix
          cg = cg + (0.97 - cg) * lipMix
          cb = cb + (0.88 - cb) * lipMix
        end
        -- And the ramp paint itself is mixed over the tarmac by coverage, so a
        -- strip that is half on the jump is half gold rather than all or
        -- nothing. Near the kart rampMix is 1 and this costs nothing.
        if rampMix < 1 then
          cr = roadColor[1] + (cr - roadColor[1]) * rampMix
          cg = roadColor[2] + (cg - roadColor[2]) * rampMix
          cb = roadColor[3] + (cb - roadColor[3]) * rampMix
        end
        strip.road:SetVertexColor(aerial(cr, cg, cb,
          roadLight * (flatRoad and ROAD_MEAN or 1), mix))
      else
        -- A SURFACE PAINTED ON THE ROAD HAS TO BE VISIBLE.
        --
        -- Terrain:Painted has always been read by the physics and never by the
        -- renderer, so Ironforge's ice -- 47% of that lap, on which steering
        -- authority drops to a QUARTER -- looked exactly like dry tarmac. Half
        -- a circuit of invisible hazard, and the same for Elwynn's mud strip
        -- and every water crossing in the game. You cannot drive round what you
        -- cannot see coming.
        local r, g, b = roadColor[1], roadColor[2], roadColor[3]
        local paint, paintStrength = AK.Terrain:Painted(track, segZ, 0)
        if paint and paint.tint then
          -- Ramped at the ends of the zone, exactly as the physics ramps the
          -- grip, so the surface arrives instead of being switched on.
          local reach = 0.72 * (paintStrength or 1)
          -- Most of the way to the material's own colour: enough to read as a
          -- different surface from a long way off, not so much that the track's
          -- identity disappears under it.
          r = r + (paint.tint[1] - r) * reach
          g = g + (paint.tint[2] - g) * reach
          b = b + (paint.tint[3] - b) * reach
        end
        -- A LEGIBILITY FLOOR. A dark palette, a night circuit and a tunnel all
        -- multiply, and three modest decisions can compound into a road at RGB
        -- 13. Whatever the lighting says, the tarmac keeps enough value to be
        -- seen -- lifted as a whole so the colour's hue survives the rescue.
        local litR, litG, litB = r * roadLight, g * roadLight, b * roadLight
        local peak = math.max(litR, litG, litB)
        if peak > 0.001 and peak < 0.17 then
          local rescue = 0.17 / peak
          litR, litG, litB = litR * rescue, litG * rescue, litB * rescue
        end
        -- A strip that has dropped its texture carries the file's mean instead,
        -- so the surface does not brighten as it crosses over.
        strip.road:SetVertexColor(aerial(litR, litG, litB,
          (dark and (1 - 0.04 * stripe) or 1.0) * (flatRoad and ROAD_MEAN or 1), mix))
      end
      setShown(strip.road, true)

      strip.shade:SetPoint("BOTTOM", self.frame, "CENTER", quadX, previousY)
      strip.shade:SetSize(math.max(2, quadHalf * 2), height)
      -- The verge darkening is a property of the surface, so it washes out
      -- with the surface rather than staying crisp on a hazed-out far road.
      strip.shade:SetAlpha(0.85 * (1 - mix))
      setShown(strip.shade, true)

      -- Rumble width is capped: proportional-only made the near strips into
      -- enormous red slabs across the bottom of the screen.
      local rumbleWidth = AK.Math.Clamp(midHalf * (self.style == "oribos" and 0.055 or 0.05), 1, 20)
      -- THE KERB IS THE WORST OF THE ALIASING, because it is the highest
      -- contrast pattern in the frame: saturated red against near-white, on a
      -- line one strip wide. Out where a strip spans several stripes it was
      -- picking one of the two at random every frame -- two flickering rails
      -- either side of the far road. Eased to the pink they average to, which
      -- is what a red-and-white kerb looks like from two hundred metres.
      local rr, rg, rb = towardMean(.82, .22, .18, .95, .95, .96, stripe)
      if dark then rr, rg, rb = towardMean(.95, .95, .96, .82, .22, .18, stripe) end
      if self.style == "oribos" then
        -- Anima light pulsing along the verge, travelling with the stripes.
        -- The pulse has a 22m period, so it aliases on the same terms; its
        -- DEPTH fades rather than its colour, leaving a steady light.
        local depth = 0.45 * stripeFade(22, segZ - previousZ) * flicker(dz)
        local pulse = (1 - depth) + depth * math.sin(segZ * 0.28 - race.elapsed * 5)
        rr, rg, rb = towardMean(0.30, 0.82, 1.00, 1.00, 0.72, 0.28, stripe)
        if dark then rr, rg, rb = towardMean(1.00, 0.72, 0.28, 0.30, 0.82, 1.00, stripe) end
        rr, rg, rb = rr * pulse, rg * pulse, rb * pulse
      end
      if onRamp then
        -- Bright rails either side of the launch, so it reads from far off.
        -- Mixed in by coverage like the paint: a rail that switched on and off
        -- with a point test was a pair of hazard-gold dashes blinking in the
        -- far field, which is the most eye-catching kind of wrong.
        --
        -- AND THEY DO NOT FLASH ANY MORE. They pulsed at nearly two hertz,
        -- which up close is a strobe on the two brightest lines in the frame --
        -- "jumps are like shiny glitchy on the sides". A ramp already announces
        -- itself: the surface is hazard gold against near-black and the bands
        -- stream past you as you approach. The rails only have to be bright.
        local flash = 0.92
        rr = rr + (1.0 * flash - rr) * rampMix
        rg = rg + (0.85 * flash - rg) * rampMix
        rb = rb + (0.25 * flash - rb) * rampMix
      end
      -- Kerbs are part of the road surface, and in a tunnel they are the most
      -- important thing on screen: they are what tells you where the edge is.
      -- They take the road's lighting, not the rock's.
      rr, rg, rb = aerial(rr, rg, rb, roadLight, mix)
      -- A KERB THAT IS THE EDGE, not a rectangle standing next to it.
      --
      -- Each piece runs from the strip's NEAR edge to its FAR edge. Strip N's
      -- far edge is strip N+1's near edge, so the chain never breaks however
      -- hard the road is turning -- the old midpoint rectangles came apart into
      -- dashes on a bend, because at distance the kerb bottoms out at a pixel
      -- and consecutive strips shift sideways by more than that.
      --
      -- Its OUTER lip is the true road edge and stays exactly `rumbleWidth`
      -- across, so from the verge side the boundary is a clean diagonal at the
      -- right place. Its INNER lip is pushed onto the tarmac by the strip's
      -- lateral travel, which is precisely how far the narrow road quad above
      -- can fall short of that edge. See the quad note: one error, one thing
      -- covering it.
      -- Sub-pixel kerbs fade rather than flicker -- see thinLine. The alpha is
      -- applied to both sides, since they are the same width by construction.
      local kerbShown, kerbAlpha = thinLine(rumbleWidth)
      rumbleWidth = kerbShown
      local nearLeft, farLeft = previousX - previousW, x - halfWidthPixels
      local nearRight, farRight = previousX + previousW, x + halfWidthPixels
      if not quadNarrow then
        nearLeft, farLeft = quadLo, quadLo
        nearRight, farRight = quadHi, quadHi
      end
      local travelLeft = math.abs(farLeft - nearLeft)
      strip.rumbleLeft:SetVertexColor(rr, rg, rb, kerbAlpha)
      setEdge(strip.rumbleLeft, self.frame,
        nearLeft + (travelLeft - rumbleWidth) * 0.5, previousY,
        farLeft + (travelLeft - rumbleWidth) * 0.5, y,
        rumbleWidth + travelLeft)
      setShown(strip.rumbleLeft, true)
      local travelRight = math.abs(farRight - nearRight)
      strip.rumbleRight:SetVertexColor(rr, rg, rb, kerbAlpha)
      setEdge(strip.rumbleRight, self.frame,
        nearRight - (travelRight - rumbleWidth) * 0.5, previousY,
        farRight - (travelRight - rumbleWidth) * 0.5, y,
        rumbleWidth + travelRight)
      setShown(strip.rumbleRight, true)

      -- THE DASHES MERGE INTO A LINE rather than flickering on and off. Their
      -- period is four stripes -- eighteen metres -- so past the resolve limit
      -- whether a strip lands on a dash or a gap is a coin toss per frame. Far
      -- enough away a dashed line IS a faint continuous one, at its own duty
      -- cycle, which is both what it looks like and the only stable thing to
      -- draw.
      local laneFade = stripeFade(STRIPE_LENGTH * 4, segZ - previousZ)
      local laneAlpha = 0.75 * ((index % 4 < 2) and laneFade or 0)
        + 0.75 * 0.5 * (1 - laneFade)
      if laneAlpha > 0.03 and midHalf > 6 then
        -- Also a diagonal. It is thinner than the kerb, so on a bend it came
        -- apart into a dotted line even sooner.
        local laneWidth, laneThin = thinLine(AK.Math.Clamp(midHalf * 0.04, 0.2, 14))
        local lr, lg, lb = aerial(.96, .95, .82, roadLight, mix)
        strip.lane:SetVertexColor(lr, lg, lb, laneAlpha * laneThin)
        local laneNear, laneFar = previousX, x
        if not quadNarrow then laneNear, laneFar = midX, midX end
        setEdge(strip.lane, self.frame, laneNear, previousY, laneFar, y, laneWidth)
        setShown(strip.lane, true)
      else
        setShown(strip.lane, false)
      end

      -- Covered section: rock overhead and to both sides.
      --
      -- The walls reach outward a fixed multiple of the road's own half-width
      -- rather than to the edge of the screen. Spanning the screen would mean a
      -- tunnel 120m away painting rock over grass 20m away; scaling with the
      -- road keeps it a compact portal that grows correctly as you approach.
      if coverage > 0 and ceilY and previousCeilY then
        local ceilTop = math.max(previousCeilY, ceilY + 1)
        local wallOut = midHalf * 1.4
        local wallHeight = math.max(1, ceilTop - previousY)
        -- LIT FROM THE ROAD, NOT FROM THE SKY.
        --
        -- This was `fog * (0.46 + ...)`, and `fog` already carries the scene
        -- light AFTER the full cover dimming -- so the wall was reduced three
        -- times over (track light, cover, its own rock factor) and then a
        -- fourth by the rock texture's own mean. Measured through the real
        -- renderer on Deadmines under 0.89 cover, the BRIGHTEST wall piece on
        -- screen came out at 0.192, and RenderSurround was filling the frame
        -- behind them at 0.163. Fifteen percent apart is not a wall in front of
        -- a void, it is one dark box -- which is exactly the report.
        --
        -- A tunnel is lit by what is in it, and what is in it is the road. So
        -- the rock takes the ROAD's light, a little under it at the mouth and
        -- well under it deep inside, and the fill beyond stays dark so the
        -- walls have something to be brighter than.
        -- Under the road's own value, not over it. Neutral grey rock at the
        -- same luminance as a saturated brown floor reads BRIGHTER than it, so
        -- matching the numbers put the walls in front of the road instead of
        -- around it.
        local tint = self.rockTint or { 1, 1, 1 }
        local rock = wallLight(self.roadColour or { .5, .5, .5 }, roadLight, tint, coverage)
        -- A WALL'S TEXTURE RUNS UP IT, NOT ALONG THE TRACK.
        --
        -- V was previousZ..segZ over TUNNEL_TILE -- the strip's own slice of
        -- track distance. On a near strip that is half a metre out of a
        -- five-metre repeat, so a wall four hundred pixels tall was drawn from
        -- a tenth of one texture row: every slab came out as a single smear of
        -- vertical streaks, and the tunnel read as a beige curtain rather than
        -- as rock. Photographed on the Deadmines run it is the most obviously
        -- wrong surface in the game.
        --
        -- A wall is a vertical face. Its V axis is HEIGHT -- one repeat every
        -- TUNNEL_TILE metres up the rock, so the grain is the size it should be
        -- and every slab shows a whole texture rather than one row of it. The
        -- U axis carries the travel instead: the span is fixed so the number of
        -- repeats across a slab cannot change, and the offset slides with
        -- distance so the rock still streams past you.
        local vNear, vFar = 0, TUNNEL_HEIGHT / TUNNEL_TILE
        local uSlide = segZ / TUNNEL_TILE

        -- Standing on the NARROW quad's edge, not the average -- see the note
        -- there. A wall pinned to the average has the same staircase the road
        -- would have had, and it is the one boundary the kerb cannot hide,
        -- because the wall is drawn outboard of it. Started from the narrow
        -- edge instead, the wall's own step is tucked under the kerb and what
        -- you see is the kerb's clean diagonal.
        strip.wallLeft:SetTexCoord(uSlide, uSlide + 1.6, vNear, vFar)
        strip.wallLeft:SetPoint("BOTTOM", self.frame, "CENTER",
          quadLo - wallOut * 0.5, previousY)
        strip.wallLeft:SetSize(wallOut, wallHeight)
        strip.wallLeft:SetVertexColor(rock * tint[1], rock * tint[2], rock * tint[3], 1)
        setShown(strip.wallLeft, true)

        strip.wallRight:SetTexCoord(uSlide + 1.6, uSlide, vNear, vFar)
        strip.wallRight:SetPoint("BOTTOM", self.frame, "CENTER",
          quadHi + wallOut * 0.5, previousY)
        strip.wallRight:SetSize(wallOut, wallHeight)
        strip.wallRight:SetVertexColor(rock * tint[1], rock * tint[2], rock * tint[3], 1)
        setShown(strip.wallRight, true)

        -- The ceiling ribbon spans this band's ceiling up to the nearer one,
        -- exactly as the road spans this band's ground down to the nearer one.
        -- The ceiling IS a floor seen from below, so its V does carry the
        -- travel -- that is the one surface the old mapping was right for.
        local uCeil = tuning.roadHalf / TUNNEL_TILE
        local ceilHigh = math.max(1, ceilTop - ceilY)
        local cv0 = previousZ / TUNNEL_TILE
        local cv1 = math.min(segZ / TUNNEL_TILE, cv0 + math.max(0.08, ceilHigh / MIN_TEXEL))
        strip.ceiling:SetTexCoord(-uCeil, uCeil, cv0, cv1)
        strip.ceiling:SetPoint("BOTTOM", self.frame, "CENTER", quadX, ceilY)
        strip.ceiling:SetSize(math.max(2, (quadHalf + wallOut) * 2), math.max(1, ceilTop - ceilY))
        -- Overhead is darker than the walls: nothing is lighting it.
        strip.ceiling:SetVertexColor(rock * tint[1] * 0.62, rock * tint[2] * 0.60,
          rock * tint[3] * 0.58, 1)
        setShown(strip.ceiling, true)

        if not nearestTunnelBand then
          nearestTunnelBand = { midX = midX, midHalf = midHalf, ceil = ceilTop,
            ground = previousY, rock = rock, vNear = vNear }
        end
      elseif onRamp then
        -- Ramps are the other place the physics puts a wall, so they get one
        -- you can see: solid side rails along the launch. A barrier the player
        -- cannot see reads as a bug no matter how well it is tuned, so the two
        -- must agree -- Physics:VergeHasWall walls exactly tunnels and ramps.
        -- Sized in METRES and projected, never as a fraction of the road's
        -- on-screen half-width: midHalf is enormous in the near field, so a
        -- fraction of it drew a rail three storeys tall across half the screen.
        -- SPANNING, like the kerbs above, and for the same reason. Each rail
        -- was one rect at the strip's own edge -- so where the road widens or
        -- the hill pitches, and it does both on every ramp in the game,
        -- consecutive rails stepped sideways by more than they were wide and
        -- the barrier came apart into a picket fence with grass showing
        -- between the posts. Each piece now reaches from its strip's near edge
        -- to its far edge, and stands as tall as the taller of the two, so the
        -- rail is one continuous wall however hard the ground is moving.
        local railHeight = math.max(2, pixelsPerMetre * 1.15)
        local railOut = math.max(1, pixelsPerMetre * 0.40)
        local nearHeight = math.max(2, (previousPPM or pixelsPerMetre) * 1.15)
        local nearOut = math.max(1, (previousPPM or pixelsPerMetre) * 0.40)
        local thick = math.max(railOut, nearOut)
        local railTop = math.max(previousY + nearHeight, y + railHeight)
        -- Steady, for the same reason the kerbs above are. See that note.
        local flash = 0.90
        local rr2, rg2, rb2 = 0.95 * flash * fog, 0.80 * flash * fog, 0.26 * flash * fog
        -- Indexed rather than `pairs({ [-1] = ..., [1] = ... })`: that built a
        -- fresh table for every strip of every frame -- a hundred and fifty
        -- pieces of garbage per frame inside a tunnel, for a two-element loop --
        -- and iterated it in an order Lua does not define, so which rail drew
        -- first was luck.
        for i = 1, 2 do
          local side = i == 1 and -1 or 1
          local texture = i == 1 and strip.wallLeft or strip.wallRight
          local nearEdge = previousX + side * previousW
          local farEdge = x + side * halfWidthPixels
          local lo, hi
          if side < 0 then
            lo, hi = math.min(nearEdge, farEdge) - thick, math.max(nearEdge, farEdge)
          else
            lo, hi = math.min(nearEdge, farEdge), math.max(nearEdge, farEdge) + thick
          end
          texture:SetTexCoord(0, 1, 0, 1)
          texture:SetPoint("BOTTOM", self.frame, "CENTER", (lo + hi) * 0.5, previousY)
          texture:SetSize(math.max(1, hi - lo), math.max(2, railTop - previousY))
          -- Faded by how much of this strip is really on the ramp, so the
          -- first and last rail of a jump arrive and leave instead of popping.
          -- Out in the far field one strip can be longer than the whole ramp,
          -- and a rail switched by a point test blinks.
          texture:SetVertexColor(rr2, rg2, rb2, rampMix)
          setShown(texture, true)
        end
        setShown(strip.ceiling, false)
      else
        setShown(strip.wallLeft, false); setShown(strip.wallRight, false); setShown(strip.ceiling, false)
      end
    else
      setShown(strip.grass, false); setShown(strip.road, false); setShown(strip.lane, false); setShown(strip.shade, false)
      setShown(strip.rumbleLeft, false); setShown(strip.rumbleRight, false)
      setShown(strip.wallLeft, false); setShown(strip.wallRight, false); setShown(strip.ceiling, false)
    end
    previousX, previousY, previousW, previousZ = x, y, halfWidthPixels, segZ
    previousCeilY, previousPPM = ceilY, pixelsPerMetre
  end

  self:RenderSurround(camDepth, nearestTunnelBand)
  -- Published so something outside the renderer can ask where the camera
  -- actually ended up. The gap between this and the player's own distance is
  -- what a fork transition has to hold steady, and there was no way to measure
  -- it from anywhere.
  self.camZ = camZ
  -- And how far behind the kart it was TRYING to sit. The chase distance is not
  -- a constant -- a boost pushes the camera back -- so "did the camera end up
  -- where it meant to" cannot be answered against camBack alone.
  self.camGap = tuning.camBack + (feel.push or 0)
  return camX, camZ
end

--- Fill the screen with rock once the camera is actually under cover.
---
--- The per-band walls draw the tunnel as a portal, which is what you want while
--- you are still approaching it. Once inside, everything the portal does not
--- cover -- outboard of the walls, above the ceiling -- is also rock, and
--- without this you would see sky through it.
function RaceUI:RenderSurround(depth, band)
  local surround = self.surround
  if not band or depth <= 0 then
    setShown(surround.left, false); setShown(surround.right, false); setShown(surround.top, false)
    if self.hazeBelow then self.hazeBelow:SetAlpha(1) self.hazeAbove:SetAlpha(1) end
    return
  end
  local w, h = self.halfWidth, self.halfHeight
  -- The dark beyond, deliberately well under the per-band walls in front of
  -- it. At 0.86 of the same value the fill and the walls were within fifteen
  -- percent of each other and the tunnel had no visible geometry at all.
  local rock = band.rock * 0.42

  -- ONE full-screen fill, with no edge arithmetic at all.
  --
  -- This used to compute side panels reaching inward to the outer edge of the
  -- tunnel walls, at `midX +/- midHalf * 2.4`. Inside a tunnel `nearestTunnelBand`
  -- is a NEAR band, and a near band's on-screen half-width is several times the
  -- width of the display -- so both edges clamped to the screen and both side
  -- fills collapsed to ZERO WIDTH. Only the ceiling ever drew: rock hanging
  -- overhead with open sky, trees and grass still showing to either side, which
  -- is exactly the "walls are getting closer and very transparent" report.
  --
  -- Filling the whole frame instead is simpler and cannot degenerate. The road
  -- is ARTWORK and the karts are higher still, so they draw over this on their
  -- own; the per-band walls sit just above it and keep the converging portal.
  local tileP = math.max(64, h * 0.85)
  surround.left:ClearAllPoints()
  surround.left:SetPoint("BOTTOMLEFT", self.frame, "CENTER", -w, -h)
  surround.left:SetPoint("TOPRIGHT", self.frame, "CENTER", w, h)
  surround.left:SetTexCoord(0, (w * 2) / tileP, 0, (h * 2) / tileP)
  -- Faded in over the mouth so entering is a transition, not a switch.
  local tint = self.rockTint or { 1, 1, 1 }
  surround.left:SetVertexColor(rock * tint[1], rock * tint[2], rock * tint[3], depth)
  setShown(surround.left, true)
  setShown(surround.right, false)
  setShown(surround.top, false)

  -- The horizon haze lives on BORDER, which is a whole layer above BACKGROUND,
  -- so it paints straight over the rock. Under cover there is no horizon to
  -- soften, and leaving it up put a bright band across the middle of a tunnel.
  -- SetVertexColor already carries the haze's own .30 alpha and SetAlpha
  -- multiplies it, so this is a plain 1..0 scale, not a second alpha value.
  -- The haze lives on BORDER, a whole layer above the rock, so it paints over
  -- the tunnel no matter what the fill does. Under cover there is no horizon to
  -- soften and it has to leave entirely, faster than the rock arrives.
  if self.hazeBelow then
    local clear = AK.Math.Clamp(1 - depth * 1.6, 0, 1)
    self.hazeBelow:SetAlpha(clear)
    self.hazeAbove:SetAlpha(clear)
  end
end

function RaceUI:RenderObjects(race, player, camX, camZ)
  local tuning = self.T
  local pulse = 0.5 + 0.5 * math.sin(race.elapsed * 5)
  local route = self.route or race.track

  -- Work out what is visible, then give every object a frame it KEEPS.
  --
  -- Pool slots used to be handed out by position in a per-frame list, so which
  -- frame an object landed in changed whenever anything else entered or left
  -- view. One frame would be a hovering item box on one tick and a flat dash
  -- pad on the next, and the panels appeared to jump about and swap places.
  -- Sorting the list first did NOT fix it: objects leave at the NEAR end, so
  -- every index behind them shifts regardless of which way it is ordered.
  --
  -- The fix is identity. An object claims a slot when it comes into view and
  -- holds that same slot until it leaves, so its frame never changes underneath
  -- it. The sort now only decides WHO gets drawn when more objects are in view
  -- than there are frames -- nearest wins, since those are the readable ones.
  self.visibleObjects = self.visibleObjects or {}
  self.slotOwner = self.slotOwner or {}
  self.slotOf = self.slotOf or {}
  self.slotLive = self.slotLive or {}
  self.slotDrawn = self.slotDrawn or {}
  local visible, slotOwner, slotOf = self.visibleObjects, self.slotOwner, self.slotOf
  local live, drawn = self.slotLive, self.slotDrawn
  local capacity = #self.objectFrames

  -- Trackside objects get a SHORTER draw distance than the road, and fade in
  -- over the end of it.
  --
  -- The bend model integrates curvature twice, so the road's screen offset grows
  -- quadratically with how far ahead you look. Measured (verify-render.js), the
  -- road is already past the screen edge by 80m on every track in this game and
  -- reaches 2.1-2.9 half-screens at the full 330m draw distance. Objects were
  -- drawn that whole way, so a far pickup sat as a chip near the screen edge
  -- with no road under it and then swung inward as you closed -- which is the
  -- "things slide in from off screen" read. The size floor in :ObjectSize and
  -- the 0.22 alpha floor in :FogAt are what kept those chips visible instead of
  -- letting them disappear into the haze.
  -- Measured (verify-render.js): the road is fully on screen 96-100% of a lap at
  -- 60m, 76-97% at 100m, but only 61-89% at 140m and 52-74% at 191m. Objects
  -- drawn out to 191m therefore spent much of a lap appearing where the road
  -- had already swung off the display, so they entered at the screen edge and
  -- travelled inward -- "sliding in from the distance instead of just being on
  -- the track". Pulling the draw distance back to where the road is reliably on
  -- screen is what makes a pickup appear ON the road and simply grow.
  -- That threshold is in METRES (see `reach`), not a fraction of the draw
  -- distance: how far ahead the road stays on screen is a property of the bend
  -- model, and winding the See-ahead slider out must not start flinging
  -- pickups back off the edges again.
  local objectFar = reach(88)
  -- ANYTHING BEHIND THE KART IS BEHIND THE KART.
  --
  -- `dz` is measured from the CAMERA, which trails the kart by camBack -- so a
  -- cutoff of 1.5m kept drawing things four and a half metres behind the driver,
  -- at the size clamp and flung to the edge of the screen by the projection. In
  -- the footage that is a dash panel filling the bottom-left corner of the
  -- display, over the control buttons, while the kart is somewhere else. Objects
  -- now leave as they pass under the kart, which is where they went.
  local objectNear = tuning.camBack * 0.70

  local count = 0
  for _, object in ipairs(race.objects) do
    local dz = AK.Math.SignedLoopDistance(camZ % route.length, object.distance, route.length)
    if dz > objectNear and dz < objectFar and not object.hidden and self:OnRoute(race, object) then
      count = count + 1
      local entry = visible[count]
      if not entry then entry = {} visible[count] = entry end
      entry.object, entry.dz = object, dz
    end
  end
  -- Entries are reused rather than rebuilt; spares are parked at math.huge so
  -- one sort over the whole array leaves them harmlessly at the end.
  for i = count + 1, #visible do visible[i].object, visible[i].dz = nil, math.huge end
  table.sort(visible, function(a, b) return a.dz < b.dz end)
  local showCount = math.min(count, capacity)

  -- Release the slots of anything that has left view, THEN fill the gaps. Doing
  -- it in that order is what lets a departing object hand its frame straight to
  -- an arriving one without disturbing everybody in between.
  wipe(live)
  for i = 1, showCount do
    local object = visible[i].object
    local slot = slotOf[object]
    if slot and slotOwner[slot] == object then live[slot] = true end
  end
  for slot = 1, capacity do
    local owner = slotOwner[slot]
    if owner and not live[slot] then slotOf[owner], slotOwner[slot] = nil, nil end
  end
  local free = 1
  for i = 1, showCount do
    local object = visible[i].object
    if not slotOf[object] then
      while free <= capacity and slotOwner[free] do free = free + 1 end
      if free > capacity then break end
      slotOwner[free], slotOf[object] = object, free
    end
  end

  wipe(drawn)
  for index = 1, showCount do
    local object, dz = visible[index].object, visible[index].dz
    local slot = object and slotOf[object]
    if slot then
      drawn[slot] = true
      local frame = self.objectFrames[slot]
      local style = OBJECT_STYLE[object.kind] or OBJECT_STYLE.hazard
      -- A Fake Item Box must be indistinguishable from a real one. Its entire
      -- function is that players are trained to drive into anything box-shaped;
      -- tinting it or labelling it would defeat the item completely.
      if object.fake then style = OBJECT_STYLE.box end
      -- camZ + dz, not object.distance -- see the note in RenderProps. Object
      -- distances are lap-relative and `Bend` measures from an absolute camZ.
      local baseX, worldY = self:RoadAt(self.route or race.track, camZ + dz)
      local x, y, pixelsPerMetre = self:Project(dz, baseX + object.lateral * tuning.roadHalf, camX, worldY)
      -- Floor the size well above zero: a pickup you cannot see is a pickup you
      -- cannot dodge, and the whole point is reading them early.
      local size = self:ObjectSize(pixelsPerMetre, style.size)
      local color = style.color
      local fog = self:FogAt(dz)
      local flat = style.flat

      -- Fade in from the far end, and fade out towards the screen edge, so
      -- anything the corner has swung off-axis is gone before it can be seen
      -- travelling. Applied to the frame so every layer -- pad, ring, icon,
      -- shadow, label -- fades together on exactly the same curve.
      frame:SetAlpha(self:DepthFade(dz, objectFar) * self:EdgeFade(x, dz))
      -- Cubes hover and bob; pads are painted on the tarmac and never leave it.
      -- Low. A box that floats half its own height off the tarmac reads as a
      -- sticker hanging in the air; MK64's barely leave the ground and the bob
      -- is small. The SHADOW does the work of selling the gap, not the height.
      local hover = style.float
        and (size * 0.20 + math.sin(race.elapsed * 2.4 + object.distance) * size * 0.06) or 0

      frame:ClearAllPoints()
      frame:SetPoint("BOTTOM", self.frame, "CENTER", x, y + hover)
      frame:SetSize(size, size)
      frame:SetFrameLevel(self:DepthLevel("object", dz))

      -- Contact shadow, pinned to the ROAD rather than to the frame above it.
      -- It shrinks and fades as the box rises, which is what reads as height --
      -- a shadow that bobs along with the object just looks like part of it.
      local lift = size > 0 and hover / size or 0
      frame.shadow:ClearAllPoints()
      frame.shadow:SetPoint("CENTER", self.frame, "CENTER", x, y + size * 0.05)
      frame.shadow:SetSize(size * (flat and 1.30 or 1.02) * (1 - lift * 0.30),
        math.max(2, size * (flat and 0.36 or 0.34) * (1 - lift * 0.30)))
      frame.shadow:SetAlpha((flat and 0.34 or 0.62) * fog * (1 - lift * 0.45))

      -- Rotation is POOLED STATE and must be written on every path.
      --
      -- Only the item-box branch below ever touched it, so the first time a
      -- frame that had been a spinning box was handed to a dash pad, the pad
      -- inherited the box's rotation -- a wide flat quad drawn with a spin on
      -- it, tumbling as the box's angle kept advancing. THAT is what "the dash
      -- pads flip about and move around strangely" actually was. Reordering the
      -- draw list never had a chance of fixing it; churn only decided how often
      -- a frame changed hands and so how often the bug fired.
      if frame.icon.SetRotation then
        frame.icon:SetRotation(style.spin
          and ((race.elapsed * 0.9 + object.distance * 0.05) % (math.pi * 2)) or 0)
      end

      if flat then
        -- A dash panel is PAINTED ON the road. Drawn as a wide, short quad at
        -- ground level, so it lies in the surface instead of standing up out of
        -- it like a signpost -- an upright square was most of why these read as
        -- icons on a shelf.
        -- Height floors must be SCREEN-RELATIVE, like every other size here.
        --
        -- Laying the panel flat multiplies its size by ~0.3, and the floor left
        -- behind was an absolute 3px. Rendered and compared against OLDOBJ, a
        -- distant dash panel collapsed to a 3px sliver where the upright icon it
        -- replaced was a readable 22px plate -- so flattening them, which fixed
        -- the "icons on a shelf" read, quietly cost most of their visibility.
        -- That is the "dash panels used to be good and have got worse" report,
        -- and it is a floor bug, not a case against flat panels.
        local minH = self.halfWidth * 0.009
        frame.pad:SetSize(size * 1.50, math.max(minH, size * 0.34))
        frame.pad:SetVertexColor(color[1], color[2], color[3], 1)
        frame.pad:SetAlpha((.34 + pulse * .30) * fog)
        setShown(frame.beam, false)
        frame.icon:SetSize(size * 1.42, math.max(minH, size * 0.32))
        if frame.iconApplied ~= style.icon then
          frame.iconApplied = style.icon
          frame.icon:SetTexture(style.icon)
        end
        frame.icon:SetVertexColor(self:Aerial(color[1], color[2], color[3], fog, dz))
        -- Fixed width, pulsing only in brightness. A flat plate that also
        -- breathes in and out reads as sliding around on the road.
        frame.ring:SetSize(size * 1.46, math.max(2, size * 0.06))
        frame.ring:SetAlpha((.30 + pulse * .35) * fog)
      else
        frame.pad:SetSize(size * 1.2, math.max(3, size * 0.26))
        frame.pad:SetVertexColor(color[1], color[2], color[3], 1)
        frame.pad:SetAlpha((.30 + pulse * .28) * fog)
        -- Narrow, faint shaft. The old wide one read as a solid blue box.
        setShown(frame.beam, true)
        frame.beam:SetSize(math.max(2, size * 0.10), size * 1.25)
        frame.beam:SetVertexColor(color[1], color[2], color[3], 1)
        frame.beam:SetAlpha((.10 + pulse * .12) * fog)
        frame.icon:SetSize(size, size)
        if frame.iconApplied ~= style.icon then
          frame.iconApplied = style.icon
          frame.icon:SetTexture(style.icon)
        end
        frame.icon:SetVertexColor(self:Aerial(1, 1, 1, fog, dz))
        frame.ring:SetSize(size * (1.05 + pulse * .10), math.max(2, size * 0.05))
        frame.ring:SetAlpha((.45 + pulse * .45) * fog)
      end
      frame.ring:SetVertexColor(color[1], color[2], color[3], 1)
      frame.label:SetText(size > self.halfWidth * 0.04 and style.label or "")
      frame.label:SetTextColor(color[1], color[2], color[3])
      setShown(frame, true)
    end
  end
  for slot = 1, capacity do
    if not drawn[slot] then setShown(self.objectFrames[slot], false) end
  end
end

--- Course hazards: the track's own antagonists, drawn like any other object.
function RaceUI:RenderHazards(race, camX, camZ)
  local tuning = self.T
  local pulse = 0.5 + 0.5 * math.sin(race.elapsed * 4)
  -- Same identity rule as RenderObjects, and it matters even more here: every
  -- hazard frame carries a creature MODEL, so a hazard that gets handed a
  -- different pool slot re-specs that model and pops through a reload. One
  -- hazard dropping out of view used to shift every hazard behind it by a slot.
  self.hazardSlotOwner = self.hazardSlotOwner or {}
  self.hazardSlotOf = self.hazardSlotOf or {}
  self.hazardLive = self.hazardLive or {}
  self.hazardDrawn = self.hazardDrawn or {}
  self.visibleHazards = self.visibleHazards or {}
  local hOwner, hOf = self.hazardSlotOwner, self.hazardSlotOf
  local hLive, hDrawn, hVisible = self.hazardLive, self.hazardDrawn, self.visibleHazards
  local hazardCap = #self.hazardFrames
  local routeLength = (self.route or race.track).length
  -- Same shortened draw distance as the trackside objects, for the same reason:
  -- past it the road has bent off-screen and a hazard out there is a creature
  -- model floating at the display edge. See RenderObjects for the measurements.
  local hazardFar = reach(92)
  local hFadeFrom = hazardFar * 0.70

  local hCount = 0
  for _, hazard in ipairs(race.hazards or {}) do
    local dz = AK.Math.SignedLoopDistance(camZ % routeLength,
      hazard.distance % routeLength, routeLength)
    -- Same as the pickups: past the kart is past the kart, not a wall of art
    -- across the corner of the screen.
    if dz > tuning.camBack * 0.70 and dz < hazardFar then
      hCount = hCount + 1
      local entry = hVisible[hCount]
      if not entry then entry = {} hVisible[hCount] = entry end
      entry.hazard, entry.dz = hazard, dz
    end
  end
  for i = hCount + 1, #hVisible do hVisible[i].hazard, hVisible[i].dz = nil, math.huge end
  table.sort(hVisible, function(a, b) return a.dz < b.dz end)
  local hShow = math.min(hCount, hazardCap)

  wipe(hLive)
  for i = 1, hShow do
    local slot = hOf[hVisible[i].hazard]
    if slot and hOwner[slot] == hVisible[i].hazard then hLive[slot] = true end
  end
  for slot = 1, hazardCap do
    local owner = hOwner[slot]
    if owner and not hLive[slot] then hOf[owner], hOwner[slot] = nil, nil end
  end
  local hFree = 1
  for i = 1, hShow do
    local hazard = hVisible[i].hazard
    if not hOf[hazard] then
      while hFree <= hazardCap and hOwner[hFree] do hFree = hFree + 1 end
      if hFree > hazardCap then break end
      hOwner[hFree], hOf[hazard] = hazard, hFree
    end
  end

  wipe(hDrawn)
  for index = 1, hShow do
    local hazard, dz = hVisible[index].hazard, hVisible[index].dz
    local slot = hazard and hOf[hazard]
    if slot then
      hDrawn[slot] = true
      local frame = self.hazardFrames[slot]
      -- camZ + dz, not hazard.distance -- see the note in RenderProps.
      local baseX, worldY = self:RoadAt(self.route or race.track, camZ + dz)
      local x, y, ppm = self:Project(dz, baseX + hazard.lateral * tuning.roadHalf, camX, worldY)
      local size = self:ObjectSize(ppm, 2.6)
      local fog = self:FogAt(dz)
      local appear = 1
      if dz > hFadeFrom then
        appear = AK.Math.Clamp((hazardFar - dz) / (hazardFar - hFadeFrom), 0, 1)
      end
      frame:SetAlpha(appear * self:EdgeFade(x, dz))
      frame:ClearAllPoints()
      frame:SetPoint("BOTTOM", self.frame, "CENTER", x, y)
      frame:SetSize(size, size)
      frame:SetFrameLevel(self:DepthLevel("hazard", dz))
      -- Contact shadow so the creature stands on the road instead of hovering
      -- in front of it. Anchored to the race frame at ground height.
      frame.shadow:ClearAllPoints()
      frame.shadow:SetPoint("CENTER", self.frame, "CENTER", x, y + size * 0.05)
      frame.shadow:SetSize(size * 0.92, math.max(2, size * 0.30))
      frame.shadow:SetAlpha(0.58 * fog)
      frame.glow:SetSize(size * 1.7, size * 1.7)
      frame.glow:SetAlpha((0.18 + pulse * 0.20) * fog)
      frame.label:SetText(size > self.halfWidth * 0.042 and hazard.name:upper() or "")

      -- Same rule as the karts: show the frame so it can stream in, and let the
      -- icon cover the gap until it has.
      local ready = false
      if hazard.model and not self.suppressModels then
        AK.Model:SetSpec(frame.model, hazard.model)
        frame.model:SetSize(size * 2.4, size * 2.4)
        frame.model:SetPoint("CENTER", frame, "BOTTOM", 0, size * 0.42)
        -- Creature hazards face the oncoming field, and the moving ones lean
        -- into their sweep so a patrol reads as walking rather than sliding.
        frame.model:SetFacing(math.pi + (hazard.lateral or 0) * 0.6)
        AK.Model:Reframe(frame.model)
        frame.model:Show()
        ready = AK.Model:IsReady(frame.model)
      else
        frame.model:Hide()
      end
      -- Not every hazard has a creature to be, and the ones that do not were
      -- drawing a raw ability icon -- square, bordered, unmistakably a piece of
      -- inventory UI sitting on the track. Trimming the border off and tinting
      -- it with the hazard's own colour at least makes it read as an object in
      -- the world rather than a spellbook button someone dropped.
      frame.icon:SetShown(not ready)
      -- THIS GAME'S OWN ART FIRST. `art` names a file in Art/, drawn for this
      -- world; `icon` is the WoW ability icon that was the only option before,
      -- and is still the fallback for a hazard that has neither a creature nor
      -- a sprite of its own.
      local hazardIcon = hazard.art and (ART .. hazard.art)
        or hazard.icon or "Interface\\Icons\\Spell_Fire_SelfDestruct"
      if frame.iconApplied ~= hazardIcon then
        frame.iconApplied = hazardIcon
        frame.icon:SetTexture(hazardIcon)
        -- ONLY AN ICON HAS A BORDER TO TRIM. Cropping eight per cent off every
        -- edge is what makes a WoW icon stop looking like a button; doing it to
        -- a sprite drawn for this game just cuts the edges off the boulder.
        if hazard.art then
          frame.icon:SetTexCoord(0, 1, 0, 1)
        else
          frame.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        end
      end
      -- A sprite of the thing carries its own colour; an icon borrowed from the
      -- spellbook needs the hazard's tint to belong to the scene at all.
      if hazard.art then
        frame.icon:SetVertexColor(1, 1, 1)
      else
        local tint = hazard.color or { 1, 1, 1 }
        frame.icon:SetVertexColor(tint[1], tint[2], tint[3])
      end
      frame.icon:SetSize(size, size)
      setShown(frame, true)
    end
  end
  for slot = 1, hazardCap do
    if not hDrawn[slot] then setShown(self.hazardFrames[slot], false) end
  end
end

--- Your previous best, replayed. Deliberately ghostly: translucent, no name
--- tag, no shadow, and it takes no part in the race whatsoever.
function RaceUI:RenderGhost(race, camX, camZ)
  local state = race.ghostState
  if not state or not self.ghostKart then
    if self.ghostKart then self.ghostKart:Hide() end
    return
  end
  local tuning = self.T
  local dz = AK.Math.SignedLoopDistance(camZ % (self.route or race.track).length,
    state.distance % (self.route or race.track).length, (self.route or race.track).length)
  if dz <= 0.9 or dz >= FAR_Z then self.ghostKart:Hide() return end

  -- camZ + dz: the ghost's recorded distance is lap-relative, so it hits the
  -- same clamp as the props did. See the note in RenderProps.
  local baseX, worldY = self:RoadAt(self.route or race.track, camZ + dz)
  local x, y, ppm = self:Project(dz, baseX + state.lateral * tuning.roadHalf, camX, worldY)
  local width = AK.Math.Clamp(ppm * 2.2 * tuning.kartScale, 14, self.halfWidth * 0.72)
  self.ghostKart:ClearAllPoints()
  self.ghostKart:SetPoint("BOTTOM", self.frame, "CENTER", x, y)
  self.ghostKart:SetSize(width, width)
  self.ghostKart:SetFrameLevel(self.frame:GetFrameLevel() + 140)
  -- The ghost is your own previous run, so it wears the kart you are driving.
  local ghostArt = kartTexture(state.kartId or AK.db.selection.kart)
  if self.ghostArtApplied ~= ghostArt then
    self.ghostArtApplied = ghostArt
    self.ghostBody:SetTexture(ghostArt)
  end
  self.ghostBody:SetSize(width * 1.05, width * 1.05 * 0.625)
  self.ghostBody:SetVertexColor(0.55, 0.85, 1.0)
  -- Ghostly by design, and faded again by how far off-axis a corner has thrown
  -- it -- otherwise the one kart you are racing against in a Time Trial is the
  -- one thing still sliding in from the screen edge.
  self.ghostKart:SetAlpha(0.38 * self:EdgeFade(x, dz))
  self.ghostKart:Show()
end

--- Shells, bananas and bombs, projected onto the road like anything else.
function RaceUI:RenderProjectiles(race, camX, camZ)
  local tuning = self.T
  local shown = 0
  for _, projectile in ipairs(race.projectiles) do
    if shown >= #self.projectileFrames then break end
    -- A shell at full chat covers most of a metre per slice; without the same
    -- interpolation the camera and the karts get, it strobes past you.
    local drawZ = self:Lerped(projectile.prevDistance, projectile.distance, race.alpha, 3)
    local drawLateral = self:Lerped(projectile.prevLateral, projectile.lateral, race.alpha, 0.5)
    local dz = AK.Math.SignedLoopDistance(camZ % (self.route or race.track).length,
      drawZ % (self.route or race.track).length, (self.route or race.track).length)
    if dz > 1 and dz < FAR_Z then
      shown = shown + 1
      local shot = self.projectileFrames[shown]
      local item = projectile.item
      local baseX, worldY = self:RoadAt(self.route or race.track, drawZ)
      local x, y, pixelsPerMetre = self:Project(dz, baseX + drawLateral * tuning.roadHalf, camX, worldY)
      local size = self:ObjectSize(pixelsPerMetre, 1.5)
      local fog = self:FogAt(dz)
      -- Thrown items hop and spin along; a dropped banana sits still.
      local moving = projectile.speed > 0
      local bob = moving and math.abs(math.sin(projectile.age * 11)) * size * 0.22 or 0
      projectile.screenX, projectile.screenY = x, y + bob

      shot:ClearAllPoints()
      shot:SetPoint("BOTTOM", self.frame, "CENTER", x, y + bob)
      shot:SetSize(size, size)
      -- Same stride as the karts so a shell still sorts against the field by
      -- depth; the constant 40 below a kart at equal depth is preserved.
      -- Same bucketing and stride as the karts, 10 below a kart at equal depth
      -- as before, so shells still sort against the field. A kart's three
      -- levels cover all residues mod 3, so a shot CAN tie with one of them at
      -- certain relative depths; the only consequence is undefined order
      -- between a shell and a bumper, which is not worth another band.
      shot:SetFrameLevel(self:DepthLevel("shot", dz))
      if shot.iconApplied ~= item.icon then
        shot.iconApplied = item.icon
        shot.icon:SetTexture(item.icon)
      end
      -- Item icons are WoW ability art with a baked border. Trimmed so a shell
      -- on the road stops reading as a spellbook button someone dropped.
      shot.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
      local tint = item.tint or { 1, 1, 1 }
      shot.icon:SetVertexColor(self:Aerial(tint[1], tint[2], tint[3], fog, dz))
      shot.glow:SetSize(size * 1.9, size * 1.9)
      shot.glow:SetVertexColor(item.color[1], item.color[2], item.color[3], 1)
      shot.glow:SetAlpha((moving and (0.35 + 0.25 * math.sin(projectile.age * 14)) or 0.18) * fog)
      -- Ground shadow: anchored to the RACE frame, not to this bobbing one, so
      -- a hopping shell throws a shadow that stays on the tarmac. Previously it
      -- was a child of the frame and rose with the item, which is exactly the
      -- "floating" read -- the item and its shadow moved as one sticker.
      local lift = size > 0 and bob / size or 0
      shot.shadow:ClearAllPoints()
      shot.shadow:SetPoint("CENTER", self.frame, "CENTER", x, y + size * 0.05)
      shot.shadow:SetSize(size * 0.9 * (1 - lift * 0.35), math.max(2, size * 0.30 * (1 - lift * 0.35)))
      shot.shadow:SetAlpha(0.5 * fog * (1 - lift * 0.5))
      -- On the frame, so the icon, its glow and the shadow all go together. The
      -- shadow is ANCHORED to the race frame but PARENTED to this one, so it
      -- inherits this; multiplying the fade into it as well would square it.
      shot:SetAlpha(self:EdgeFade(x, dz))
      setShown(shot, true)

      -- Sparks trailing a live shot so it reads as fast, not floating.
      if moving and math.random() < 0.55 then
        self:Emit(x, y + bob + size * 0.3, size * 0.22, item.color, 0.28,
          (math.random() - .5) * 60, -40 - math.random() * 60, -260)
      end
    end
  end
  for i = shown + 1, #self.projectileFrames do setShown(self.projectileFrames[i], false) end
end

--- Called by the simulation when a projectile connects.
function RaceUI:ProjectileHit(projectile, hitThePlayer)
  local color = projectile.item.color
  local x, y, width = self.playerX or 0, self.playerY or 0, self.playerWidth or 60
  -- Explosion at the point of contact.
  self:PlayEffect("burst", x, y + width * 0.4, width * 2.4, color)
  self:PlayEffect("shock", x, y + width * 0.3, width * 2.0, color)
  if hitThePlayer then
    self:Flash(color, .20)
    self:Shake(20)
  end
  for i = 1, 22 do
    local angle = math.random() * math.pi * 2
    self:Emit(x, y + width * 0.35, width * 0.20, color, 0.4 + math.random() * 0.3,
      math.cos(angle) * 340, math.sin(angle) * 300 + 140, -520)
  end
  -- Three layers a few milliseconds apart: the only way to build weight out of
  -- a fixed library of one-shot UI blips.
  if AK.PlayStinger then AK:PlayStinger("collision", 3, 0.045) end
end

--- Two items destroying each other out on the track.
function RaceUI:ProjectileClash(first, second)
  -- Projectiles record where they were last drawn, so the blast lands on the
  -- items rather than guessing at a screen position.
  local x = first.screenX or second.screenX or 0
  local y = first.screenY or second.screenY or (self.playerY or 0)
  local color = first.item.color
  self:PlayEffect("burst", x, y + 40, 120, color)
  self:PlayEffect("shock", x, y + 30, 100, second.item.color)
  for i = 1, 12 do
    local angle = math.random() * math.pi * 2
    self:Emit(x, y + 40, 14, color, 0.32,
      math.cos(angle) * 220, math.sin(angle) * 200 + 80, -460)
  end
  if AK.PlaySfx then AK:PlaySfx("collision") end
end

--- Item box breaking open: shards flying off plus a quick pop.
function RaceUI:BoxShatter()
  local x, y, width = self.playerX or 0, self.playerY or 0, self.playerWidth or 60
  self:PlayEffect("pop", x, y + width * 0.6, width * 1.4, { 1, .86, .35 })
  for i = 1, 14 do
    local angle = math.random() * math.pi * 2
    self:Emit(x, y + width * 0.6, width * 0.16, { 1, .88, .45 }, 0.35 + math.random() * 0.25,
      math.cos(angle) * 300, math.sin(angle) * 260 + 130, -540)
  end
end

--- Where something on the OTHER side of a junction sits, in this frame's space.
---
--- Returns depth, world X and world height, or nil when the thing is not on the
--- road RenderFork drew this frame. The maths is the ribbon's: start at the
--- junction, walk that route's own curvature -- fork turn included -- and add
--- the racer's position across it.
---
--- The two roads through a junction are different lengths, so `dz` here is
--- metres along the OTHER road rather than a shared coordinate. Over the two
--- hundred metres a junction is on screen for that is the right answer anyway:
--- what you want to see is whether the kart that took the other line is level
--- with you, and it is level with you when it has covered the same ground.
function RaceUI:CrossRoute(entity)
  local cross = self.crossRoute
  if not cross or (entity.route or nil) ~= cross.route then return nil end
  local along = (entity.distance or 0) - cross.from
  -- A kart commits to a branch a few metres SHORT of the split, so its distance
  -- along that branch is genuinely negative for a moment. Blinking it out of
  -- the world for those metres is the flicker this whole pass is about; the
  -- curvature walk simply starts at zero instead.
  if along < -12 then return nil end
  return cross.dzAt + along,
    cross.centre + cross.bend(math.max(0, along)),
    AK.Math.RoadHeight(cross.route, entity.distance)
      - AK.Math.RoadHeight(cross.route, cross.from) + cross.baseY
end

--- Put one pool entry entirely out of the world.
---
--- THE TAG, THE PLATE AND THE MARKER ARE NOT THE KART'S CHILDREN.
---
--- They live on `tagLayer` so they always draw over the field -- which is the
--- whole reason that layer exists -- and the price of that is that hiding a
--- kart frame does NOT hide them. Every path that takes a racer off the screen
--- has to take all four with it, and there is more than one such path, so this
--- is the only place that knows the list. It was written out by hand in one of
--- them and the battle marker had already been left off it.
local function hideKart(self, kart, index)
  setShown(kart, false)
  setShown(kart.tag, false)
  setShown(kart.tagPlate, false)
  kart.warn:SetText("")
  kart.warn:SetAlpha(0)
  self.previous[index] = nil
end

function RaceUI:RenderKarts(race, player, camX, camZ)
  local tuning = self.T
  for index, vehicle in ipairs(race.vehicles) do
    local kart = self.karts[index]
    -- Interpolated exactly as the camera is, or every other kart judders
    -- against a world that does not.
    local drawZ = self:Lerped(vehicle.prevDistance, vehicle.distance, race.alpha, 3)
    local drawLateral = self:Lerped(vehicle.prevLateral, vehicle.lateral, race.alpha, 0.5)
    local dz = AK.Math.SignedLoopDistance(camZ % (self.route or race.track).length, drawZ % (self.route or race.track).length, (self.route or race.track).length)
    -- A KART BEING RECOVERED IS NOT IN THE WORLD.
    --
    -- Nothing in the renderer read `falling`, so a kart that had gone off the
    -- course kept being drawn on the road it left -- and then, at the instant
    -- the simulation put it back at its recovery point, jumped bodily
    -- backwards up the track. On a rival right beside you that reads as the
    -- game breaking. It is gone while it is out of play, and comes back where
    -- it comes back.
    -- ON THE OTHER SIDE OF A FORK IS STILL IN THE WORLD.
    --
    -- A rival who took the other line was hidden outright, which is most of why
    -- a shortcut felt like nothing had happened: you drove it alone and found
    -- out whether it had worked by reading the position number afterwards. When
    -- RenderFork has a junction on screen, they are drawn on the road they are
    -- actually on -- alongside, closing or pulling away -- and that is the
    -- whole point of there being two roads.
    local baseX, worldY
    if self:OnRoute(race, vehicle) then
      baseX, worldY = self:RoadAt(self.route or race.track, drawZ)
    else
      dz, baseX, worldY = self:CrossRoute(vehicle)
    end
    if not vehicle.falling and dz
      and dz > 0.9 and dz < FAR_Z and not vehicle.finished and baseX then
      local x, y, pixelsPerMetre = self:Project(dz, baseX + drawLateral * tuning.roadHalf, camX, worldY)
      -- A kart is about 2.2m wide; scale the sprite by the same projection as
      -- the road so near racers loom and distant ones shrink correctly.
      -- Lightning leaves you tiny; flattening squashes you further still.
      local sizeScale = 1
      if (vehicle.shrunk or 0) > 0 then sizeScale = 0.46 end
      if (vehicle.flattened or 0) > 0 then sizeScale = sizeScale * 0.60 end
      -- Screen-relative cap, not an absolute pixel cap -- 460px was a third of
      -- a 1280 preview and a sixth of a 1440p client.
      --
      -- There is deliberately no minimum size. A floor was tried and it was a
      -- mistake: the kart's projected size is 2.2m of road seen from camBack
      -- metres, so it is already correct by construction -- roughly a quarter
      -- of the road's width, at any resolution. Forcing a screen-relative
      -- minimum on top of that fought the perspective, and when the camera sat
      -- far back it inflated a kart that was still drawn up near the horizon.
      -- If the kart looks wrong, the camera is wrong; fix it there.
      local width = AK.Math.Clamp(pixelsPerMetre * 2.2 * tuning.kartScale * sizeScale, 10, self.halfWidth * 0.72)
      local height = width

      -- Suspension. A kart travelling over paving should never sit perfectly
      -- still: bounce scales with speed and doubles over rough ground.
      local travel = vehicle.speed / math.max(1, vehicle.maxSpeed)
      local bumpRate = 13 + travel * 16
      local bump = math.sin(vehicle.distance * 0.9 + (vehicle.seed or 0)) * travel
      -- HOW ROUGH THE GROUND IS, from the ground. Every material in
      -- Data/Terrain.lua carries a `rumble` -- scree 0.95, snow 0.45, ice 0.10
      -- -- and nothing read it: leaving the road shook the kart by a flat 1.6
      -- whether it had gone onto a glacier or into a rockfall. This is the only
      -- channel a client with no controller has for saying what is under the
      -- wheels, and it was spending it on a constant.
      if vehicle.offroad then
        local rough = (vehicle.material and vehicle.material.rumble) or 0.55
        bump = bump + math.sin(race.elapsed * bumpRate) * (0.6 + rough * 1.6)
      end
      local bounce = bump * width * 0.022
      -- Airtime from a blast: a clean arc up and back down.
      local hop = vehicle.hop or 0
      if hop > 0 then
        local t = 1 - hop / math.max(0.01, vehicle.hopMax or 1)
        bounce = bounce + math.sin(t * math.pi) * width * 1.15
      end
      -- Standalone hop from tapping the drift key without steering.
      local plainHop = vehicle.hopAir or 0
      if plainHop > 0 then
        local t = 1 - plainHop / math.max(0.01, vehicle.hopAirMax or 1)
        bounce = bounce + math.sin(t * math.pi) * width * 0.42
      end
      -- Drift hop: short, snappy, at the moment the drift engages.
      local dhop = vehicle.driftHop or 0
      if dhop > 0 then
        local t = 1 - dhop / math.max(0.01, vehicle.driftHopMax or 1)
        bounce = bounce + math.sin(t * math.pi) * width * 0.30
      end
      -- Ramp airtime: a long, high arc, well above the blast hop.
      -- +1 leaving the lip, 0 at the top, -1 coming down. Used again below to
      -- stretch the kart on the way up and gather it on the way down.
      local airRise = 0
      local airHeight, airPhase = jumpArc(vehicle)
      if airHeight then
        -- METRES, projected. pixelsPerMetre is exactly how this frame turns a
        -- height at this depth into a screen offset, so the arc is correct
        -- however far away the kart is -- and the shadow, which stays pinned at
        -- the road's own y, opens up underneath it by the same amount.
        bounce = bounce + pixelsPerMetre * airHeight
        airRise = math.cos(airPhase * math.pi)
      end

      -- The world yaws around the player, so take most of the yaw back off
      -- their own kart. Leaving a little in lets it drift toward the outside of
      -- the corner, which is what a chase camera actually does.
      local drawX = x
      if vehicle == player then drawX = x - (self.yawShift or 0) * 0.85 end

      kart:ClearAllPoints()
      kart:SetPoint("BOTTOM", self.frame, "CENTER", drawX, y + bounce)
      kart:SetSize(width, height)
      -- Nearer karts must draw over further ones -- and each kart needs THREE
      -- exclusive levels, because it is three stacked frames: chassis behind,
      -- driver, chassis-front.
      --
      -- The stride used to be 1. Two karts a metre apart therefore overlapped:
      -- the further kart's driver sat on the same level as the nearer kart's
      -- body, and its front chassis on the same level as the nearer driver. So
      -- riders rendered through neighbouring karts, which is why it happened
      -- across the whole field rather than on one racer. A stride of 4 leaves
      -- each kart a level of headroom and cannot interleave.
      -- Depth is bucketed to 2m so a stride of 3 still fits the layer budget:
      -- 160..382, comfortably under the tag layer at 400. Widening the stride
      -- without shrinking the range instead pushed karts past 1200, over the
      -- main menu at 700 -- a worse bug than the one being fixed.
      local level = self:DepthLevel("kart", dz)
      kart:SetFrameLevel(level)
      -- Driver behind, chassis in front, so they are sitting in the kart.
      kart.model:SetFrameLevel(level + 1)
      kart.chassis:SetFrameLevel(level + 2)

      -- Lean: derived from how fast the racer is sliding across the road, plus
      -- an extra kick while drifting. This is what makes Baine look alive.
      local memory = self.previous[index]
      local lastLateral = memory and memory.lateral or vehicle.lateral
      local slide = vehicle.lateral - lastLateral
      local lean = AK.Math.Clamp(slide * 26, -0.55, 0.55) * tuning.leanAmount
      -- THE DRIFT HAS TO LOOK LIKE A COMMITMENT.
      --
      -- A drift ignores half the wheel on purpose now -- fight the slide and
      -- you get a fifth of your steering, not a turn the other way -- and a
      -- rule like that is only fair if the kart is visibly doing it. A flat
      -- tilt the whole time it was drifting said "drifting" and nothing else,
      -- so a player holding full opposite lock and going nowhere had no way to
      -- tell the difference between a mechanic and a broken control.
      --
      -- `driftHold` is what the physics actually applied this frame: all of the
      -- turn holding in, most of it at neutral, a fifth of it fighting. The
      -- kart lays right over when you commit and comes back upright as you
      -- fight it, which is the picture of what the stick is doing.
      if vehicle.drifting then
        local hold = vehicle.driftHold or 1
        lean = lean + (vehicle.driftDirection or 0)
          * (0.16 + 0.44 * hold) * tuning.leanAmount
      end
      if memory then memory.lateral = vehicle.lateral end
      -- Spin-out: whole kart rotates through several turns, easing to a stop.
      local spin = vehicle.spin or 0
      local spinTurns = 0
      if spin > 0 then
        local t = spin / math.max(0.01, vehicle.spinMax or 1)
        spinTurns = t * t * math.pi * 2 * 2.5
      end
      -- A TRICK. One clean revolution over the flight, in the same channel the
      -- spin-out uses -- so the kart really does roll, driver and all, rather
      -- than the boost simply appearing on landing with nothing to look at.
      -- Deliberately a single turn: a spin-out is several, frantic and
      -- decelerating, and the two must never read as the same event.
      local trick = vehicle.trick or 0
      if trick > 0 then
        local t = trick / math.max(0.01, vehicle.trickMax or 1)
        spinTurns = spinTurns + (1 - t) * math.pi * 2
      end

      -- The shadow stays on the ground and tightens as the kart lifts, which is
      -- what makes the bounce read as height rather than as sliding.
      -- THE SHADOW IS HOW YOU KNOW YOU ARE IN THE AIR.
      --
      -- It stayed pinned to the tarmac while the kart rose, which is right --
      -- and then faded out with height, which is exactly backwards. A ramp
      -- launch lifts the kart 2.1 widths; at 0.8 per width the alpha went
      -- NEGATIVE well before the top of the arc, so the one cue that separates
      -- "airborne" from "closer to the camera" switched itself off for the
      -- whole jump. Now it only shrinks and softens: a small hard dot a long
      -- way under you is what height looks like.
      local lift = math.abs(bounce) / math.max(1, width)
      local shrink = AK.Math.Clamp(1 - lift * 0.30, 0.38, 1)
      kart.shadow:ClearAllPoints()
      kart.shadow:SetPoint("BOTTOM", self.frame, "CENTER", drawX, y - 1)
      kart.shadow:SetSize(width * 1.15 * shrink, math.max(3, height * .22 * shrink))
      kart.shadow:SetAlpha(AK.Math.Clamp(0.55 - lift * 0.15, 0.22, 0.55))
      -- Kart art is 256x160, so keep that ratio or the wheels distort.
      local bodyWidth = width * 1.05
      local bodyHeight = bodyWidth * 0.625
      -- Lightning squashes you flat for a moment.
      local squash = vehicle.squash or 0
      if squash > 0 then
        local t = squash / math.max(0.01, vehicle.squashMax or 1)
        bodyWidth = bodyWidth * (1 + t * 0.35)
        bodyHeight = bodyHeight * (1 - t * 0.45)
      end
      -- AIRBORNE. A sprite that only translates upward is a sprite sliding up
      -- the screen; the shadow says it is high, and this says it is FLYING.
      -- Stretched as it leaves the lip, gathered as it comes down -- the same
      -- squash-and-stretch every hand-drawn jump in the genre has, and free,
      -- because the arc phase is already computed for the bounce.
      if airRise ~= 0 then
        bodyHeight = bodyHeight * (1 + airRise * 0.10)
        bodyWidth = bodyWidth * (1 - airRise * 0.05)
      end
      -- And the compression at the bottom of it, on the suspension's own
      -- channel: a fifth of the lightning squash, over a fifth of a second.
      local land = vehicle.land or 0
      if land > 0 then
        local t = land / math.max(0.01, vehicle.landMax or 1)
        bodyWidth = bodyWidth * (1 + t * 0.14)
        bodyHeight = bodyHeight * (1 - t * 0.18)
      end
      -- A spin-out narrows the kart as it turns side-on to the camera.
      if spinTurns > 0 then
        bodyWidth = bodyWidth * (0.35 + 0.65 * math.abs(math.cos(spinTurns)))
      end
      -- Body art follows the kart, and only when it actually changes: SetTexture
      -- every frame on eight racers would re-bind the same file 480 times a
      -- second for nothing.
      local art = kartTexture(vehicle.kart.id)
      if kart.artApplied ~= art then
        kart.artApplied = art
        kart.body:SetTexture(art)
        kart.lip:SetTexture(art)
      end
      kart.body:SetSize(bodyWidth, bodyHeight)

      -- Star power flickers gold through the whole kart.
      local br, bg, bb = unpack(vehicle.kart.color)
      if (vehicle.star or 0) > 0 then
        local flash = 0.6 + 0.4 * math.sin(race.elapsed * 22)
        br, bg, bb = 1, 0.75 * flash + 0.25, 0.25 * flash
      end
      -- Rivals recede into the same air as the road under them; without this
      -- a kart 300m away was drawn at full saturation, a bright chip floating
      -- on hazed ground with nothing tying it to the distance.
      kart.body:SetVertexColor(self:Aerial(br, bg, bb, 1, dz))
      kart.body:SetDesaturated(vehicle.stun > 0)

      -- Front slice: the bottom `kartLip` fraction of the same texture, drawn
      -- over the driver's legs. Zero the knob to disable it entirely.
      local lip = AK.Math.Clamp(tuning.kartLip, 0, 0.95)
      kart.lip:SetShown(lip > 0.01)
      if lip > 0.01 then
        kart.lip:SetTexCoord(0, 1, 1 - lip, 1)
        kart.lip:SetSize(bodyWidth, bodyHeight * lip)
        kart.lip:SetVertexColor(br, bg, bb)
        kart.lip:SetDesaturated(vehicle.stun > 0)
      end
      kart.flame:SetSize(math.max(3, width * .38), math.max(3, height * .22))
      kart.flame:SetAlpha((vehicle.boostTime > 0 or vehicle.speed > vehicle.maxSpeed * .91) and (AK.db.settings.reducedEffects and .3 or .8) or 0)
      kart.flame:SetVertexColor(unpack(vehicle.boostTime > 0 and AK.COLORS.gold or { 1, .35, .12 }))
      kart.trail:SetSize(width * 1.1, height * 0.42)
      kart.trail:SetAlpha(vehicle.boostTime > 0 and (AK.db.settings.reducedEffects and .08 or .22) or 0)

      -- Drift sparks. Everything here is a fraction of the kart's drawn width,
      -- so they scale with distance and resolution like the kart itself.
      local sparkTier = vehicleIsDrifting(vehicle) and driftTier(vehicle.driftCharge) or 0
      if sparkTier > 0 and not AK.db.settings.reducedEffects then
        local hue = driftColor(vehicle.driftCharge)
        -- Bigger and busier with each tier, and flickering faster -- the rate is
        -- as much of the read as the colour.
        local flicker = 0.62 + 0.38 * math.sin(race.elapsed * (16 + sparkTier * 9)
          + (vehicle.seed or 0))
        local size = width * (0.20 + sparkTier * 0.07)
        -- Outboard of the bodywork and down at road level, NOT tucked under the
        -- kart. Rendered, tier 1's blue sparks vanished completely against a
        -- blue kart -- and since the player picks the kart colour, no tier hue
        -- is safe from that. Putting them beside the silhouette means they are
        -- always read against tarmac, whatever colour the kart is.
        for i = 1, 2 do
          local side = i == 1 and -1 or 1
          local spark = i == 1 and kart.sparkL or kart.sparkR
          spark:ClearAllPoints()
          spark:SetPoint("CENTER", kart, "BOTTOM", side * width * 0.46, height * 0.02)
          spark:SetSize(size, size)
          spark:SetVertexColor(hue[1], hue[2], hue[3], 1)
          spark:SetAlpha((0.45 + 0.30 * sparkTier / 3) * flicker)
        end
      else
        kart.sparkL:SetAlpha(0)
        kart.sparkR:SetAlpha(0)
      end

      -- Each racer wears their own appearance and sits at their own height;
      -- both calls no-op unless something actually changed.
      -- A PlayerModel that is never shown never streams its model in. Gating
      -- the Show() on IsReady() therefore deadlocked: hidden, so it never
      -- loaded, so it was never ready, so it stayed hidden -- and every racer
      -- fell back to the flat kart icon no matter which racer was chosen.
      -- The frame is shown as soon as it has a spec; an unloaded model simply
      -- draws nothing, and the icon covers that gap.
      local modelReady = false
      if not self.suppressModels then
        AK.Model:SetSpec(kart.model, AK:GetRacerModel(vehicle))
        AK.Model:SetSeat(kart.model, vehicle.racer)
        modelReady = AK.Model:IsReady(kart.model)
        kart.model:Show()
        -- RETRY A STUCK MODEL.
        --
        -- Loading is asynchronous and the completion can simply be lost: a
        -- PlayerModel hidden part-way through a stream may never fire
        -- OnModelLoaded, so `akLoaded` stays false -- and because `akSpec` was
        -- already set, SetSpec early-returns on every subsequent frame and
        -- never retries. The racer is then a flat icon for the rest of the
        -- session with no path back, which is the "everyone lost their models
        -- again" report. Attract mode hides every model by design, so this is
        -- reachable on any menu-to-race transition.
        -- BOUNDED. Retrying forever is worse than the fault it is for: a model
        -- the client will never report as loaded -- a unit-based one, say --
        -- was being cleared and re-streamed every second and a half for the
        -- whole race. Three attempts is a lost load; more than that is a
        -- disagreement about what "loaded" means, and thrashing the frame will
        -- not settle it.
        if modelReady then
          kart.modelStuck, kart.modelTries = 0, 0
        else
          kart.modelStuck = (kart.modelStuck or 0) + (race.renderDelta or race.delta or 0)
          if kart.modelStuck > 1.5 and (kart.modelTries or 0) < 3 then
            AK.Model:Invalidate(kart.model)
            kart.modelStuck = 0
            kart.modelTries = (kart.modelTries or 0) + 1
          end
        end
      else
        kart.model:Hide()
      end
      -- Centre-anchored and generously sized: model frames clip to their bounds
      -- and render about the model's own origin, so a bottom-anchored frame
      -- chopped Baine off at the waist and sank him into the road.
      local modelSize = width * tuning.modelScale * 2.4
      kart.model:ClearAllPoints()
      kart.model:SetPoint("CENTER", kart, "BOTTOM", 0, width * tuning.modelLift)
      kart.model:SetSize(modelSize, modelSize)
      AK.Model:Reframe(kart.model)
      -- The driver spins with the kart.
      kart.model:SetFacing(math.pi + lean + spinTurns)
      if kart.model.SetDesaturation then kart.model:SetDesaturation(vehicle.stun > 0 and 1 or 0) end
      -- AND THE ICON GIVES UP. It exists to cover the second or two before a
      -- model streams in, not to be a portrait glued to the kart for the whole
      -- race. Once the retries are spent, an empty model frame simply draws
      -- nothing -- which is a far better picture than a framed photograph of
      -- the driver mounted on the bonnet.
      kart.icon:SetShown(not modelReady and (kart.modelTries or 0) < 3)
      kart.icon:SetSize(width * .6, width * .6)
      if kart.iconApplied ~= vehicle.kart.icon then
        kart.iconApplied = vehicle.kart.icon
        kart.icon:SetTexture(vehicle.kart.icon)
      end

      -- Deployed item, orbiting just behind the rear bumper.
      local held = vehicle.held and AK.Items[vehicle.held]
      kart.heldIcon:SetShown(held ~= nil)
      kart.heldGlow:SetShown(held ~= nil)
      if held then
        local size = width * 0.42
        local sway = math.sin(race.elapsed * 3.1 + index) * width * 0.06
        kart.heldIcon:ClearAllPoints()
        kart.heldIcon:SetPoint("CENTER", kart, "BOTTOM", sway, -width * 0.16)
        kart.heldIcon:SetSize(size, size)
        if kart.heldApplied ~= held.icon then
          kart.heldApplied = held.icon
          kart.heldIcon:SetTexture(held.icon)
        end
        kart.heldIcon:SetVertexColor(unpack(held.tint or { 1, 1, 1 }))
        kart.heldGlow:ClearAllPoints()
        kart.heldGlow:SetPoint("CENTER", kart.heldIcon, "CENTER")
        kart.heldGlow:SetSize(size * 2.0, size * 2.0)
        kart.heldGlow:SetVertexColor(held.color[1], held.color[2], held.color[3], 1)
        kart.heldGlow:SetAlpha(0.25 + 0.15 * math.sin(race.elapsed * 7))
      end

      -- Name tags float above the model, in their own always-on-top layer.
      --
      -- THROUGH setShown, BOTH WAYS. These two were shown with a direct
      -- SetShown and hidden through the cache -- and the cache's whole contract
      -- (see its note above) is that anything showing or hiding a pooled region
      -- has to come through it. The direct call never set the flag, so when the
      -- kart later left the screen `setShown(kart.tag, false)` looked at a flag
      -- that still said "hidden", decided there was nothing to do, and skipped
      -- the Hide. The tag stayed exactly where it was last drawn.
      --
      -- That is the name parked in the distance: not a rendering fault at all,
      -- but the one region in this file that used both idioms on the same
      -- widget, so the hide could never fire.
      local tagVisible = width > 34
      setShown(kart.tag, tagVisible)
      setShown(kart.tagPlate, tagVisible)
      if tagVisible then
        kart.tag:SetText(vehicle == player and "YOU" or (vehicle.racer.tag or "CPU"))
        kart.tag:SetTextColor(unpack(vehicle == player and AK.COLORS.gold or { 1, 1, 1 }))
        kart.tag:ClearAllPoints()
        -- Above the racer's HEAD, not above the frame. The kart frame is a
        -- square as tall as it is wide, while the kart and rider only fill
        -- roughly its lower two thirds -- so 1.10 of the frame height threw the
        -- tag far above the art. That was invisible while karts were small and
        -- became "YOU floating on the horizon" as soon as they were not.
        -- `bounce` carries every vertical offset the kart has -- road bump, the
        -- drift hop, and the long ramp arc. The kart frame is placed at
        -- `y + bounce` but the tag was placed at plain `y`, so launching off a
        -- ramp left "YOU" sitting on the tarmac while the kart flew up the
        -- screen without it.
        kart.tag:SetPoint("CENTER", self.frame, "CENTER", drawX, y + bounce + height * 0.70)
        kart.tagPlate:SetSize(kart.tag:GetStringWidth() + 10, kart.tag:GetStringHeight() + 5)
        -- Tags live on `tagLayer` so they always draw over the field, which
        -- also means they do NOT inherit the kart's alpha. Faded by hand, or a
        -- rival fading out at the screen edge leaves a name floating there on
        -- its own -- which is the sliding artefact with a label on it.
        local tagFade = vehicle == player and 1 or self:EdgeFade(drawX, dz)
        kart.tag:SetAlpha(tagFade)
        kart.tagPlate:SetAlpha(0.55 * tagFade)
      end

      -- Battle marker. A rival counts as fighting you once they have been
      -- within a few metres for more than a moment -- the dwell is what stops
      -- it strobing every time someone flicks past on a straight.
      if vehicle ~= player and not vehicle.finished and player and not player.finished then
        local gap = math.abs(vehicle.distance - player.distance)
        if gap < 6 and math.abs((vehicle.lateral or 0) - (player.lateral or 0)) < 0.9 then
          vehicle.battleTime = (vehicle.battleTime or 0) + (race.renderDelta or race.delta or 0)
        else
          vehicle.battleTime = 0
        end

        -- NEAR MISS. Passing close at speed is most of what makes a crowded
        -- pack exciting, and nothing acknowledged it at all. Fires once per
        -- rival per pass: `nearMissed` latches while you are alongside and only
        -- clears once you are properly apart, so a kart you sit beside down a
        -- straight cannot machine-gun the cue.
        local alongside = gap < 2.2
          and math.abs((vehicle.lateral or 0) - (player.lateral or 0)) < 0.85
        if alongside and not vehicle.nearMissed then
          vehicle.nearMissed = true
          if (player.speed or 0) > (player.maxSpeed or 1) * 0.70 then
            self:Feel("kickX", ((vehicle.lateral or 0) < (player.lateral or 0) and 1 or -1) * 7)
            self:Shake(4)
            if AK.PlaySfx then AK:PlaySfx("nearMiss") end
          end
        elseif not alongside and gap > 5 then
          vehicle.nearMissed = false
        end
      else
        vehicle.battleTime = 0
        vehicle.nearMissed = false
      end
      local battling = (vehicle.battleTime or 0) > 1.5 and tagVisible
      kart.warn:ClearAllPoints()
      kart.warn:SetPoint("CENTER", self.frame, "CENTER", drawX, y + height * 0.95)
      kart.warn:SetText(battling and "!" or "")
      kart.warn:SetAlpha(battling and (0.55 + 0.45 * math.sin(race.elapsed * 9)) or 0)

      -- A rival thrown off-axis by a corner fades like everything else standing
      -- in the world. Your OWN kart never does: it sits at camBack metres, well
      -- inside EdgeFade's near exemption, but it is the one thing on screen that
      -- must never dim under any circumstances, so it is excluded outright
      -- rather than left to depend on a tuning value staying where it is.
      -- UNTOUCHABLE HAS TO LOOK LIKE SOMETHING.
      --
      -- `immune` is the strongest defensive state in the game -- it is what
      -- Boo's getaway is -- and it was drawn identically to being ordinary. A
      -- player who cannot see it cannot use it, which is half of why the item
      -- felt like it did nothing. A slow half-fade, so the kart reads as
      -- present but not quite there.
      local solid = vehicle == player and 1 or self:EdgeFade(drawX, dz)
      if (vehicle.immune or 0) > 0 then
        solid = solid * (0.42 + 0.16 * math.sin(race.elapsed * 9))
      end
      kart:SetAlpha(solid)
      setShown(kart, true)
      if vehicle == player then
        self.playerX, self.playerY, self.playerWidth = drawX, y, width
      end

      self:VehicleEffects(vehicle, index, x, y, width, vehicle == player)
    else
      hideKart(self, kart, index)
    end
  end

  -- AND THE POOL IS BIGGER THAN THE FIELD.
  --
  -- There are MAX_RACERS kart frames, built once and reused, and this loop only
  -- ever walks the racers actually in the race -- so every entry past the end
  -- of the field keeps whatever the LAST race left on it. A Time Trial and a
  -- Practice run are built with exactly one vehicle (Race:BuildRace), and
  -- lowering the rival count in the settings does the same thing on a smaller
  -- scale, so seven name tags from the grand prix you just finished stayed
  -- painted on the screen, frozen at the position their kart was in when it was
  -- last drawn: "THRALL" parked in the distance for the whole of your hot lap.
  --
  -- The kart frames themselves went away with it and were never the tell, since
  -- the model and the sprite are children of the frame. The tags are not.
  for index = #race.vehicles + 1, #self.karts do
    hideKart(self, self.karts[index], index)
  end
end

function RaceUI:Render(race)
  if not self.frame or not self.frame:IsShown() then return end
  local player = race.player
  if not player then return end
  local tuning = AK.db.tuning
  self.T = tuning
  self.halfWidth = self.frame:GetWidth() * .5
  self.halfHeight = self.frame:GetHeight() * .5
  -- Visual easing uses the real frame delta; the simulation uses fixed slices.
  local dt = race.renderDelta or race.delta
  if self.appliedHorizon ~= tuning.horizon then self:LayoutHorizon(tuning.horizon) end
  -- Same deal for the HUD dial: nudging it in the tuning panel during a race
  -- should move the HUD while you watch, not on the next reload.
  if self.appliedHudScale ~= tuning.hudScale then
    self.appliedHudScale = tuning.hudScale
    self:LayoutHud()
  end

  local speedRatio = AK.Math.Clamp(player.speed / player.maxSpeed, 0, 1.3)
  -- Lens widens with speed and boost. Cheap, and it is most of what makes going
  -- fast actually feel fast.
  local boostFov = tuning.boostFov
  local targetDepth = tuning.camDepth - boostFov * AK.Math.Clamp(speedRatio - .45, 0, 1) / .55
  if player.boostTime > 0 then targetDepth = tuning.camDepth - boostFov end
  if AK.db.settings.reducedEffects then targetDepth = tuning.camDepth end
  -- Asymmetric: the lens snaps open when the boost lands and relaxes slowly
  -- afterwards. Equal rates make a boost feel like a setting changing rather
  -- than something hitting you.
  local widening = targetDepth < (self.camDepth or tuning.camDepth)
  local lensRate = widening and 12 or 4.5    -- ~0.15s in, ~0.4s out
  self.camDepth = AK.Math.Lerp(self.camDepth or tuning.camDepth, targetDepth,
    math.min(1, dt * lensRate))

  -- Feel channels: triggers, then decay. Read every frame from the player's own
  -- state, so nothing has to remember to call in from the simulation.
  self.feel = self.feel or {}
  local feel = self.feel
  local was = self.previous

  -- Boost begins: shove the camera back. Ending it needs no impulse -- the
  -- channel is already easing home on its own.
  local boosting = (player.boostTime or 0) > 0
  if boosting and not was.boosting then self:Feel("push", 2.6) end
  was.boosting = boosting

  -- Launch and landing, the two ends of a jump.
  local air = (player.air or 0)
  if (was.air or 0) <= 0 and air > 0 then self:FeelLaunch(player.airMax or air) end
  if (was.air or 0) > 0 and air <= 0 then self:FeelLanding(was.airMax or was.air) end
  was.air, was.airMax = air, air > 0 and math.max(was.airMax or 0, player.airMax or air) or 0

  -- Drift lean, PROPORTIONAL TO CHARGE rather than a flat tilt the moment a
  -- drift starts. The lean growing as the mini-turbo builds is the readable
  -- part -- it tells you how close the boost is without looking at the meter.
  local charge = vehicleIsDrifting(player) and (player.driftCharge or 0) or 0
  local leanTarget = (player.driftDirection or 0) * AK.Math.Clamp(charge / 1.8, 0, 1)
  if AK.db.settings.reducedEffects then leanTarget = 0 end
  feel.lean = AK.Math.Lerp(feel.lean or 0, leanTarget, math.min(1, dt * 6))
  if math.abs(feel.lean) < FEEL_EPSILON then feel.lean = 0 end

  -- Rates are "how fast this comes home", verified by verify-feel.js. `push`
  -- was 2.6, which took 4.25s to fully settle -- with boosts landing every few
  -- seconds the camera then sat pulled back permanently instead of punching and
  -- recovering, which is the opposite of the intended read.
  feel.push = decay(feel.push, 5.0, dt)     -- ~0.6s to imperceptible
  feel.dip = decay(feel.dip, 7.0, dt)       -- fast, it is a landing thump
  feel.kickX = decay(feel.kickX, 6.0, dt)

  -- Camera shake: decays fast, plus a constant rumble while off the tarmac.
  local rumble = player.offroad and 3.5 or 0
  self.shake = math.max((self.shake or 0) * math.max(0, 1 - dt * 7) - dt * 4, rumble)
  if AK.db.settings.reducedEffects then self.shake = 0 end
  local shake = self.shake * tuning.shakeScale
  self.shakeX = (math.random() - .5) * 2 * shake + (feel.kickX or 0)
  self.shakeY = (math.random() - .5) * 2 * shake

  -- Aim the camera down the road ahead, plus a kick from your own steering.
  -- The result is that the world swings through a corner instead of sliding.
  -- No heading term any more: the forward-accumulated bend already swings the
  -- road through the corner, and yawing on top of it would cancel exactly the
  -- curvature we just went to the trouble of showing. What is left is the part
  -- yaw was always actually good for -- a kick from your own input.
  local steer = (AK.Race.controls.right and 1 or 0) - (AK.Race.controls.left and 1 or 0)
  if not player.isPlayer then steer = 0 end
  local targetYaw = steer * tuning.camYaw * 0.16 * speedRatio
  -- Lean into the slide, scaled by how much mini-turbo is banked. `feel.lean`
  -- is already eased and already zeroed when the drift ends.
  targetYaw = targetYaw + (feel.lean or 0) * tuning.camYaw * 0.20
  self.camYawValue = AK.Math.Lerp(self.camYawValue or targetYaw, targetYaw, math.min(1, dt * 4.5))
  self.yawShift = -self.camYawValue * (self.camDepth or tuning.camDepth) * self.halfWidth

  local camX, camZ = self:RenderRoad(race, player)
  self:RenderFork(race, player, camX, camZ)
  -- Props are child frames, so they draw above the rock rather than behind it,
  -- and underground there is no roadside to decorate. This gate was 0.85, which
  -- is not "under cover" -- cover ramps in over 14m, so 0.85 is twelve metres
  -- INSIDE the tunnel with the rock already almost opaque behind the trees.
  if (self.tunnelDepth or 0) < 0.15 then self:RenderProps(race, camX, camZ) end
  self:RenderSky(race, camX)
  self:RenderPosts(race, camX, camZ)
  self:RenderArches(race, camX, camZ)
  self:RenderFinish(race, camX, camZ)
  self:RenderSpectators(race, camX, camZ)
  self:RenderObjects(race, player, camX, camZ)
  self:RenderHazards(race, camX, camZ)
  self:RenderGhost(race, camX, camZ)
  self:RenderProjectiles(race, camX, camZ)
  self:RenderKarts(race, player, camX, camZ)
  self:UpdateParticles(dt)
  self:UpdateEffects(dt)
  self:RenderWeather(race, dt)

  self:UpdatePresentation(race, dt)
  self:UpdateLadder(race)
  self:UpdateRecovery(race)
  -- On the cooldown lap nobody is driving: the item box, the drift meter and
  -- the control legend are all instruments for a driver who no longer exists,
  -- so they fade back and leave the screen to the ladder and the road.
  local driving = race.state ~= AK.RACE_STATES.COOLDOWN
  self.driverFade = self.driverFade
    and self.driverFade + (((driving and 1 or 0.18) - self.driverFade)
      * math.min(1, dt * 6))
    or (driving and 1 or 0.18)
  if self.itemPanel then self.itemPanel:SetAlpha(self.driverFade) end

  local lineAlpha = AK.db.settings.reducedEffects and 0 or AK.Math.Clamp((speedRatio - .55) * 1.8, 0, .5)
  if player.boostTime > 0 then lineAlpha = math.max(lineAlpha, .5) end
  -- The last lap is louder: streaks bite lower down the speed range and run
  -- harder, so the final lap reads as urgent even at the same pace.
  if self.finalLapUrgency then
    lineAlpha = math.max(lineAlpha, AK.Math.Clamp((speedRatio - .30) * 1.6, 0, .62))
  end
  lineAlpha = lineAlpha * tuning.speedLines
  for index, line in ipairs(self.speedLines) do
    -- Streaks radiate from the vanishing point, and only in the periphery --
    -- scattered through the middle they read as scratches on the screen.
    local angle = index * 2.399
    local travel = ((race.elapsed * (.9 + speedRatio * 1.7) + index * .137) % 1)
    local reach = travel * travel
    local x = math.cos(angle) * reach * self.halfWidth * 1.9
    local y = tuning.horizon + math.sin(angle) * reach * self.halfHeight * 1.9
    local peripheral = math.abs(x) / self.halfWidth
    line:ClearAllPoints()
    line:SetPoint("CENTER", self.frame, "CENTER", x, y)
    -- Length scales with actual pace, not just opacity. Streaks that only fade
    -- in read as a filter switching on; streaks that STRETCH read as speed.
    -- Screen-relative, so they are the same streak at any resolution.
    local stretch = 0.55 + speedRatio * 0.85 + (boosting and 0.5 or 0)
    line:SetSize(math.max(1, self.halfWidth * 0.0012 * (1 + reach * 3)),
      self.halfHeight * (0.017 + reach * 0.092) * stretch)
    line:SetAlpha(lineAlpha * math.min(1, travel * 2.5) * AK.Math.Clamp((peripheral - .32) * 2.2, 0, 1))
  end

  -- Edge warp, boost only. A dark vignette that tightens as the boost runs,
  -- which pinches the frame inward without touching the middle of the screen
  -- where the player is actually looking.
  if self.vignette then
    local boostLeft = AK.db.settings.reducedEffects and 0
      or AK.Math.Clamp((player.boostTime or 0) / 0.8, 0, 1)
    self.boostWarp = AK.Math.Lerp(self.boostWarp or 0, boostLeft, math.min(1, dt * 9))
    if self.boostWarp < 0.001 then self.boostWarp = 0 end
    -- 0.22 is the resting vignette this texture was built for; the boost only
    -- ever adds on top, so turning effects off leaves exactly the old look.
    self.vignette:SetAlpha(0.22 + self.boostWarp * 0.30)
  end
  self.boostTint:SetAlpha(player.boostTime > 0 and (AK.db.settings.reducedEffects and 0 or .08) or 0)

  -- AN ARENA IS SCORED DIFFERENTLY FROM A CIRCUIT.
  --
  -- Both readouts in this block were racing readouts printed over a battle:
  -- a place ordinal derived from how far around the loop each kart happened to
  -- be, which is not a standing in a fight, and "LAP 1 / 999". The mode's two
  -- real numbers -- your balloons, and how many rivals are still in -- were
  -- nowhere on the screen.
  if race.battle then
    local alive, mine = 0, player.balloons or 0
    for _, vehicle in ipairs(race.vehicles) do
      if not vehicle.eliminated then alive = alive + 1 end
    end
    if self.shownAlive and alive ~= self.shownAlive then self.positionPulse = 1 end
    self.shownAlive, self.shownPosition = alive, nil
    self.positionPulse = math.max(0, (self.positionPulse or 0) - dt * 2.6)
    local out = player.eliminated
    self.position:SetText(out and "OUT" or tostring(alive))
    self.positionOf:SetText(out and "" or "STILL IN")
    local base = out and AK.COLORS.danger
      or (alive <= 2 and AK.COLORS.gold or { .9, .94, 1 })
    local pulseTint = self.positionPulse
    self.position:SetTextColor(
      base[1] + (1 - base[1]) * pulseTint,
      base[2] + (1 - base[2]) * pulseTint,
      base[3] + (1 - base[3]) * pulseTint)
    self.lapWord:SetText("BALLOONS")
    self.lap:SetText(tostring(mine))
    self.lap:SetTextColor(unpack(mine <= 1 and AK.COLORS.danger or { .95, .96, 1 }))
    for i, pip in ipairs(self.lapPips) do
      pip:SetShown(i <= AK.BATTLE_BALLOONS)
      pip:SetVertexColor(unpack(i <= mine and AK.COLORS.danger or { .25, .32, .42, 1 }))
    end
  else
    local position = race.positions[player] or 1
    -- Pulse the ordinal whenever it changes, so a gained place registers even if
    -- you were watching the road instead of the HUD.
    if self.shownPosition and position ~= self.shownPosition then
      self.positionPulse = 1
    end
    self.shownPosition, self.shownAlive = position, nil
    self.positionPulse = math.max(0, (self.positionPulse or 0) - dt * 2.6)
    self.position:SetText(ORDINALS[position] or (position .. "TH"))
    local pulseTint = self.positionPulse
    local base = position == 1 and AK.COLORS.gold or (position <= 3 and AK.COLORS.lime or { .9, .94, 1 })
    self.position:SetTextColor(
      base[1] + (1 - base[1]) * pulseTint,
      base[2] + (1 - base[2]) * pulseTint,
      base[3] + (1 - base[3]) * pulseTint)
    self.positionOf:SetText("/ " .. #race.vehicles)
    self.lapWord:SetText("LAP")
    self.lap:SetText(math.min(player.lap, race.laps) .. " / " .. race.laps)
    self.lap:SetTextColor(.95, .96, 1)
    for i, pip in ipairs(self.lapPips) do
      pip:SetShown(i <= race.laps)
      pip:SetVertexColor(unpack(i < player.lap and AK.COLORS.gold or { .25, .32, .42, 1 }))
    end
  end
  self.timer:SetText(self:FormatTime(race.elapsed))
  self.speed:SetShown(AK.db.settings.showSpeed)
  self.speed:SetText(math.floor(player.speed * 2.2) .. " km/h")
  self.speed:SetTextColor(unpack(player.boostTime > 0 and AK.COLORS.gold or AK.COLORS.lime))
  local slowed = (player.slow or 0) > 0
  self.status:SetText(slowed and "SLOWED" or (player.offroad and "OFF ROAD" or (player.boostTime > 0 and "TURBO!" or "")))
  self.status:SetTextColor(unpack(slowed and AK.COLORS.danger or (player.offroad and AK.COLORS.gold or AK.COLORS.lime)))

  -- The keyboard legend and the shortcut blurb are onboarding, not HUD. They
  -- are exactly what you want while the lights are counting down, and pure
  -- clutter across the bottom of the screen for the other ninety seconds. So
  -- they fade out once you are actually driving, and come back whenever the
  -- race is not running -- the countdown, a pause, the moment after the flag.
  local settled = race.state == AK.RACE_STATES.RACING and race.elapsed > 6
  local onboarding = settled and AK.Math.Clamp(1 - (race.elapsed - 6) / 1.5, 0, 1) or 1
  onboarding = onboarding * (self.driverFade or 1)
  self.controlHint:SetAlpha(onboarding)
  self.shortcut:SetAlpha(onboarding)

  -- Item roulette: picking up a box spins the slot before locking in, which is
  -- half the fun of getting one.
  if player.item and not self.lastItem then
    self.roulette = race.elapsed + 0.95
    self:BoxShatter()
    if AK.PlaySfx then AK:PlaySfx("item") end
  elseif not player.item then
    self.roulette = nil
  end
  self.lastItem = player.item
  local spinning = self.roulette and race.elapsed < self.roulette
  if spinning then
    -- Slow the cycle as it settles, so it lands rather than cuts.
    local remaining = self.roulette - race.elapsed
    local rate = 26 - 20 * (1 - remaining / 0.95)
    local pool = AK.ItemOrder
    local shown = pool[(math.floor(race.elapsed * rate) % #pool) + 1]
    self.itemIcon:SetTexture(AK.Items[shown].icon)
    self.itemIcon:SetDesaturated(false)
    self.itemLabel:SetText("???")
    self.itemGlow:SetAlpha(0.30)
    local pop = ITEM_ICON + 9 * math.sin(race.elapsed * 24)
    self.itemIcon:SetSize(pop, pop)
    self.itemIcon:SetShown(true)
    applyItemTint(self.itemIcon, AK.Items[shown])
  else
    if self.roulette then
      self.roulette = nil
      self:Flash(AK.COLORS.gold, .08)
    end
    self.itemIcon:SetSize(ITEM_ICON, ITEM_ICON)
    -- The slot shows what is banked; a deployed item shows as "READY - FIRE".
    local slot = player.item and AK.Items[player.item]
    local held = player.held and AK.Items[player.held]
    local shown = slot or held
    -- An empty box is an EMPTY BOX. It used to show a big desaturated question
    -- mark, which reads as "you are holding something unidentified" rather than
    -- as "you are holding nothing".
    self.itemIcon:SetShown(shown ~= nil)
    if shown then
      self.itemIcon:SetTexture(shown.icon)
      self.itemIcon:SetDesaturated(false)
      applyItemTint(self.itemIcon, shown)
    end
    if held and not slot then
      self.itemLabel:SetText("FIRE!")
      self.itemLabel:SetTextColor(unpack(AK.COLORS.lime))
    elseif shown then
      -- Multi-activation items show how many are left, not three icons.
      -- Through the helper rather than reimplementing it here: AK:ItemCount was
      -- the documented way to ask, and this was the only place that asked.
      local count = slot and AK:ItemCount(player) or 1
      -- The icon already says WHAT it is. The label carries the only thing an
      -- icon cannot: how many are left -- and, while the aim is reversed, which
      -- WAY it is about to go. A shell fired behind you is the whole defensive
      -- half of the item game and there was nothing on screen that said it was
      -- possible, let alone that it was currently armed.
      local back = AK.Race.controls.aimBack or AK.Race.controls.brake
      if back and shown.effect == "projectile" then
        self.itemLabel:SetText(count > 1 and ("<< x" .. count) or "<< BACK")
        self.itemLabel:SetTextColor(unpack(AK.COLORS.lime))
      else
        self.itemLabel:SetText(count > 1 and ("x" .. count) or "")
        self.itemLabel:SetTextColor(unpack(AK.COLORS.gold))
      end
    else
      -- An empty box is an empty box. It used to print "NO ITEM" in it, which
      -- is a form field telling you what you can already see.
      self.itemLabel:SetText("")
    end
    self.itemGlow:SetAlpha(shown and (0.14 + 0.12 * math.sin(race.elapsed * (held and 11 or 6))) or 0)
  end

  -- Current lap split, with the best lap so far alongside it.
  -- Corner callout. Only fires on a change, and fades rather than sitting on
  -- screen, so it reads as a signpost going past instead of as a HUD element.
  if self.sectionLabel then
    local section = AK.TrackBuilder:SectionAt(player.route or race.track, player.distance)
    local name = section and section.name
    if name ~= self.sectionShown then
      self.sectionShown = name
      self.sectionUntil = race.elapsed + 2.4
      self.sectionLabel:SetText(name and name:upper() or "")
    end
    local left = (self.sectionUntil or 0) - race.elapsed
    self.sectionLabel:SetAlpha(AK.Math.Clamp(left / 0.9, 0, 1) * 0.92)
  end

  local lapElapsed = race.elapsed - (player.lapStart or 0)
  if race.state == AK.RACE_STATES.RACING or race.state == AK.RACE_STATES.PAUSED then
    self.lapTime:SetText(("LAP %s   BEST %s"):format(
      self:FormatTime(math.max(0, lapElapsed)),
      player.bestLap and self:FormatTime(player.bestLap) or "--:--.--"))
  else
    self.lapTime:SetText("")
  end

  local charge = AK.Math.Clamp(player.driftCharge / DRIFT_MAX, 0, 1)
  local chargeColor = driftColor(player.driftCharge)
  self.driftFill:SetWidth(math.max(0.01, DRIFT_TRACK * charge))
  self.driftFill:SetVertexColor(chargeColor[1], chargeColor[2], chargeColor[3], 1)
  self.driftGlow:SetWidth(math.max(0.01, DRIFT_TRACK * charge))
  self.driftGlow:SetVertexColor(chargeColor[1], chargeColor[2], chargeColor[3], 1)
  self.driftGlow:SetAlpha(charge > 0 and (0.18 + 0.22 * math.sin(race.elapsed * 9)) * charge or 0)
  -- The tier you have BANKED, in the tier's own colour -- not an instruction.
  -- "DRIFT BOOST" and "RELEASE FOR BOOST" were a tutorial pinned to the screen
  -- for the whole race; what you actually cannot see is which rung you are on.
  local tier = driftTier(player.driftCharge)
  self.driftLabel:SetText(DRIFT_TIER_NAMES[tier] or "")
  self.driftLabel:SetTextColor(chargeColor[1], chargeColor[2], chargeColor[3])
  self.driftPanel:SetAlpha((player.drifting and 1 or (charge > 0 and 1 or 0.45))
    * (self.driverFade or 1))
  -- Each tick lights when the charge passes the threshold it actually marks.
  for i, tick in ipairs(self.driftTicks) do
    local lit = charge >= DRIFT_TICKS[i] - 0.001
    tick:SetVertexColor(unpack(lit and AK.COLORS.gold or { .08, .13, .20, 1 }))
  end

  -- The on-screen pads and the corner quit answer the same question -- "how do
  -- I do this without a keyboard" -- so they travel together.
  local pads = AK.db.settings.showControls
  self.controlPads:SetShown(pads)
  self.quit:SetShown(pads)

  self.minimap:SetShown(AK.db.settings.showMinimap)
  if AK.db.settings.showMinimap then
    for index, vehicle in ipairs(race.vehicles) do
      local mapX, mapY = self:MapPosition(race.track, vehicle.progress or vehicle.distance)
      local dot = self.mapDots[index]
      dot:ClearAllPoints()
      dot:SetPoint("CENTER", self.minimap, "CENTER", mapX, mapY)
      local colour = vehicle == player and AK.COLORS.gold or vehicle.kart.color
      -- A kart that is out of a battle is still on the road -- it drives on,
      -- it just cannot win or be hit any more. Drawn dark grey rather than in
      -- its own colour, so the map answers "who is still in this" at a glance,
      -- which is the whole question in an arena.
      if vehicle.eliminated then
        dot:SetVertexColor(.30, .32, .36)
      else
        dot:SetVertexColor(unpack(colour))
      end
      dot:SetSize(vehicle == player and 9 or 6, vehicle == player and 9 or 6)
      dot:Show()
    end
  end

  -- The panel is laid out on the EDGE, not every frame: it re-anchors three
  -- buttons and resizes the plate, and doing that sixty times a second while
  -- the player reads it is work for no picture. It also means the quit button's
  -- arming survives -- a relayout disarms it, which is right on a fresh pause
  -- and wrong one frame after the player clicked it.
  local paused = race.state == AK.RACE_STATES.PAUSED
  if paused ~= self.pauseShown then
    self.pauseShown = paused
    self.pause:SetShown(paused)
    if paused then self:LayoutPause(race) end
  end
  if paused and self.pauseWhere then
    -- A battle has no laps to count, and a Grand Prix is one heat of four.
    self.pauseWhere:SetText((race.track and race.track.name or "BATTLE ARENA"):upper())
    if race.battle then
      self.pauseCount:SetText("BATTLE")
    else
      local lap = ("LAP %d OF %d"):format(math.min(player.lap or 1, race.laps), race.laps)
      if race.grandPrix then
        self.pauseCount:SetText(("RACE %d OF %d  --  %s"):format(
          race.grandPrix.index, #race.grandPrix.cup.tracks, lap))
      else
        self.pauseCount:SetText(lap)
      end
    end
  end
  if race.state == AK.RACE_STATES.COUNTDOWN then
    local counting = race.countdown > 0.15
    self.countdown:SetText(counting and tostring(math.ceil(race.countdown)) or "GO!")
    local phase = counting and (math.ceil(race.countdown) - race.countdown) or 0
    if self.countdown.SetScale then self.countdown:SetScale(1.35 - AK.Math.Clamp(phase, 0, .35)) end
    self.countdown:SetTextColor(unpack(counting and AK.COLORS.gold or AK.COLORS.lime))
    -- Lights arm from left to right as the count runs down, then all go green.
    self.lightRig:Show()
    for i, light in ipairs(self.lights) do
      local armed = race.countdown <= (3 - i + 1)
      if not counting then
        light.lamp:SetVertexColor(.25, 1, .35, 1)
        light.halo:SetVertexColor(.3, 1, .4, 1)
        light.halo:SetAlpha(.75)
      elseif armed then
        light.lamp:SetVertexColor(1, .18, .12, 1)
        light.halo:SetVertexColor(1, .2, .15, 1)
        light.halo:SetAlpha(.6)
      else
        light.lamp:SetVertexColor(.16, .05, .05, 1)
        light.halo:SetAlpha(0)
      end
    end
  else
    self.countdown:SetText("")
    self.lightRig:Hide()
  end

  if self.noticeUntil then
    local remaining = self.noticeUntil - race.elapsed
    if remaining <= 0 then
      self.notice:SetText("")
      self.noticePlate:Hide(); self.noticeEdge:Hide(); self.noticeIcon:Hide()
    else
      local fade = AK.Math.Clamp(remaining / .35, 0, 1)
      -- Punch in over the first 120ms so it reads as an event, not a caption.
      -- The pop drives the plate rather than the text: SetScale on a region
      -- scales its anchor offset too, which would fling a banner anchored at
      -- +258 up the screen as it grew.
      local age = race.elapsed - (self.noticeStart or 0)
      local pop = 1 + 0.30 * math.max(0, 1 - age / 0.12)
      self.notice:SetAlpha(fade)
      local textWidth = self.notice:GetStringWidth()
      local iconSize = self.noticeIcon:IsShown() and 42 or 0
      self.noticePlate:SetSize((textWidth + 56 + iconSize) * pop, 52 * pop)
      self.noticePlate:SetAlpha(fade * .62)
      self.noticePlate:Show()
      self.noticeEdge:SetSize((textWidth + 56 + iconSize) * pop, 2)
      self.noticeEdge:SetVertexColor(unpack(self.noticeColor or AK.COLORS.gold))
      self.noticeEdge:SetAlpha(fade)
      self.noticeEdge:Show()
      if iconSize > 0 then
        self.noticeIcon:SetSize(iconSize, iconSize)
        self.noticeIcon:SetAlpha(fade)
      end
    end
  end
  self.flashAlpha = math.max(0, (self.flashAlpha or 0) - dt * 1.9)
  self.flash:SetAlpha(self.flashAlpha)
  if AK.Debug then AK.Debug:Update(race) end
end
